<?php return array (
  'index-halaqoh-display' => 'App\\Http\\Livewire\\IndexHalaqohDisplay',
);