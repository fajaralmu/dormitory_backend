<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class PointRecordFollowUp extends Pivot
{
    protected $table = 'point_record_follow_up';
}
