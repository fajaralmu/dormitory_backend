<?php

namespace App\Dto;

class AttachmentInfo
{
    public string $name;
    // public string $data;
    /**
     * base64 String
     */
    public string $url;
}
