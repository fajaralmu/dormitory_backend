<?php $__env->startSection('content'); ?>
    <h1 class="title">Halaqoh</h1>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.halaqoh.create')); ?>" class="button is-primary is-rounded">
                <span class="icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span>Halaqoh Baru</span>
            </a>
        </div>
    </div>

    <?php if($halaqohs->count()): ?>
        <?php $__env->startComponent('components.card', ['title' => 'Musyrif & Halaqoh']); ?>

        <?php $__env->startComponent('components.singleselect', ['id'=>'select-display',
        'options'=> [''=>'--choose display--', 'table'=>'Table', 'card'=>'Card']]); ?>
        <?php echo $__env->renderComponent(); ?>

        <?php if(isset($listDisplay) && $listDisplay == 'card'): ?>
        <div class="columns is-multiline">
            <?php $__currentLoopData = $halaqohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column is-one-third">
                    <div class="card">
                        <header class="card-header">
                        </header>
                        <div class="card-content" style="text-align: center">
                            <div class="card-image has-text-centered">
                                <img width="200" height="100"
                                    src="<?php echo e(asset('img/quran.png')); ?>" />
                            </div>
                            <h3 style="margin-bottom:0px; margin-top:7px" class="title is-5">Halaqah <?php echo e($halaqoh->nama); ?></h3>
                            <p style="margin-bottom:10px"><?php echo e($halaqoh->pegawai->user->name); ?></p>
                            <p align="center" ><span class="tag">Jumlah Siswa </span><span class="tag is-primary"><?php echo e($halaqoh->members_count); ?></span></p> 

                        </div>
                        <footer class="card-footer" style="display: grid; grid-template-columns: 25% 25% 25% 25%">
                            <a href="<?php echo e(route('admin.halaqoh.signature.index', $halaqoh)); ?>" class="button is-text">
                                <i class="fas fa-stamp"></i>
                            </a>
                            <a href="<?php echo e(route('admin.halaqoh.members.index', $halaqoh)); ?>" class="button is-text">
                                <i class="fas fa-list"></i>
                            </a>
                            <a href="<?php echo e(route('admin.halaqoh.edit', $halaqoh)); ?>"
                                class="button is-text has-text-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php echo $__env->make('components.delete-button', ['url' => route('admin.halaqoh.destroy', $halaqoh)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </footer>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Musyrif</th>
                        <th>Nama Halaqoh</th>
                        <th class="has-text-centered">Anggota</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $halaqohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($halaqoh->pegawai->user->name); ?></td>
                            <td><?php echo e($halaqoh->nama); ?></td>
                            <td class="has-text-centered"><?php echo e($halaqoh->members_count); ?></td>
                            <td class="has-text-right">
                                <a href="<?php echo e(route('admin.halaqoh.signature.index', $halaqoh)); ?>" class="button is-text">
                                    <i class="fas fa-stamp"></i>
                                </a>
                                <a href="<?php echo e(route('admin.halaqoh.members.index', $halaqoh)); ?>" class="button is-text">
                                    <i class="fas fa-list"></i>
                                </a>
                                <a href="<?php echo e(route('admin.halaqoh.edit', $halaqoh)); ?>"
                                    class="button is-text has-text-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php echo $__env->make('components.delete-button', ['url' => route('admin.halaqoh.destroy', $halaqoh)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <?php echo $__env->renderComponent(); ?>

        <?php $__env->startSection('modal'); ?>
			<?php $__env->startComponent('components.modal', ['modal_id' => 'delete-confirmation', 'close_btn' => true]); ?>
				<?php echo $__env->make('partials.delete-confirmation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->renderComponent(); ?>
		<?php $__env->stopSection(); ?>

        <script>
            function init(){
                gotoPageWhenChanged("select-display", function(value){
                   return "/admin/halaqoh?display="+value;
                });

                <?php if(isset($listDisplay)  ): ?>
                   byId("select-display").value = "<?php echo e($listDisplay); ?>";
                <?php endif; ?>

            }

            init();
        </script>
    <?php else: ?>
        <div class="notification is-warning">
            No halaqoh data yet.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/halaqoh/index.blade.php ENDPATH**/ ?>