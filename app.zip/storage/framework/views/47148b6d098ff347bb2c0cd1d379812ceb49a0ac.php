<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('/css/pages/rapor.css')); ?>" rel="stylesheet">
    <title>Rapor PAS | Tahfidz</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bulma.css')); ?>">
    <style>
        td,
        tr,
        tbody,
        thead {
            background-color: transparent;
        }

        /* body {
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
        } */
        body {
            font-size: 1.2rem;
            background-image: url("<?php echo e(asset('img/kiis-bg.jpg')); ?>");
            background-repeat: no-repeat;
            background-position: center;

        }

        table.table.is-vcentered tr td {
            vertical-align: middle;
        }

        hr {
            background-color: #000;
            height: 1px;
        }

        table#details {
            border-color: #000;
        }

        table#details th,
        table#details td {
            border-color: #000;
        }

        .center {
            text-align: center;
        }

        .box,
        .table {
            background-color: transparent;
            font-size: 0.9em;
        }

        table {
            font-size: 0.9em;
        }

        .container {
            padding-left: 2px;
            padding-right: 2px;
        }

    </style>
</head>

<?php
// FIX THIS
$jenjangs = [
'menengah_pertama' => 'Madrasah Tsanawiyah',
'menengah_atas' => 'Madrasah Aliyah',
];

$semester_alias = [
'1' => 'Gasal',
'2' => 'Genap',
];

$labels = [
'a' => 'Sangat Baik',
'b' => 'Baik',
'c' => 'Kurang',
'd' => 'Butuh Bimbingan Lebih',
];
?>

<body>
    <div class="container is-fluid">
        <div class="header" style="display: grid; grid-template-columns: 20% 60% 20%">
            <div class="center"><img height="80" width="80" src="<?php echo e(asset('img/kiis.jpg')); ?>" /></div>
            <div class="has-text-centered" style="margin-bottom: 20px;">
                <h3 class="title is-size-4">Laporan Penilaian Tahfidz Al Quran</h3>
                <h4 class="subtitle title is-size-5"><?php echo e($institusi); ?></h4>
            </div>
            <div class="center"><img height="80" width="80" src="<?php echo e(asset('img/logo.png')); ?>" /></div>
        </div>
        <div class="box">
            <table style="width: 100%; font-size: 1.1em">
                <tr>
                    <th style="width: 300px;">Nama</th>
                    <td><?php echo e($siswa->user->name); ?></td>
                </tr>
                <tr>
                    <th>NIS</th>
                    <td> <?php echo e($siswa->nis); ?> </td>
                </tr>
                <tr>
                    <th>Jenjang</th>
                    <td> <?php echo e(Arr::get($jenjangs, $siswa->kelas->sekolah->jenjang)); ?> </td>
                </tr>
                <tr>
                    <th>Kelas</th>
                    <td> <?php echo e($siswa->kelas->level . $siswa->kelas->rombel); ?> </td>
                </tr>
                <tr>
                    <th>Kategori</th>
                    <td> <?php echo e(strtoupper($kategori)); ?> </td>
                </tr>
                <tr>
                    <th>Tahun Ajaran / Semester</th>
                    <td><?php echo e(config('school.tahun_ajaran')); ?> / <?php echo e(config('school.semester')); ?>

                        (<?php echo e(Arr::get($semester_alias, config('school.semester'))); ?>)</td>
                </tr>
            </table>
        </div>

        <h4 class="is-size-5 has-text-weight-bold is-uppercase section-title" >Rangkuman Penilaian</h4>
        <div class="box">
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th class="has-text-centered">Rerata PAS</th>
                        <?php if(in_array($siswa->kelas->level, [9, 12])): ?>
                            <th class="has-text-centered">Munaqosyah</th>
                        <?php endif; ?>
                        <th class="has-text-centered">Nilai Periodik</th>
                        <th class="has-text-centered">Nilai Rapor</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="has-text-centered"><?php echo e(number_format($nilai_pas, 2)); ?></td>
                        <?php if(in_array($siswa->kelas->level, [9, 12])): ?>
                            <?php if(isset($munaqosyah_active) && $munaqosyah_active == true): ?>
                                <td class="has-text-centered"><?php echo e(number_format($nilai_munaqosyah, 2)); ?></td>
                            <?php else: ?>
                            <td class="has-text-centered">-</td>
                            <?php endif; ?>
                        <?php endif; ?>
                        <td class="has-text-centered"><?php echo e(number_format($nilai_periodik, 2)); ?></td>
                        <td class="has-text-centered"><?php echo e(number_format($nilai_akhir, 2)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <?php if($siswa->rapors->count()): ?>
            <?php
                $fashohah = Arr::get($siswa->rapors[0], 'fashohah');
                $tajwid = Arr::get($siswa->rapors[0], 'tajwid');
                $adab = Arr::get($siswa->rapors[0], 'adab');
            ?>
            <h4 class="is-size-5 has-text-weight-bold is-uppercase  section-title">Penilaian Individual</h4>
            <div class="box">
                <table class="table is-fullwidth is-vcentered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aspek Penilaian</th>
                            <th>Nilai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Fashohah dalam bacaan</td>
                            <td><?php echo e(strtoupper($fashohah)); ?></td>
                            
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Pemahaman dan penerapan ilmu tajwid</td>
                            <td><?php echo e(strtoupper($tajwid)); ?></td>
                            
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Adab (penerapan karakter muslim)</td>
                            <td><?php echo e(is_null($adab) ? '' : strtoupper($adab)); ?></td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        
            <div class="bottom no-break-page" style="width: 100%;  font-size: 0.9em">
                <p class="has-text-centered">Jakarta, <?php echo e($tanggal_cetak); ?> <br> Mengetahui,</p>
                <table style="width: 100%; table-layout: fixed">
                    <tr>
                        <?php $__currentLoopData = $signatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dir => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <div>
                                    <div class="has-text-centered">
                                        <p class="has-text-weight-bold" style="margin: 0 0 -2px 0;">
                                            <?php echo e($details['as']); ?>

                                        </p>
                                        <div style="height: 100px;position:relative;">
                                            <?php if($dir === 'left' && !is_null($stempel)): ?>
                                                <img style="height: 110%;position:absolute;top: 10px;left: 70px;transform: rotate(350deg);"
                                                    src="<?php echo e(Storage::url('stamps/' . $stempel)); ?>" alt="">
                                            <?php endif; ?>
                                            <?php if(!is_null($details['image'])): ?>
                                                <img style="height: 100%;"
                                                    src="<?php echo e(Storage::url('signatures/' . $details['image'])); ?>" alt="">
                                                
                                            <?php endif; ?>
                                        </div>
                                       
                                        <p ><?php echo e($details['name']); ?></p>
                                    </div>
                                </div>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </table>
            </div>
            <div class="page-break" ></div>
            <h4 class="is-size-5 has-text-weight-bold is-uppercase has-text-centered section-title">Daftar Nilai Ujian
            </h4>

            <?php
                $more_than_20_juz = sizeof($targets)>20;
            ?>

            <div class="box no-page-break"
                style="margin-bottom: 10px; <?php echo e($more_than_20_juz ?
                    'padding-bottom:0; padding-top:0; '
                    :''); ?>">
                <table  class="table is-fullwidth is-vcentered" style=" <?php echo e($more_than_20_juz ?
                    'font-size: 0.6em; margin-bottom:0'
                    :''); ?>">
                    <thead>
                        <tr>
                            <th class="has-text-centered">Juz</th>
                            <th class="has-text-centered">Kelancaran</th>
                            <th class="has-text-centered">Fashohah</th>
                            <th class="has-text-centered">Tajwid</th>
                            <th class="has-text-centered">Nilai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php
                                $juz_part = null;

                                $juz_label = (string) $juz;
                                $pure_juz = $juz;
                                $raw_juz = explode( '_', $juz_label);

                                if(Str::contains ($juz_label, '_a')){
                                $juz_part = 'a';
                                $pure_juz = $raw_juz[0];
                                }
                                elseif(Str::contains ($juz_label, '_b')){
                                $juz_part = 'b';
                                $pure_juz = $raw_juz[0];
                                }
                                if(sizeof( $raw_juz) == 1){
                                array_push( $raw_juz, null);
                                }

                                $pas_detail_score = $siswa->getPasDetailScores($raw_juz[0], $raw_juz[1]);
                                ?>
                                <td class="has-text-centered"><?php echo e(App\Traits\Quran::getJuzLabel($juz)); ?></td>
                                <td class="has-text-centered"><?php echo e($pas_detail_score['kelancaran']); ?></td>
                                <td class="has-text-centered"><?php echo e($pas_detail_score['fashohah']); ?></td>
                                <td class="has-text-centered"><?php echo e($pas_detail_score['tajwid']); ?></td>
                                <td class="has-text-centered"><?php echo e($pas_detail_score['score']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- Catatan dan tanda tangan musyrif -->
            <div class="bottom no-break-page" style="width: 100%; margin-top:5px; font-size: 0.9em">
                <div class="columns">
                    <div class="column is-three-fifths">
                        <div class="box" style="height:100%">
                            <p class="has-text-weight-bold" >Catatan:</p>
                            <?php if($siswa->rapors->count()): ?>
                                <p style="font-size: 0.9em"><?php echo e(Arr::get($siswa->rapors[0], 'catatan')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="column has-text-centered">
                        <?php
                            $musyrif_details = $signatures['right']; //as musyrif
                        ?>
                        <p class="has-text-centered">Jakarta, <?php echo e($tanggal_cetak); ?></p>
                            <p class="has-text-weight-bold" style="margin: 0 0 -2px 0;">
                                <?php echo e($musyrif_details['as']); ?>

                            </p>
                            <div style="height: 90px;position:relative;">
                                <?php if(!is_null($musyrif_details['image'])): ?>
                                    <img style="height: 100%;"
                                        src="<?php echo e(Storage::url('signatures/' . $details['image'])); ?>" alt="">
                                    
                                <?php endif; ?>
                            </div>
                            <p><?php echo e($musyrif_details['name']); ?></p>
                                 
                    </div>
                </div>
            </div>
        </div>
</body>

</html>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/pas/cetak/show.blade.php ENDPATH**/ ?>