<?php $__env->startSection('content'); ?>
    <h1 class="title">Munaqosyah <span class="tag is-dark">Penilaian Akhir</span></h1>

    <div class="level">
        <div class="level-left">
            <form action="<?php echo e(route('admin.pas.munaqosyah.index')); ?>" method="GET">
                <div class="field">
                    <p class="control has-icons-left">
                        <input name="siswa" type="text" class="input is-rounded" placeholder="Temukan siswa...">
                        <span class="icon is-left">
                            <i class="fas fa-search"></i>
                        </span>
                    </p>
                </div>
            </form>
        </div>
        <div class="level-right">
            <div class="dropdown is-right is-hoverable">
                <div class="dropdown-trigger">
                    <button class="button is-info" aria-haspopup="true" aria-controls="dropdown-menu4">
                        <span class="icon">
                            <i class="fas fa-filter"></i>
                        </span>
                        <span>Filter By Kelas</span>
                        <span class="icon is-small">
                            <i class="fas fa-angle-down" aria-hidden="true"></i>
                        </span>
                    </button>
                </div>
                <div class="dropdown-menu" id="dropdown-menu4" role="menu">
                    <div class="dropdown-content">
                        <?php $__currentLoopData = $kelases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('admin.pas.munaqosyah.index', ['kelas' => $kelas->id])); ?>" class="dropdown-item">Kelas <?php echo e($kelas->level . $kelas->rombel); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <table class="table is-fullwidth is-vcentered">
        <thead>
            <tr>
                <th>Nama Siswa</th>
                <th>Kelas</th>
                <th>Nilai</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students->forPage(request()->get('page'), 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $level = Arr::get($kelases->where('id', $student->kelas_id)->first(), 'level');
                    $rombel = Arr::get($kelases->where('id', $student->kelas_id)->first(), 'rombel');
                    $penilaian = $scores->where('siswa_id',  $student->id)->first();
                    $score = Arr::get($penilaian, 'score', 0);
                ?>
                <tr>
                    <td><?php echo e($student->user->name); ?></td>
                    <td><?php echo e($level . $rombel); ?></td>
                    <td><?php echo e($score > 0 ? number_format($score, 2) : $score); ?></td>
                    <td class="has-text-right">
                        <a href="<?php echo e(route('admin.pas.munaqosyah.show', $student->id)); ?>" class="button is-text">
                            <i class="fas fa-list"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($pagination->appends(request()->only(['kelas', 'siswa']))->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pas/munaqosyah/index.blade.php ENDPATH**/ ?>