<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="icon" type="image/ico" href="<?php echo e(asset('img/logo.png')); ?>" />

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
      .main-content {
        left: 0;
      }

      .font-logo {
        margin: 0 auto;
        margin-bottom: 30px;
        border: solid 1px;
        border-radius: 50%;
        width: 175px;
        height: 175px;
        padding-top: 45px;
        background: #363636;
        color: #eaeaea;
      }
    </style>
    <?php echo $__env->yieldContent('extra_style'); ?>
  </head>
  <body>
    <?php echo $__env->make('partials.navbars.navbar-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
      <?php echo $__env->make('partials.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('status_script'); ?>
  </body>
</html><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>