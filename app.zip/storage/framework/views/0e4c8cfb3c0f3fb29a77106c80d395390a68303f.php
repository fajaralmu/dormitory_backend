<?php $__env->startSection('content'); ?>
    <h1 class="title">Rekapitulasi <span class="tag is-dark">Penilaian Tengah Semester</span></h1>

    <div class="tabs is-boxed is-centered">
        <ul>
            <li class="is-active">
                <a>Proges Penguji</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.pts.hasil-penilaian-siswa.index')); ?>">Hasil Penilaian Siswa</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.pts.detail-score')); ?>">Detail Nilai Siswa</a>
            </li>
            
        </ul>
    </div>

    <table class="table is-fullwidth is-vcentered">
        <thead>
            <tr>
                <th>#</th>
                <th>Penguji</th>
                <th class="has-text-centered">Siswa</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $testers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($tester->pegawai->user->name); ?></td>
                    <td class="has-text-centered"><?php echo e($tester->members->count()); ?></td>
                    <td class="has-text-right">
                        <a href="<?php echo e(route('admin.pts.progres-penguji.show', $tester)); ?>" class="button is-text">
                            <i class="fas fa-list"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pts/rekapitulasi/progres-penguji/index.blade.php ENDPATH**/ ?>