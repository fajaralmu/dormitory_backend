<?php $__env->startSection('content'); ?>
    <script type="text/javascript">
       
        const URL_EVENTS = "<?php echo e(url('/musyrif/harian')); ?>";
        const students = <?php echo json_encode($students); ?>;
        const date = new Date();
        const schoolList = <?php echo json_encode($schools); ?>; 
        const eventItemData = {
            id: 0,
            sekolah_id: null,
            day: date.getDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear(),
            description: "",
            active: true,
            populate: function(event) {
                this.id = event.id;
                this.sekolah_id = event.sekolah_id;
                this.day = event.day;
                this.month = event.month;
                this.year = event.year;
                this.description = event.description;
                this.active = event.active;
            },
            setDefault: function() {
                this.id = 0;
                this.description = "";
                this.active = true;
            }

        };
        var selectedMonth = eventItemData.month;
        var selectedYear = eventItemData.year;
        var selectedStudentId =  null;

        function getSchoolById(id) {
            for (let i = 0; i < schoolList.length; i++) {
                const school = schoolList[i];
                if (school.id == id) {
                    return school;
                }
            }
            return null;
        }

        function getStudentById(id){
            for (let i = 0; i < students.length; i++) {
                if(id == students[i].id) {
                    return students[i];
                }
                
            }
            return null;
        }
    </script>
    <?php if(sizeof($students) > 0): ?>
        <script type="text/javascript">
            this.selectedStudentId = "<?php echo e($students[0]->id); ?>";
            
        </script>
    <?php endif; ?>
    <h1 class="title">Harian Halaqoh <?php echo e($halaqoh->nama); ?></h1>
    <div>
        <?php $__env->startComponent('components.card', ['title' => 'Options']); ?>
        <div class="columns">
            <form class="column" onsubmit="return false;">
                <div class="fields">
                    <div class="field">
                        <label class="label">Sekolah</label>
                        <div class="select"><select id="select-school" disabled>
                                <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option level="<?php echo e($school->jenjang); ?>" value="<?php echo e($school->id); ?>"><?php echo e($school->nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></div>
                    </div>
                    <div class="field">
                        <label class="label">Siswa</label>
                        <div class="select"><select autocomplete="off" id="select-student" >
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option school="<?php echo e($student->sekolah_id); ?>" value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?> - <?php echo e($student->sekolah_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></div>
                    </div>
                    
                    
                </div>
            </form>
            <div class="column">
                <article class="message is-link">
                    <div class="message-header"><p>Info</p></div>
                    <div class="message-body" id="info">Assalamu Alaikumn</div>
                </article>
            </div>
        </div>
        <?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('components.card', ['title' => 'Events Calendar']); ?>
        <div id="calendar-wrapper">
            <form id="calendar-navigation-form">
                <table class="table is-borderless" style="width: 100%" id="cal-input-fields">
                </table>
            </form>
            <table class="table" style="width: 100%" id="calendarTable">
                <tr><th>Please Wait....</th></tr>
            </table>
        </div>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.card', ['title' => 'Detail: Silakan Pilih Tanggal', 'id'=>'detail']); ?>
        <div class="columns">
            <form class="column is-two-third" onsubmit="return false;" id="events-form">
                <div class="field">
                    <label class="label">Hari Aktif</label>
                    <div class="control">
                        <input disabled id="events-active" type="radio" name="events-active" checked/><!--
                        --><label for="events-active" >Ya</label><!--
                        --><input disabled id="events-non-active" type="radio" name="events-active"/><!--
                        --><label for="events-non-active">Tidak</label>         
                </div>
                </div>
                <div class="field">
                    <label class="label">Keterangan Agenda</label>
                    <textarea disabled autocomplete="false" class="textarea" id="events-description" placeholder="Keterangan"
                        rows="2"></textarea>
                </div>
                
            </form>
            <div class="column is-one-third">
                <div class="field">
                    <label class="label">Keterangan Kalender<label>
                </div>
                <div class="box" style="background-color: rgb(100,200,0); padding:10px"><label>Hari Aktif</label></div>
                <div class="box" style="background-color: rgb(250,130,30); padding:10px"><label>Hari Non Aktif</label></div>
                <div class="box" style="background-color: #ffffff; padding:10px"><label>Belum Ada Data<label></div>
            </div>
        </div>
        <?php echo $__env->renderComponent(); ?>
    </div>
    <script type="text/javascript">
        const eventActiveToggleRadios = document.getElementsByName("events-active");
        const eventDescriptionTextarea = byId("events-description");
        const selectSchool = byId("select-school"), selectStudent = byId("select-student");
        const info = byId("info");
        const eventActiveRadio = byId("events-active");
        const eventInActiveRadio = byId("events-non-active");
        const formCardTitle = byId("card-header-detail");

        for (let i = 0; i < eventActiveToggleRadios.length; i++) {
            const radio = eventActiveToggleRadios[i];
            radio.onchange = function(e) {
                eventItemData.active = e.target.checked && e.target.id == "events-active";
            }
        }
        eventDescriptionTextarea.onkeyup = function(e) {
            eventItemData.description = e.target.value;
        }
        eventDescriptionTextarea.value = null;
        selectSchool.onchange = function(e) {
            updateSchool(e.target.value);
        }
        selectStudent.onchange = function(e){
            try{
                selectedStudentId = e.target.value;
                const options = e.target.options;
                const selectedOption = options[e.target.selectedIndex];
                const schoolId = selectedOption.getAttribute("school");
                selectSchool.value = schoolId;
                updateSchool(schoolId);
            }catch(e){
                alert("Failed adjusting school: "+e);
            }
        }
        //initial values
        eventItemData.sekolah_id = selectStudent.options[selectStudent.selectedIndex].getAttribute("school");
        selectSchool.value = eventItemData.sekolah_id;
        let selectedSchool = getSchoolById(eventItemData.sekolah_id);

    </script>
    <!-- CALENDAR CALLBACKS -->
    <script type="text/javascript">
        addOnloadHandler(loadCalendar);
        
        //when detail BUTTON is clicked
        function dateItemClickedCallback(day, month, year) {
            if (day == null || month == null || year == null) {
                return;
            }

            setFormTitle(day, month, year, null);
            setEventItemData(day, month, year);

        };

        //when one month calendar loaded
        function monthDataLoadedCallback(month, year) {
            this.selectedMonth = month;
            this.selectedYear = year;
            loadEvents();
        }

    </script>
    <script type="text/javascript">

        function updateSchool(id) {
            console.info("School id: ", id);
            eventItemData.sekolah_id = id;
            selectedSchool = getSchoolById(id);
            loadEvents();
        }
        
        function setFormTitle(day, month, year, additional) {
            const monthName = MONTHS[month - 1].name;
            additional = additional != null ? additional : "";
            formCardTitle.innerHTML = "Detail: " + day + " " + monthName + " " + year + " " + (selectedSchool==null?"": selectedSchool.nama) + " " +
                additional;
        }

        function fillDateItem(d, m, y) {
            const element = createHtml("div", "");
            element.id = "detail-date-element-"+d+"-"+m;
            element.className = "detail-date-element";
            return element;
        };

        function setEventItemData(day, month, year) {
            eventItemData.day = day;
            eventItemData.month = month;
            eventItemData.year = year;
            eventItemData.setDefault();

            populateDetailEventInputs(eventItemData);

            loadEventsByDayAndMonth(day, month);
        }

        function populateDetailEventInputs(eventItemData) {

            eventDescriptionTextarea.value = eventItemData.description;
            eventActiveRadio.checked = eventItemData.active == true;
            eventInActiveRadio.checked = eventItemData.active == false;
        }
        
        function populateDetailEvent(response) {
            const eventItemDataList = response.eventItemDataList;
            if ((eventItemDataList == null || 0 == eventItemDataList.length) &&
                response.eventItemData == null) {
                formCardTitle.innerHTML += ' (Belum ada data)';
                return;
            }
            const loadedEventItemData = response.eventItemData != null ? response.eventItemData : eventItemDataList[0];
            eventItemData.populate(loadedEventItemData);
            populateDetailEventInputs(eventItemData);

            setFormTitle(loadedEventItemData.day, loadedEventItemData.month, loadedEventItemData.year, " (Record id: " +
                loadedEventItemData.id + ")");

            const selectedStudent = getStudentById(selectedStudentId);
            if (loadedEventItemData.active && null != selectedStudent) {
                const monthName = MONTHS[loadedEventItemData.month - 1].name;
                const stringDate = loadedEventItemData.day+" "+ monthName+ " "+loadedEventItemData.year;
                confirmDialog("Isi data siswa "+selectedStudent.name+" tanggal "+stringDate+"?")
                .then(function(ok){
                    if(ok){
                        const dateQueryString = "day="+loadedEventItemData.day+"&month="+loadedEventItemData.month+"&year="+loadedEventItemData.year;
                        openInNewTab(URL_EVENTS+"/"+selectedStudentId+"/edit?"+dateQueryString);
                    }
                });
            }
        }

        function populateCalendar(response) {
            clearDateElement();
            const eventItemDataList = response.eventItemDataList;
            if (null == eventItemDataList) {
                return;
            }
            info.innerHTML = "Total Events Current Month: " + eventItemDataList.length;
            for (let i = 0; i < eventItemDataList.length; i++) {
                const element = eventItemDataList[i];
                updateButtonInDateElement(element);
            }

            const dailyActivityList = response.dailyActivityList;
            if (null == dailyActivityList) {
                return;
            }
            for (let i = 0; i < dailyActivityList.length; i++) {
                const dailyActivity = dailyActivityList[i];
                populateDateItemWithActivityData(dailyActivity);
            }
        }

        function populateDateItemWithActivityData(dailyActivity) {
            const day = dailyActivity.day;
            const month = dailyActivity.month;
            const detailElement = byId("detail-date-element-"+day+"-"+month);
            detailElement.appendChild(createHtml("p", "<i class=\"fas fa-check-circle\"></i>&nbsp;"+ dailyActivity.time));
        }

        function updateButtonInDateElement(eventItemData) {
            console.debug("populateDateItem: ", eventItemData);
            const month = eventItemData.month;
            const day = eventItemData.day;
            const active = eventItemData.active;
            const element = byId("date-" + day + "-" + month);
            if (element == null) {
                return;
            }
            const detailButton = byId("button-detail-" + day + "-" + month);
          //  detailButton.innerHTML = "<i class=\"fas fa-ellipsis-v\"></i>"
            element.style.backgroundColor = active ? COLOR_ACTIVE : COLOR_INACTIVE;
        }

        populateDetailEventInputs(eventItemData);

    </script>
    <!-- AJAX CALLS -->
    <script type="text/javascript"> 
       
        function loadEvents() {
            startLoading();
            const schoolId = selectedSchool.id;
            const month = selectedMonth;
            const year = selectedYear;
            axios.get(URL_EVENTS + "/" + schoolId + "?filter=true&month=" + month + "&year=" + year+"&siswa_id="+selectedStudentId)
                .then(function(response) {
                    const payload = response.data;
                    populateCalendar(payload);
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);

        }

        function loadEventsByDayAndMonth(day, month) {
            startLoading();
            const schoolId = selectedSchool.id;
            axios.get(URL_EVENTS + "/" + schoolId + "?filter=true&month=" + month + "&day=" + day+"&year="+selectedYear)
                .then(function(response) {
                    const payload = response.data;
                    populateDetailEvent(payload);
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);

        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/events/index.blade.php ENDPATH**/ ?>