<?php
    $semester = config('school.semester');
    $juz_map = Arr::get($configuration->settings, 'pemetaan_juz_ujian');
    $global_basic = Arr::get($configuration->settings, 'global_basic', []);
    $total_examined = 0;
    $total_target = 0;
?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Siswa PTS</h1>

    <?php if($tester->members->count()): ?>
        <div class="level">
            <div class="level-left"></div>
            <div class="level-right">
                <div class="tags has-addons are-medium">
                    <span class="tag is-dark">Total target</span>
                    <span id="total-target" class="tag is-info">0</span>
                    <span class="tag is-dark">Total diuji</span>
                    <span id="total-examined" class="tag is-info">0</span>
            </div>
            </div>
        </div>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>Nama Siswa</th>
                    <th>Kelas</th>
                    <th class="is-hidden-mobile">Musyrif</th>
                    <th>Kategori</th>
                    <th class="has-text-centered">Target</th>
                    <th class="has-text-centered">Diuji</th>
                    <th class="has-text-centered">Diselesaikan</th>
                    <th class="has-text-centered">Nilai Akhir</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tester->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $hm = array_get($hms, $member->siswa->id);
                        // $path = $hm->level . '.' . $member->siswa->kelas->level . '.' . $semester;
                        // $target = count(array_get($juz_map, $path, []));

                        // if ($hm->level === 'basic') {
                        //     $global_basic_for_level = [7, 8, 10, 11];

                        //     if (in_array($member->siswa->kelas->level, $global_basic_for_level)) {
                        //         $targets = Arr::get($global_basic, $member->siswa->kelas->level . '.' . $semester);
                        //         $target = count($targets);
                        //     } else {
                        //         $target = array_get($hm->targets->first(), 'total_juz', 0);
                        //     }
                        // }
                    ?>
                    <tr>
                        <td><?php echo e($member->siswa->user->name); ?></td>
                        <td><?php echo e(Arr::get($member->siswa->kelas, 'level') . Arr::get($member->siswa->kelas, 'rombel')); ?></td>
                        <td class="is-hidden-mobile"><?php echo e(!is_null($hm) ? $hm->halaqoh->pegawai->user->name : '-'); ?></td>
                        <td>
                            <span class="tag is-dark"><?php echo e(Arr::get($hm, 'level')); ?></span>
                        </td>
                        <td class="has-text-centered"><?php echo e($member->siswa->getPtsTarget()); ?></td>
                        <td class="has-text-centered"><?php echo e($member->siswa->getPtsExamined()); ?></td>
                        <td class="has-text-centered"><?php echo e($member->siswa->getPtsFinished()); ?></td>
                        <td class="has-text-centered"><?php echo e(number_format($member->siswa->pts_final_score, 2)); ?></td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('tester.pts.students.show', $member->siswa)); ?>" class="button is-text has-text-dark">
                                <i class="fas fa-list"></i>
                            </a>
                        </td>
                    </tr>
                    <?php
                        $total_target+=$member->siswa->getPtsTarget();
                        $total_examined+=$member->siswa->getPtsExamined();
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table> 
        <script text="text/javascript">
            document.getElementById("total-target").innerHTML = <?php echo e($total_target); ?>;
            document.getElementById("total-examined").innerHTML = <?php echo e($total_examined); ?>;
        </script>
    <?php else: ?>
        <div class="notification is-warning">
            <span class="icon">
                <i class="fas fa-info-circle"></i>
            </span>
            <span>No member yet!</span>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/tester/pts/students/index.blade.php ENDPATH**/ ?>