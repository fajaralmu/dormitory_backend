<?php $__env->startSection('content'); ?>
    <script type="text/javascript">
        const months = <?php echo json_encode(App\Utils\DateUtil::$MONTH_NAMES); ?>;
        
    </script>
    
    <h1 class="title">Laporan Mutabaah Halaqoh <?php echo e($halaqoh->nama); ?></h1>
    <?php $__env->startComponent('components.card', ['title' => 'Filter']); ?>
    <form onsubmit="loadData(event)">
        
        <?php $__env->startComponent('components.selectperiod', ['label'=>'Dari Periode', 'names' => ['day', 'month', 'year']]); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.selectperiod', ['label'=>'Sampai Periode', 'names' => ['dayTo', 'monthTo', 'yearTo']]); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.inputhorizontal', ["label"=>null]); ?>
            <button type="submit" class="button is-success" >
                <span class="icon"><i class="fas fa-play-circle"></i></span>
                <span>Submit</span>
            </button>
            <a href="<?php echo e(url('musyrif/mutabaah')); ?>" class="button is-link"><span class="icon"><i class="fas fa-arrow-circle-left"></i></span><span>Kembali</span></a>
            <a href="<?php echo e(url('musyrif/mutabaah/laporandetail/')); ?>" class="button is-link"><span class="icon"><i class="fas fa-list"></i></span><span>Detail per Siswa</span></a>
            
        <?php echo $__env->renderComponent(); ?>
    </form>
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.card', ['title'=>'Record List']); ?>
    <div style="overflow: scroll">
        <table class="table is-bordered is-striped"   >
            <thead >
                <tr>
                    <th rowspan="2">No</th>
                    <th rowspan="2">Nama</th>
                    <th colspan="4" >Kehadiran</th>
                    <th rowspan="2">Tidak Pembukaan</th>
                    <th rowspan="2">Tidak Penutupan</th>
                    <th rowspan="2">Tidak Setoran</th>
                   
                    <th rowspan="2">Di Luar Area</th>
                    <th rowspan="2">Tidak Berseragam</th>
                    <th rowspan="2">Bercanda</th>
                    <th rowspan="2">Pelanggaran Adab</th>
                    <th rowspan="2">Tidur</th>
                    <th rowspan="2">Bermain Gadget</th>
                    <th rowspan="2">Melakukan Kecurangan</th>
                    <th  >TOTAL POINT</th>
                </tr>
                <tr>
                    <th>Hadir</th>
                    <th>Izin</th>
                    <th>Sakit</th>
                    <th>Alpa</th>
                </tr>
            </thead>
            <tbody >
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td style="font-size:0.7em"><?php echo e($student->name); ?> - <?php echo e($student->level); ?><?php echo e($student->rombel); ?></td>
                        
                        <td id="presence_h-<?php echo e($student->id); ?>"></td>
                        <td id="presence_i-<?php echo e($student->id); ?>"></td>
                        <td id="presence_s-<?php echo e($student->id); ?>"></td>
                        <td id="presence_a-<?php echo e($student->id); ?>"></td>

                        <td id="not_opening-<?php echo e($student->id); ?>"></td>
                        <td id="not_closing-<?php echo e($student->id); ?>"></td>
                        <td id="not_recited-<?php echo e($student->id); ?>"></td>
                       
                        <td id="rule_break_area-<?php echo e($student->id); ?>"></td>
                        <td id="rule_break_dresscode-<?php echo e($student->id); ?>"></td>
                        <td id="rule_break_joke-<?php echo e($student->id); ?>"></td>
                        <td id="rule_break_attitude-<?php echo e($student->id); ?>"></td>
                        <td id="rule_break_sleep-<?php echo e($student->id); ?>"></td>
                        <td id="rule_break_play_gadget-<?php echo e($student->id); ?>"></td>
                        <td id="rule_break_cheat-<?php echo e($student->id); ?>"></td>

                        <td id="TOTAL_POINT-<?php echo e($student->id); ?>"></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo $__env->renderComponent(); ?>
     
    <script type="text/javascript">
    //thead and tbody is declared in daily_activities_summary.js
        thead = document.getElementById("list-thead");
        tbody = document.getElementById("list-tbody");
        const URL_REPORT = "<?php echo e(url('/musyrif/mutabaah/laporan/')); ?>";
        function loadData(e) {
            startLoading();
            e.preventDefault();
            const formData = new FormData(e.target);
            const request = { filter: {} };
            for (var pair of formData.entries()) {
                request.filter[pair[0]]  =  pair[1];
            }
            
            axios.post(URL_REPORT, request)
            .then(function(response) {
                populateData(response.data);
            }).catch(function(e){
                alert("Operation failed: "+e);
            }).finally(stopLoading)
        } 


        function populateData(response) {
            const summaries = response.dailyActivitySummaryList;
            const summaryPoint = response.dailyActivitySummary;
            if (null == summaries || summaries.length == 0) return;
            for (let i = 0; i < summaries.length; i++) {
                const summary = summaries[i];
                const studentId = summary.student.id;
                const point = calculatePoint(summary, summaryPoint);
                for (const key in summary) {
                    if (Object.hasOwnProperty.call(summary, key)) {
                        const value = summary[key]; 
                        const cell = byId(key+"-"+studentId);
                        if (cell) {
                            cell.innerHTML = value;
                        }
                    }
                }
                summary['point'] = point;
                byId('TOTAL_POINT-'+studentId).innerHTML = '<strong>'+point+'</strong>';
            }
            // console.debug("SUMMARIES: ", summaries);
        }

        function calculatePoint(summary, summaryPoint) {
            let point = 0;
            for (const key in summary) {
                if (Object.hasOwnProperty.call(summary, key)) {
                    const element = summary[key];
                    if (element && summaryPoint[key]) {
                        point += (summaryPoint[key] * element)
                    }
                }
            }
            return point;
        }
       

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/dailyactivitiesv2/laporan.blade.php ENDPATH**/ ?>