<?php $__env->startSection('content'); ?>
    <h1 class="title">Detail Penilaian Harian</h1>
    
    <article class="message is-link">
        <div class="message-header"><p><?php echo e($student->user->name); ?></p></div>
        <div class="message-body" id="info">
            <p>Waktu <?php echo e(strtoupper($dailyActivity->time)); ?></p>
            <p>Tanggal <?php echo e($date_str); ?></p>
            <a style="margin-top:20px" class="button is-link" href="<?php echo e(route('admin.laporan-harian.index')); ?>" ><i class="fas fa-arrow-circle-left"></i>&nbsp;&nbsp;Kembali</a>
        </div>
    </article>
    <?php $__env->startComponent('components.card', ['title'=>'Formulir']); ?>
        <div>
            <?php echo $form; ?>

        <div>
    <?php echo $__env->renderComponent(); ?>

    <script type="text/javascript">
        
        const inputs = document.getElementsByTagName("input");
        const textareas = document.getElementsByTagName("textarea");
        const selects = document.getElementsByTagName("select");

        
       function disableFields(inputs) {
           try {
                for (let i = 0; i < inputs.length; i++) {
                    inputs[i].setAttribute("disabled", "disabled");
                }
           } catch (e) {

           }
       }
       disableFields(inputs);
       disableFields(textareas);
       disableFields(selects);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/harian/edit.blade.php ENDPATH**/ ?>