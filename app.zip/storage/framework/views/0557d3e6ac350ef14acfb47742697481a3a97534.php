<nav class="pagination is-centered">
    <ul class="pagination-list">
        <?php $__currentLoopData = $navigation_button_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navigation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php if($navigation == $current_page): ?>
                        <a class="pagination-link is-current"><?php echo e($navigation); ?></a>
                    <?php else: ?> 
                        <?php
                           $link = route($route);
                           $filters = [];
                           foreach ($request_params as $param) {
                                if(request()->has($param)){
                                array_push($filters, $param.'='. request()->get($param));
                                }
                           }

                           array_push($filters, 'page='. $navigation);
                           $requestParams = join('&', $filters);
                        ?>
                        <a href="<?php echo e($link); ?>?<?php echo e($requestParams); ?>" class="pagination-link"><?php echo e($navigation); ?></a>
                    <?php endif; ?>
                    
                </li> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/components/tahfizpagination.blade.php ENDPATH**/ ?>