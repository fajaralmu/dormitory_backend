<?php $__env->startSection('content'); ?>
    <h1 class="title">Settings <span class="tag is-dark">Umum</span></h1>
    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.settings.stamp.index')); ?>" class="button is-outlined is-dark">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks Sekolah</span>
            </a>
        </div>
    </div>
    <div class="columns">
        <div class="column">
            <?php $__env->startComponent('components.card', ['title' => 'Unggah Stempel '.$school->nama]); ?>
                <?php echo $form; ?>

            <?php echo $__env->renderComponent(); ?>
        </div>
        <?php if(! is_null($stempel)): ?>
        
            <div class="column has-text-centered">
                <?php $__env->startComponent('components.card', ['title' => 'Preview Stempel']); ?>
                <img src="<?php echo e(Storage::url('stamps/' . $stempel)); ?>" alt="">
                <?php echo $__env->renderComponent(); ?>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/settings/stamp/edit.blade.php ENDPATH**/ ?>