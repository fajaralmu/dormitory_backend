<nav class="navbar is-dark is-fixed-top" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
        <a target="_blank" class="navbar-item" href="/home">
            <span class="icon">
                <i class="fas fa-quran"></i>
            </span>
            <span class="has-text-weight-bold">Tahfiz Application</span>
        </a>
        <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
        </a>
    </div>
    <div id="navbarBasicExample" class="navbar-menu">
        <div class="navbar-start"></div>

        <div class="navbar-end">
            <div class="navbar-item">
                <div class="buttons">
                    <a class="button">
                        <span class="icon">
                            <i class="far fa-user-circle"></i>
                        </span>
                        <span><?php echo e(Auth::user()->name); ?></span>
                    </a>
                    <a class="button is-danger is-rounded" onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                        <span class="icon">
                            <i class="fas fa-sign-out-alt"></i>
                        </span>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</nav><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/tester/pts/students/penilaian/navbar.blade.php ENDPATH**/ ?>