<?php
    $semester = config('school.semester');
    $halaqoh_membership = $student->halaqohs->first();
    $musyrif = is_null($halaqoh_membership)? '' : $halaqoh_membership->halaqoh->pegawai->user->name;
    $kategori = Arr::get($halaqoh_membership, 'level');
    $kelas = is_null($student->kelas) ? new App\Models\Kelas() : $student->kelas;

    // $global_basic = Arr::get($settings, 'global_basic');

    // if ($kategori === 'basic') {
    //     $global_basic_for_level = [7, 8, 10, 11]; // TODO: move this to config

    //     if (in_array($kelas->level, $global_basic_for_level)) {
    //         $targets = Arr::get($global_basic, $kelas->level . '.' . $semester);
    //     } else {
    //         $targets = Arr::get($halaqoh_membership->targets->first(), 'peta_juz', []);
    //     }
    // } else {
    //     $targets = Arr::get($settings, 'pemetaan_juz_ujian.' . $kategori . '.' . $kelas->level . '.' . $semester, []);
    // }

    // $student->pts_accumulations->sum('score') / count($targets);
?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Rekapitulasi <span class="tag is-dark">Penilaian Tengah Semester</span></h1>

    <div class="tabs is-boxed is-centered">
        <ul>
            <li>
                <a href="<?php echo e(route('admin.pts.progres-penguji.index')); ?>">Proges Penguji</a>
            </li>
            <li class="is-active">
                <a>Hasil Penilaian Siswa</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.pts.detail-score')); ?>">Detail Nilai Siswa</a>
            </li>
        </ul>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.pts.hasil-penilaian-siswa.index')); ?>" class="button is-outlined is-primary">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks</span>
            </a>
        </div>
    </div>

    <div class="box">
        <h4 class="title is-4"><?php echo e($student->user->name); ?></h4>
        <div class="content">
            <ul>
                <?php
                    $tester_name = "undefined";
                    try{
                        $tester = $student->pts_memberships->first()->penguji_pts;  
                        $tester_name = $tester->pegawai->user->name;
                    }catch(Throwable $th){ }

                ?>
                <li>Kelas: <?php echo e(Arr::get($kelas, 'level') . Arr::get($kelas, 'rombel')); ?></li>
                <li>Musyrif: <?php echo e($musyrif); ?></li>
                <li>Kategori: <?php echo e($kategori); ?></li>
                <li>Target: <?php echo e($student->getPtsTarget()); ?></li>
                <li>Penguji: <?php echo e($tester_name); ?></li>
            </ul>
        </div>

        <div class="tags has-addons are-medium">
            <span class="tag is-dark">Nilai Akhir</span>
            <span class="tag is-info"><?php echo e(number_format($nilai_akhir, 2)); ?></span>
        </div>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'Score Juz']); ?>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>Juz</th>
                    <th class="has-text-centered">Kelancaran</th>
                    <th class="has-text-centered">Fashohah</th>
                    <th class="has-text-centered">Tajwid</th>
                    <th class="has-text-centered">Score</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $juz_part = null;

                        $juz_label = (string) $juz;
                        $pure_juz = $juz;
                        $raw_juz = explode( '_', $juz_label);

                        if(Str::contains ($juz_label, '_a')){ 
                            $juz_part = 'a';
                            $pure_juz =  $raw_juz[0];
                        }
                        elseif(Str::contains ($juz_label, '_b')){ 
                            $juz_part = 'b';
                            $pure_juz =  $raw_juz[0];
                        }
                        if(sizeof( $raw_juz) == 1){
                            array_push( $raw_juz, null);
                        }
                        $pts_detail_score = $student->getPtsDetailScores($raw_juz[0], $raw_juz[1]);  
                    ?>
                    <tr>
                        <td><?php echo e(App\Traits\Quran::getJuzLabel($juz)); ?></td>
                        <td class="has-text-centered"><?php echo e($pts_detail_score['kelancaran']); ?></td>  
                        <td class="has-text-centered"><?php echo e($pts_detail_score['fashohah']); ?></td> 
                        <td class="has-text-centered"><?php echo e($pts_detail_score['tajwid']); ?></td>      
                        <td class="has-text-centered"><?php echo e(($pts_detail_score['score'])); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pts/rekapitulasi/hasil-penilaian-siswa/show.blade.php ENDPATH**/ ?>