<div>
    <div>
        <button class="button is-info" wire:click="switchDisplay('card' )">Card</button>
        <button class="button is-info" wire:click="switchDisplay('table' )">Table</button>
    </div>
    
    <?php if(isset($listDisplay) && $listDisplay == 'card'): ?>
    <div class="columns is-multiline">
        <?php $__currentLoopData = $halaqohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column is-one-third">
                <div class="card">
                    <header class="card-header">
                    </header>
                    <div class="card-content" style="text-align: center">
                        <div class="card-image has-text-centered">
                            <img width="200" height="100"
                                src="<?php echo e(asset('img/quran.png')); ?>" />
                        </div>
                        <h3 style="margin-bottom:0px; margin-top:7px" class="title is-5">Halaqah <?php echo e($halaqoh->nama); ?></h3>
                        <p style="margin-bottom:10px"><?php echo e($halaqoh->pegawai->user->name); ?></p>
                        <p align="center" ><span class="tag">Jumlah Siswa </span><span class="tag is-primary"><?php echo e($halaqoh->members_count); ?></span></p> 

                    </div>
                    <footer class="card-footer" style="display: grid; grid-template-columns: 25% 25% 25% 25%">
                        <a href="<?php echo e(route('admin.halaqoh.signature.index', $halaqoh)); ?>" class="button is-text">
                            <i class="fas fa-stamp"></i>
                        </a>
                        <a href="<?php echo e(route('admin.halaqoh.members.index', $halaqoh)); ?>" class="button is-text">
                            <i class="fas fa-list"></i>
                        </a>
                        <a href="<?php echo e(route('admin.halaqoh.edit', $halaqoh)); ?>"
                            class="button is-text has-text-primary">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button class="button is-text has-text-danger">
                            <i class="fas fa-trash"></i>
                        </button>
                    </footer>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Musyrif</th>
                    <th>Nama Halaqoh</th>
                    <th class="has-text-centered">Anggota</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $halaqohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($halaqoh->pegawai->user->name); ?></td>
                        <td><?php echo e($halaqoh->nama); ?></td>
                        <td class="has-text-centered"><?php echo e($halaqoh->members_count); ?></td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('admin.halaqoh.signature.index', $halaqoh)); ?>" class="button is-text">
                                <i class="fas fa-stamp"></i>
                            </a>
                            <a href="<?php echo e(route('admin.halaqoh.members.index', $halaqoh)); ?>" class="button is-text">
                                <i class="fas fa-list"></i>
                            </a>
                            <a href="<?php echo e(route('admin.halaqoh.edit', $halaqoh)); ?>"
                                class="button is-text has-text-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php echo $__env->make('components.delete-button', ['url' => route('admin.halaqoh.destroy', $halaqoh)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/livewire/index-halaqoh-display.blade.php ENDPATH**/ ?>