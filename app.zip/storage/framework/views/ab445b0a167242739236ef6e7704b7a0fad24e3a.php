<?php $__env->startSection('content'); ?>
    <h1 class="title">Halaqoh <span class="tag is-dark">Members</span></h1>

    <div class="box">
        <h4 class="title is-4"><?php echo e($halaqoh->nama); ?> <span class="has-text-info has-text-weight-light is-size-5">(Ust. <?php echo e($halaqoh->pegawai->user->name); ?>)</span></h4>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.halaqoh.members.create', $halaqoh)); ?>" class="button is-primary is-rounded">
                <span class="icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span>New Halaqoh Member</span>
            </a>
        </div>
    </div>

    <?php if($halaqoh->members->count()): ?>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Siswa</th>
                    <th>Sekolah</th>
                    <th>Kelas</th>
                    <th class="has-text-centered">Kategori</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $halaqoh->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $kelas = "";
                        $sekolah = null;
                        if (!is_null($member->siswa->kelas)) { 
                            $sekolah = $schools->where('id', $member->siswa->kelas->sekolah_id)->first();
                            if(!is_null($sekolah)){
                                $jurusan = config('school.pilihan_jurusan.' . $member->siswa->kelas->jurusan);
                                $kelas = $member->siswa->kelas->level . $member->siswa->kelas->rombel;

                                if ($sekolah->jenjang === 'menengah_atas') {
                                    $kelas .= ' (' . $jurusan . ')';
                                }
                            }
                        }
                    ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($member->siswa->user->name); ?></td>
                        <td><?php echo e(Arr::get($sekolah, 'nama')); ?></td>
                        <td><?php echo e($kelas); ?></td>
                        <td class="has-text-centered"><span class="tag is-dark"><?php echo e($member->level); ?></span></td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('admin.halaqoh.members.edit', [$halaqoh, $member])); ?>" class="button is-text has-text-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php echo $__env->make('components.delete-button', ['url' => route('admin.halaqoh.members.destroy',  [$halaqoh, $member])], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                             
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="notification is-warning">
            No members yet.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/halaqoh/members/index.blade.php ENDPATH**/ ?>