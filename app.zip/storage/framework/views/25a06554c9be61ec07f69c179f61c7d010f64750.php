
 <?php $__env->startComponent('components.card', ['title'=> 'Pilih Waktu' ]); ?>
    <div>
        <form method="GET" action="<?php echo e(url('/musyrif/harianv2/mutabaah/edit')); ?>">
            
            <div class="fields">
            <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Halaqoh"]); ?>
                <?php echo e($halaqoh->nama); ?>

            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Periode"]); ?>
            <div class="field is-grouped">
                <p class="control select">
                    <select autocomplete="off" name="day" class="select">
                        <?php for($i = 1; $i <= 31; $i++): ?>
                            <?php if($i == request()->get('day')): ?>
                                <option selected value=<?php echo e($i); ?>><?php echo e($i); ?></option>
                            <?php else: ?>
                                <option value=<?php echo e($i); ?>><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                </p>
                <p class="control select">
                    <select autocomplete="off"  name="month" class="select">
                        <?php $__currentLoopData = App\Utils\DateUtil::$MONTH_NAMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(($loop->index + 1) == request()->get('month')): ?>
                                <option selected value=<?php echo e($loop->index + 1); ?>><?php echo e($month); ?></option>
                            <?php else: ?>
                                <option value=<?php echo e($loop->index + 1); ?>><?php echo e($month); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </p>
                <p class="control">
                <input type="number" class="input" name="year" value="<?php echo e(request()->get('year')); ?>" />
                </p>
            </div>
            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Waktu"]); ?>
                <div class="select"><select class="select" id="select-time" name="time">
                        <option value="morning">Pagi</option>
                        <option value="afternoon">Sore</option>
                    </select>
                </div>
            <?php echo $__env->renderComponent(); ?>
           
            <div class="field is-horizontal">
                <div class="field-label">
                    <a class="button is-link" href="<?php echo e(route('musyrif.harianv2.index')); ?>" ><i class="fas fa-arrow-circle-left"></i>&nbsp;&nbsp;Kembali</a>
                </div>
                <div class="field-body buttons has-addons">
                    <input value="Pilih Waktu" type="submit" class="button is-dark" />
                </div>
            </div>
            </div>
        </form>
    </div>
    <?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/dailyactivitiesv2/select-time.blade.php ENDPATH**/ ?>