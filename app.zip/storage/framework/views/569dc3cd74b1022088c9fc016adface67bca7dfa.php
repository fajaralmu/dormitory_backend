<?php
    $choices = Arr::get($options, 'choices', []);
    $input_name = count($choices) > 1 ? $name . '[]' : $name;

    $selected = old($name, Arr::get($options, 'selected'));

    // when user does not choose any of choices
    if ($errors->has($name)) {
        $selected = null;
    }
?>

<?php if($orientation == 'horizontal'): ?>
    <div class="field is-horizontal">
        <div class="field-label">
            <?php if(! Arr::has($options, 'no_label')): ?>
                <label class="label"><?php echo e(title_case(str_replace('_', ' ', $name))); ?></label>
            <?php endif; ?>
        </div>
        <div class="field-body">
            <div class="field is-narrow">
                <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="control">
                        <label class="checkbox">
                            <?php if(Arr::has($options, 'no_value')): ?>
                                <input type="checkbox" name="<?php echo e($input_name); ?>">
                            <?php else: ?>
                                <input type="checkbox" name="<?php echo e($input_name); ?>" value="<?php echo e($value); ?>" <?php echo e(checked_status($value, $selected)); ?>>
                            <?php endif; ?>
                            <?php echo e($label); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($errors->has($name)): ?>
                    <p class="help is-danger">
                       <?php echo e($errors->first($name)); ?>

                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="field">
        <?php if(! Arr::has($options, 'no_label')): ?>
            <label class="label"><?php echo e(title_case(str_replace('_', ' ', $name))); ?></label>
        <?php endif; ?>
        <div class="control">
            <div class="field">
                <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="control">
                        <label class="checkbox">
                            <?php if(Arr::has($options, 'no_value')): ?>
                                <input type="checkbox" name="<?php echo e($input_name); ?>">
                            <?php else: ?>
                                <input type="checkbox" name="<?php echo e($input_name); ?>" value="<?php echo e($value); ?>" <?php echo e(checked_status($value, $selected)); ?>>
                            <?php endif; ?>
                            <?php echo e($label); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php if($errors->has($name)): ?>
            <p class="help is-danger">
               <?php echo e($errors->first($name)); ?>

            </p>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\vendor\realcahsowan\laravel-bulma-form\src/../resources/views/checkbox.blade.php ENDPATH**/ ?>