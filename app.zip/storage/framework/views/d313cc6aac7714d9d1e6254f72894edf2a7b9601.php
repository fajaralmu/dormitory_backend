<?php
    $route = route('musyrif.penilaian-periodik.hasil.store', $siswa);
?>

<?php $__env->startSection('detail'); ?>
    <h1 class="title">Hasil Penilaian Periodik</h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light"><?php echo e($siswa->user->name); ?></h4>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('musyrif.penilaian-periodik.hasil.index', $siswa)); ?>" class="button is-outlined is-primary">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks Hasil</span>
            </a>
        </div>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'Penilaian Periodik Baru']); ?>
        <?php if($errors->any()): ?>
            <div class="notification is-danger">Please fill the form correctly.</div>
        <?php endif; ?>
        <?php if($is_fullday): ?>
            <?php echo $__env->make('musyrif.penilaian-periodik.hasil.form_fullday', ['route' => $route, 'hasil' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?> 
            <?php echo $__env->make('musyrif.penilaian-periodik.hasil.form', ['route' => $route, 'hasil' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php endif; ?>
       
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/penilaian-periodik/hasil/create.blade.php ENDPATH**/ ?>