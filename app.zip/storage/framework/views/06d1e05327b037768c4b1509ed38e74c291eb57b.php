<?php $__env->startSection('detail'); ?>
    <h1 class="title">Hasil Penilaian <?php echo e($is_fullday?"Harian Fullday":"Periodik Boarding"); ?> </h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light"><?php echo e($siswa->user->name); ?></h4>
    </div>
   
    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('musyrif.penilaian-periodik.hasil.create', $siswa->id)); ?>" class="button is-primary is-rounded">
                <span class="icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span>Buat Penilaian</span>
            </a>
        </div>

        <?php if($siswa->periodic_scores->count()): ?>
            <div class="level-right is-size-5">
                Rerata Nilai: <strong style="margin-left: 5px;"><?php echo e(Arr::get($siswa->periodic_accumulations->first(), 'rerata_nilai')); ?></strong>
            </div>
        <?php endif; ?>
    </div>

    <?php if($is_fullday == false && $siswa->periodic_scores->count()): ?>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>#</th>
                    <td>Tanggal Pelaksanaan</td>
                    <td>Nilai</td>
                    <td></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $siswa->periodic_scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->tanggal_pelaksanaan->format('d F Y')); ?></td>
                        <td><?php echo e($item->nilai); ?></td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('musyrif.penilaian-periodik.hasil.edit', [$siswa->id, $item])); ?>" class="button is-text">
                                <i class="fas fa-edit"></i>
                            </a>

                            <form action="<?php echo e(route('musyrif.penilaian-periodik.hasil.destroy', [$siswa, $item])); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button name="delete-item" class="button is-text has-text-danger">
                                    <span class="icon">
                                        <i class="fas fa-trash"></i>
                                    </span>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php elseif($is_fullday == true && $siswa->daily_scores->count()): ?>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>#</th>
                    <td>Tanggal Pelaksanaan</td>
                    <td>Pemahaman Ilmu Tajwid</td>
                    <td>Karakter Muslim</td>
                    <td>Keterangan</td>
                    <td></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $siswa->daily_scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->tanggal_pelaksanaan->format('d F Y')); ?></td>
                        <td><?php echo e($item->tajwid); ?></td>
                        <td><?php echo e($item->karakter); ?></td>
                        <td> <?php echo e($item->is_after_pts?"Setelah":"Sebelum"); ?> PTS</td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('musyrif.penilaian-periodik.hasil.edit', [$siswa->id, $item])); ?>" class="button is-text">
                                <i class="fas fa-edit"></i>
                            </a>

                            <form action="<?php echo e(route('musyrif.penilaian-periodik.hasil.destroy', [$siswa, $item])); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button name="delete-item" class="button is-text has-text-danger">
                                    <span class="icon">
                                        <i class="fas fa-trash"></i>
                                    </span>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="notification is-warning">
            <p>Belum ada data!</p>
        </div>
    <?php endif; ?>

    <?php $__env->startSection('modal'); ?>
        <?php $__env->startComponent('components.modal', ['modal_id' => 'delete-confirmation', 'close_btn' => true]); ?>
            <?php echo $__env->make('partials.delete-confirmation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/penilaian-periodik/hasil/index.blade.php ENDPATH**/ ?>