<div id="<?php echo e(isset($modal_id) ? $modal_id : 'my-modal'); ?>" class="modal <?php echo e(isset($extra_classes) ? $extra_classes : ''); ?>">
    <div class="modal-background"></div>
    <div class="modal-content">
        <?php echo e($slot); ?>

    </div>
    <?php if(isset($close_btn)): ?>
        <button class="modal-close is-large" aria-label="close"></button>
    <?php endif; ?>
</div>

<?php $__env->startSection('modal_script'); ?>
    <script>
        var myModal = document.querySelector('<?php echo e(isset($modal_id) ? '#' . $modal_id : '#my-modal'); ?>');
        <?php if(isset($close_btn)): ?>
            var modalCloseBtn = document.querySelector('<?php echo e(isset($modal_id) ? '#' . $modal_id : '#my-modal'); ?> button.modal-close');
            modalCloseBtn.addEventListener('click', function() {
                myModal.classList.remove('is-active');
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/components/modal.blade.php ENDPATH**/ ?>