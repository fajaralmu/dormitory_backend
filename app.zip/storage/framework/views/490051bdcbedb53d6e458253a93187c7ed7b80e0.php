<?php $__env->startSection('content'); ?>
    <h1 class="title">Detail <span class="tag is-dark">Penilaian Periodik</span></h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light">
            <span class="icon">
                <i class="fas fa-user"></i>
            </span>
            <span><?php echo e($siswa->user->name); ?></span>
        </h4>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.penilaian-periodik.details.index', $siswa)); ?>" class="button is-primary is-outlined">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks</span>
            </a>
        </div>
        <?php if($is_fullday == false && !is_null($score)): ?>
            <div class="level-right">
                <div class="tags has-addons are-medium">
                    <span class="tag is-dark">Nilai Akhir</span>
                    <span class="tag is-info"><?php echo e($score->nilai); ?></span>
                </div>
            </div>
        <?php endif; ?>
        
    </div>

    <?php if($is_fullday == false): ?>
        <?php $__env->startComponent('components.card', ['title' => 'Detail Penilaian']); ?>
            <table class="table is-fullwidth">
                <thead>
                    <tr>
                        <th>Nomor</th>
                        <th class="has-text-centered">Kelancaran</th>
                        <th class="has-text-centered">Fashohah</th>
                        <th class="has-text-centered">Tajwid</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 1; $i <= $items_qty; $i++): ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td class="has-text-centered"><?php echo e($score->detail['kelancaran'][$i]); ?></td>
                            <td class="has-text-centered"><?php echo e($score->detail['fashohah'][$i]); ?></td>
                            <td class="has-text-centered"><?php echo e($score->detail['tajwid'][$i]); ?></td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        <?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <?php $__env->startComponent('components.card', ['title' => 'Detail Penilaian']); ?>
            <table class="table is-fullwidth">
                <thead>
                    <tr>
                        <th class="has-text-centered">Pengetahuan Ilmu Tajwid</th>
                        <th class="has-text-centered">Karakter Muslim</th> 
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="has-text-centered"><?php echo e($score->tajwid); ?></td>
                        <td class="has-text-centered"><?php echo e($score->karakter); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/penilaian-periodik/details/show.blade.php ENDPATH**/ ?>