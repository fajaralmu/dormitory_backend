<?php $__env->startSection('content'); ?>
    <h1 class="title">Halaqoh</h1>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.halaqoh.index')); ?>" class="button is-outlined is-dark">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks Halaqoh</span>
            </a>
        </div>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'New Halaqoh']); ?>
        <?php echo $form; ?>

    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/halaqoh/create.blade.php ENDPATH**/ ?>