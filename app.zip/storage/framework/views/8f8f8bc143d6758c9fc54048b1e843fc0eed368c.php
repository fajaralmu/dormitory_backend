<?php
    $extra_class = $errors->has($name) ? ' is-danger' : '';
    $choices = Arr::get($options, 'choices');
    $selected = old($name, Arr::get($options, 'selected'));

    $is_multiple = Arr::get($options, 'multiple', false) ? 'multiple' : '';
    $is_disabled = Arr::get($options, 'disabled', false) ? 'disabled' : '';

    $first_option = Arr::get($options, 'empty_value', ' -- Pilih ' . title_case($name) . ' -- ');

    $normalized_name = str_replace('[]', '', $name);

    if (Arr::get($options, 'multiple')) {
        $extra_class .= ' is-multiple';
        $extra_class .= $errors->has($name . '.0') ? ' is-danger' : '';
        $name .= '[]';
    }
?>

<?php if($orientation == 'horizontal'): ?>
    <div class="field is-horizontal">
        <div class="field-label is-normal">
            <label class="label"><?php echo e(title_case(str_replace('_', ' ', $normalized_name))); ?></label>
        </div>
        <div class="field-body">
            <div class="field">
                <div class="control">
                    <div class="select<?php echo e($extra_class); ?>">
                        <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" <?php echo e($is_multiple . ' ' . $is_disabled); ?>>
                            <option value="none"><?php echo e($first_option); ?></option>
                            <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isAssoc($choices)): ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e(selected_status($value, $selected)); ?>>
                                        <?php echo e($label); ?>

                                    </option>
                                <?php else: ?>
                                    <option value="<?php echo e($label); ?>" <?php echo e(selected_status($label, $selected)); ?>>
                                        <?php echo e(title_case(str_replace('_', ' ', $label))); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <?php if($errors->has($name)): ?>
                    <p class="help is-danger">
                       <?php echo e($errors->first($name)); ?>

                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="field">
        <label class="label"><?php echo e(title_case(str_replace('_', ' ', $normalized_name))); ?></label>
        <div class="control">
            <div class="select<?php echo e($extra_class); ?>">
                <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" <?php echo e($is_multiple . ' ' . $is_disabled); ?>>
                    <option value="none"><?php echo e($first_option); ?></option>
                    <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isAssoc($choices)): ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(selected_status($value, $selected)); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php else: ?>
                            <option value="<?php echo e($label); ?>" <?php echo e(selected_status($label, $selected)); ?>>
                                <?php echo e(title_case(str_replace('_', ' ', $label))); ?>

                            </option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <?php if($errors->has($name)): ?>
            <p class="help is-danger">
               <?php echo e($errors->first($name)); ?>

            </p>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\vendor\realcahsowan\laravel-bulma-form\src/../resources/views/select.blade.php ENDPATH**/ ?>