<div class="column is-one-third">
    <div class="field">
        <label class="label">Keterangan Kalender<label>
    </div>
    <div class="box has-background-primary" style="padding:10px; color: #fff"><label>Hari Aktif</label></div>
    <div class="box has-background-link" style="padding:10px; color: #fff"><label>Mutabaah Lengkap</label></div>
    <div class="box has-background-danger" style="padding:10px"><label>Hari Non Aktif</label></div>
    <div class="box" style="padding:10px"><label>Belum Ada Data<label></div>
</div><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/shared/calendar-legend.blade.php ENDPATH**/ ?>