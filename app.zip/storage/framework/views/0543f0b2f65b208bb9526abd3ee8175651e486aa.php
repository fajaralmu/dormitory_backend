<?php $__env->startComponent('components.card', ['title' => 'Filter']); ?>
<form onsubmit="loadData(event)">
<?php $__env->startComponent('components.inputhorizontal', ['label'=>'Siswa']); ?>
    <div class="select">
        <select id="select-student" name="siswa_id" autocomplete="off" >
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?> - <?php echo e($student->level.$student->rombel); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('components.selectperiod', ['label'=>'Dari Periode', 'names' => ['day', 'month', 'year']]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('components.selectperiod', ['label'=>'Sampai Periode', 'names' => ['dayTo', 'monthTo', 'yearTo']]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('components.inputhorizontal', ["label"=>null]); ?>
    <a href="<?php echo e(url('admin/mutabaah')); ?>" class="button is-link"><span class="icon"><i class="fas fa-arrow-circle-left"></i></span><span>Kembali</span></a>
    <input value="Submit" type="submit" class="button is-primary" />
    <a onclick="printContent()" class="button is-dark"><span class="icon"><i class="fas fa-print"></i></span><span>Cetak</span></a>
<?php echo $__env->renderComponent(); ?>
</form>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/form/daily-activities-period-form.blade.php ENDPATH**/ ?>