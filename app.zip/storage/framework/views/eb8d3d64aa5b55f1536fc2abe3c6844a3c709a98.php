<aside id="sidebar" style="margin-top: 0.75rem;" class="menu">
    <p class="menu-label" id="utama">
        Utama
    </p>
    <ul class="menu-list">
        <li>
            <a href="<?php echo e(route('tester.home')); ?>">
                <i class="fas fa-tachometer-alt"></i> Dasbor
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('tester.panduan.index')); ?>">
                <i class="fas fa-life-ring"></i> Panduan
            </a>
        </li>
        <?php if($user_is_musyrif): ?>
            <li>
                <a href="<?php echo e(route('musyrif.home')); ?>">
                    <i class="fas fa-heart"></i> Ruang Musyrif
                </a>
            </li>
        <?php endif; ?>
    </ul>
    <p class="menu-label" id="pts">
        PTS
    </p>
    <ul class="menu-list">
        <li>
            <a href="<?php echo e(route('tester.pts.students.index')); ?>">
                <i class="fas fa-users"></i> Siswa
            </a>
        </li>
    </ul>
    <p class="menu-label" id="pas">
        PAS
    </p>
    <ul class="menu-list">
        <li>
            <a href="<?php echo e(route('tester.pas.students.index')); ?>">
                <i class="fas fa-users"></i> Siswa
            </a>
        </li>
    </ul>
    <p class="menu-label" id="laporan">
        Laporan
    </p>
    <ul class="menu-list">
        <li>
            <a href="#">
                <i class="fas fa-chart-bar"></i> Statistik
            </a>
        </li>
    </ul>
</aside><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/sidebars/tester.blade.php ENDPATH**/ ?>