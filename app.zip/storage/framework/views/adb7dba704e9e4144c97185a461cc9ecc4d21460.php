 

<?php $__env->startSection('detail'); ?>

    <script type="text/javascript">
         const URL_EVENTS = "<?php echo e(url('/musyrif/harian')); ?>";
         const dailyActivityList = <?php echo json_encode($existingDataList); ?>;
         const presenceInfo = <?php echo json_encode($presenceInfo); ?>;

         function generateDailyActivityListItem(dailyActivity){
            const htmlInfo = {
                tagName: 'div', id: 'daily-activity-list-'+dailyActivity.id,
                className: 'daily-activity-list-item',
                ch0: {
                    tagName: 'div', className: 'columns',
                    ch0: {
                        tagName:'div', className: 'column',
                        innerHTML: "<p ><i class=\"fas fa-check-circle\"></i>&nbsp;&nbsp;"+dailyActivity.time.toUpperCase()+" - record id: "+ dailyActivity.id+"</p>"
                    },
                    ch1: {
                        tagName: 'div', className: 'column',
                        innerHTML:  presenceInfo[dailyActivity.presence]
                    },
                    ch2: {
                        tagName: 'div', className: 'column',
                        innerHTML: 'updated at '+dailyActivity.updated_at
                    },
                    ch3: {
                        tagName: 'div', className: 'column',
                        ch0: {
                            tagName: 'a', className: 'button is-warning',
                            innerHTML: "<i class=\"fas fa-edit\"></i>&nbsp;&nbsp;modify",
                            onclick: function(e){ loadDailyActivityData(dailyActivity.id); },
                        },
                        ch1: {
                            tagName: 'a', className: 'button is-danger',
                            innerHTML: "<i class=\"fas fa-times-circle\"></i>&nbsp;&nbsp;delete",
                            onclick: function(e){ confirmDialog("Delete record?")
                                .then(function(ok){ if(ok) deleteDailyActivityRecord(dailyActivity.id); })
                            },
                        }
                    }
                }
            };
            return createHtmlTag(htmlInfo);
        }
    </script>
    <style>
        .daily-activity-list-item{
            width: 100%; padding:10px; border-bottom: solid 1px #ccc
        }
        
    </style>
    <h1 class="title">Penilaian Harian <?php echo e($date_str); ?></h1>
    
    <?php $__env->startComponent('components.card', ['title'=> $student->user->name ]); ?>
        <div>
            <ul>
                <li>Sekolah: <strong><?php echo e($student->kelas->sekolah->nama); ?></strong></li>
                <li>Kelas: <strong><?php echo e($student->kelas->level . $student->kelas->rombel); ?></strong></li>
                <li>Musyrif: <strong>Ust. <?php echo e($halaqoh->pegawai->user->name); ?></strong></li> 
                 
            </ul>
        </div>
    <?php echo $__env->renderComponent(); ?>
    <article class="panel is-link">
        <div class="panel-heading"><p>Data Tersimpan Pada <?php echo e($date_str); ?></p></div>
        <div>
            <div id="daily-activity-list" >
                <div  style="text-align: center; width: 100%;">
                <div class="lds-ring" ><div></div><div></div><div></div><div></div></div>
                </div>
            </div>
            <div class="panel-block">
            <a style="margin-top:20px" class="button is-link" href="<?php echo e(route('musyrif.harian.index')); ?>" ><i class="fas fa-arrow-circle-left"></i>&nbsp;&nbsp;Kembali</a>
            </div>
        </div>
    </article>
    <?php $__env->startComponent('components.card', ['title'=> "Formulir" ]); ?>
        <?php echo $form; ?>

    <?php echo $__env->renderComponent(); ?>
    <!-- Components -->
    <script type="text/javascript">
        const inputForm = byId("<?php echo e($form_id); ?>");
        //
        const inputTime = byId("waktu");
        const inputKehadiran = byId("kehadiran");
        const inputPenutupan = byId("penutupan");
        const inputPembukaan = byId("pembukaan");
        //input data setoran//
        const inputSetoran = byId("setoran");
        const inputStartJuz = byName("juz_start");
        const inputStartJuzPage = byName("juz_page_start");
        const inputEndJuz = byName("juz_end");
        const inputEndJuzPage = byName("juz_page_end");
        const inputAdditionalInfo = byId("catatan");
        //input pelanggaran//
        const inputPelanggaranLuarArea = byId("pelanggaran_luar_area");
        const inputPelanggaranTidakBerseragam = byId("pelanggaran_tidak_berseragam");
        const inputPelanggaranBercanda = byId("pelanggaran_bercanda");
        const inputPelanggaranTidur = byId("pelanggaran_tidur");
        const inputPelanggaranCurang = byId("pelanggaran_curang");
        const inputPelanggaranAdab = byId("pelanggaran_adab");
        const inputPelanggaranBermainGadget = byId("pelanggaran_bermain_gadget");

        //
        const buttonSubmit = document.getElementsByClassName("button-submit-form-penilaian")[0];
        const panelDailyActivityList = byId("daily-activity-list");
        const HADIR = "h", TRUE = "true", FALSE = "false";

        function setDefaultFormEvents() {
            inputForm.removeAttribute("method");
            inputForm.removeAttribute("action");
            inputForm.setAttribute("onsubmit", "return false;");
            inputForm.reset();
        }
        function addButtonReset() {
            if (byId("button-reset-form")) {
                return;
            }
            const buttonReset = document.createElement("input");
            buttonReset.value = "Reset";
            buttonReset.id = "button-reset-form";
            buttonReset.className = "button is-danger";
            buttonReset.type="reset";
            buttonSubmit.parentNode.appendChild(buttonReset);
        }
    </script>
    <!-- Event Listeners -->
    <script type="text/javascript">
        inputPembukaan.onchange = function(e){
            if(e.target.value == TRUE) {
                inputKehadiran.value = HADIR;
            }
        }
        inputPenutupan.onchange = function(e){
            if(e.target.value == TRUE) {
                inputKehadiran.value = HADIR;
            }
        }
        inputKehadiran.onchange = function(e){
            if(e.target.value != HADIR) {
                inputPembukaan.value = FALSE;
                inputPenutupan.value = FALSE;
                disableInputs(inputPembukaan, inputPenutupan, inputSetoran, 
                    inputStartJuz, inputStartJuzPage, inputEndJuz, inputEndJuzPage,
                    inputPelanggaranAdab, inputPelanggaranBercanda, inputPelanggaranCurang,
                    inputPelanggaranLuarArea, inputPelanggaranTidakBerseragam,
                    inputPelanggaranTidur, inputPelanggaranBermainGadget);
            } else {
                enableInputs(inputPembukaan, inputPenutupan, inputSetoran, 
                    inputStartJuz, inputStartJuzPage, inputEndJuz, inputEndJuzPage,
                    inputPelanggaranAdab, inputPelanggaranBercanda, inputPelanggaranCurang,
                    inputPelanggaranLuarArea, inputPelanggaranTidakBerseragam,
                    inputPelanggaranTidur, inputPelanggaranBermainGadget);
            }
        }
        inputSetoran.onchange = function(e){
            if(e.target.value == TRUE)
            {
                enableInputSetoran();
            } else {
                disableInputSetoran();
            }
        }
         
        setDefaultFormEvents();

        if (inputSetoran.value != TRUE) {
            disableInputs(inputStartJuz, inputStartJuzPage, inputEndJuz, inputEndJuzPage);
        }        

        buttonSubmit.onclick = function(e){
            e.preventDefault();
            submit();
        }
        addButtonReset();

        addOnloadHandler(function(e){
            populateDailyActivityList(dailyActivityList);
        });
        
    </script>
    <!-- Html input manipulations -->
    <script type="text/javascript">

        function enableInputSetoran() {
            enableInputs(inputStartJuz, inputStartJuzPage,
                    inputEndJuz, inputEndJuzPage);
        }

        function disableInputSetoran() {
            disableInputs(inputStartJuz, inputStartJuzPage,
                    inputEndJuz, inputEndJuzPage);
        }

        function populateDailyActivityList(dailyActivityList) {
            panelDailyActivityList.innerHTML = "";
            if(dailyActivityList.length>0){
                
                for (let i = 0; i < dailyActivityList.length; i++) {
                    const dailyActivity = dailyActivityList[i];
                    const htmlElement = generateDailyActivityListItem(dailyActivity);
                    panelDailyActivityList.appendChild(htmlElement);
                }
            } else {
                panelDailyActivityList.innerHTML = "<div class=\"panel-block\"><p>BELUM ADA</p></div>";
            }
        }

        function populateForm(response) {
            let dailyActivity = null;// {"id":14,"siswa_id":"0d156be7-0c1b-485f-b71b-3934634b0ca5","tahun_ajaran":"2020-2021","time":"morning","presence":"h","semester":1,"day":3,"month":11,"year":2020,"juz_start":6,"juz_page_start":10,"juz_end":9,"juz_page_end":22,"opening":1,"closing":1,"is_recited":1,"description":"test","created_at":"2020-11-25 08:12:19","updated_at":"2020-11-25 08:12:19","rule_break_area":0,"rule_break_dresscode":0,"rule_break_joke":0,"rule_break_attitude":0,"rule_break_sleep":0,"rule_break_play_gadget":0,"rule_break_cheat":0};
            dailyActivity = response.dailyActivity;
            inputTime.value = dailyActivity.time;
            inputKehadiran.value = dailyActivity.presence;
            inputPembukaan.value = dailyActivity.opening?TRUE:FALSE;
            inputPenutupan.value = dailyActivity.closing?TRUE:FALSE;
            inputSetoran.value = dailyActivity.is_recited?TRUE:FALSE;
            inputStartJuz.value = dailyActivity.juz_start;
            inputStartJuzPage.value = dailyActivity.juz_page_start;
            inputEndJuz.value = dailyActivity.juz_end;
            inputEndJuzPage.value = dailyActivity.juz_page_end;
            inputAdditionalInfo.value = dailyActivity.description;

            inputPelanggaranAdab.value = dailyActivity.rule_break_attitude?TRUE:FALSE
            inputPelanggaranBercanda.value = dailyActivity.rule_break_joke?TRUE:FALSE
            inputPelanggaranBermainGadget.value = dailyActivity.rule_break_play_gadget?TRUE:FALSE
            inputPelanggaranCurang.value = dailyActivity.rule_break_cheat?TRUE:FALSE
            inputPelanggaranLuarArea.value = dailyActivity.rule_break_area?TRUE:FALSE
            inputPelanggaranTidakBerseragam.value = dailyActivity.rule_break_dresscode?TRUE:FALSE
            inputPelanggaranTidur.value = dailyActivity.rule_break_sleep?TRUE:FALSE

            if (dailyActivity.is_recited == true) {
                enableInputSetoran();
            } else {
                disableInputSetoran();
            }
        }

    </script>
    <!-- Ajax Calls -->
    <script type="text/javascript">
        function submit() {
            const setoranIsTrue = inputSetoran.value == TRUE;
            const presenceIsTrue = inputKehadiran.value == HADIR;

            //validation
            if (inputTime.value != "morning" && inputTime.value != "afternoon") {
                infoDialog("Silakan pilih waktu ").then(null);
                return;
            }
            if (setoranIsTrue && inputHasEmptyValue(inputStartJuz, inputStartJuzPage, inputEndJuz, inputEndJuzPage)) {
                infoDialog("Juz yang disetorkan tidak valid").then(null);
                return;
            }

            const aliases = {
                time: 'waktu', presence: 'kehadiran', description: 'catatan', is_recited: 'setoran',
                rule_break_area: 'pelanggaran_luar_area',
                rule_break_dresscode: 'pelanggaran_tidak_berseragam',
                rule_break_joke: 'pelanggaran_bercanda',
                rule_break_attitude:'pelanggaran_adab',
                rule_break_sleep:'pelanggaran_tidur',
                rule_break_play_gadget:'pelanggaran_bermain_gadget'
            }
            
            const payload = {
                time: inputTime.value,

                //kehadiran
                presence: inputKehadiran.value,
                opening: presenceIsTrue && inputPembukaan.value == TRUE,
                closing: presenceIsTrue && inputPenutupan.value == TRUE,

                //data setoran
                is_recited: presenceIsTrue && setoranIsTrue,
                juz_start: presenceIsTrue && setoranIsTrue?inputStartJuz.value:null,
                juz_page_start: presenceIsTrue && setoranIsTrue?inputStartJuzPage.value:null,
                juz_end: presenceIsTrue && setoranIsTrue?inputEndJuz.value:null,
                juz_page_end: presenceIsTrue && setoranIsTrue?inputEndJuzPage.value:null,

                //data pelanggaran
                rule_break_area: presenceIsTrue && inputPelanggaranLuarArea.value == TRUE,
                rule_break_dresscode: presenceIsTrue && inputPelanggaranTidakBerseragam.value == TRUE,
                rule_break_joke: presenceIsTrue && inputPelanggaranBercanda.value == TRUE,
                rule_break_attitude: presenceIsTrue && inputPelanggaranAdab.value == TRUE,
                rule_break_sleep: presenceIsTrue && inputPelanggaranTidur.value == TRUE,
                rule_break_play_gadget: presenceIsTrue && inputPelanggaranBermainGadget.value == TRUE,
                rule_break_cheat: presenceIsTrue && inputPelanggaranCurang.value == TRUE,

                //
                description: inputAdditionalInfo.value,
                
                //default
                day: parseInt("<?php echo e(request()->get('day')); ?>"),
                month: parseInt("<?php echo e(request()->get('month')); ?>"),
                year: parseInt("<?php echo e(request()->get('year')); ?>"),
                siswa_id: byName('siswa_id').value,
            }
            console.debug(payload);

            const table = createHtml("table", "<tr><th>Label</th><th>Uraian</th></tr>");
            table.setAttribute("class", 'table');

            for (const key in payload) {
                if (payload.hasOwnProperty(key)) {
                    const element = payload[key];
                    let label, value;
                    if(aliases[key] != null){
                        label = aliases[key];
                        const inputElement = byId(label);
                        if(inputElement.nodeName == "SELECT") {
                            value = inputElement.options[inputElement.selectedIndex].innerHTML;
                            if(inputElement.selectedIndex == 0) //not real value
                            {
                                value = "-";
                            }
                        } else {
                            value = inputElement.value
                        }
                    } else {
                        label = key;
                        value = element;
                    }


                    label = label.toUpperCase().replaceAll("_", " ");
                    const tr = createHtml("tr", "<td>"+label+"</td><td>"+(value == null ? "-" : value)+"</td>");
                    table.appendChild(tr);
                }
            }

            ///
            confirmDialog("<h3>Detail Data</h3>"+domToString(table))
            .then(function(ok){
                if(ok){
                    storeDailyActivity(payload);
                }
            });

            
        }

        function storeDailyActivity(payload) {
            startLoading();
            axios.post(URL_EVENTS,{ dailyActivity:  payload })
            .then(function(response){
                infoDialog("Succes").then(loadDailyActivityList);
                inputForm.reset();

            }).catch(function(e){
                alert("Operation failed: "+e);

            }).finally(stopLoading);
        }
        

        function loadDailyActivityData(id) {
            startLoading();
            const endpoint = URL_EVENTS+"/"+id;
            axios.get(endpoint)
            .then(function(response){
                populateForm(response.data);
            })
            .catch(function(e){
                alert("Operation failed: "+e);
            })
            .finally(stopLoading);

        }

        function loadDailyActivityList(){
            startLoading();
            const day = "<?php echo e(request()->get('day')); ?>";
            const month = "<?php echo e(request()->get('month')); ?>";
            const year = "<?php echo e(request()->get('year')); ?>";
            const queryString ="filter=only_daily_activity&day="+day+
                "&month="+month+"&year="+year+"&siswa_id=<?php echo e($student->id); ?>";
            axios.get(URL_EVENTS+"/<?php echo e($sekolah_id); ?>?"+queryString)
            .then(function(response){
                populateDailyActivityList(response.data.dailyActivityList);
            }).catch(function(e){
                alert("Operation failed: "+e);
            }).finally(stopLoading);
        }

        function deleteDailyActivityRecord(id){
            startLoading();
            const endpoint = URL_EVENTS+"/"+id;
            axios.delete(endpoint)
            .then(function(response){
                infoDialog("Succes").then(loadDailyActivityList);
            })
            .catch(function(e){
                alert("Operation failed: "+e);
            })
            .finally(stopLoading);
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/dailyactivities/edit.blade.php ENDPATH**/ ?>