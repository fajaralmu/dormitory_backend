
 <?php $__env->startComponent('components.card', ['title'=> 'Pilih Waktu' ]); ?>
    <div>
        <form onsubmit="selectPeriod(event)" >
            <div class="fields">
            <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Halaqoh"]); ?>
                <div class="select">
                    <select autocomplete="off" class="select" id="select-halaqoh" name="halaqoh">
                        <?php $__currentLoopData = $halaqoh_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!is_null($halaqoh) && $h->id == $halaqoh->id): ?>
                                <option selected value=<?php echo e($h->id); ?>><?php echo e($h->nama); ?> - Ust. <?php echo e($h->pegawai->user->name); ?></option>
                            <?php else: ?>
                                <option value=<?php echo e($h->id); ?>><?php echo e($h->nama); ?> - Ust. <?php echo e($h->pegawai->user->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php echo $__env->renderComponent(); ?>
            
            <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Periode"]); ?>
            <div class="field is-grouped">
                <p class="control select">
                    <select autocomplete="off" name="day" class="select">
                        <?php for($i = 1; $i <= 31; $i++): ?>
                            <?php if($i == request()->get('day')): ?>
                                <option selected value=<?php echo e($i); ?>><?php echo e($i); ?></option>
                            <?php else: ?>
                                <option value=<?php echo e($i); ?>><?php echo e($i); ?></option>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </select>
                </p>
                <p class="control select">
                    <select autocomplete="off"  name="month" class="select">
                        <?php $__currentLoopData = App\Utils\DateUtil::$MONTH_NAMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(($loop->index + 1) == request()->get('month')): ?>
                                <option selected value=<?php echo e($loop->index + 1); ?>><?php echo e($month); ?></option>
                            <?php else: ?>
                                <option value=<?php echo e($loop->index + 1); ?>><?php echo e($month); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </p>
                <p class="control">
                <input type="number" class="input" name="year" value="<?php echo e(request()->get('year')); ?>" />
                </p>
            </div>
            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Waktu"]); ?>
                <div class="select"><select class="select" id="select-time" name="time">
                        <option value="morning">Pagi</option>
                        <option value="afternoon">Sore</option>
                    </select>
                </div>
            <?php echo $__env->renderComponent(); ?>
           
            <div class="field is-horizontal">
                <div class="field-label">
                    <a class="button is-link" href="<?php echo e(route('admin.mutabaah.index')); ?>" ><i class="fas fa-arrow-circle-left"></i>&nbsp;&nbsp;Kembali</a>
                </div>
                <div class="field-body buttons has-addons">
                    <input value="Pilih" type="submit" class="button is-dark" />
                </div>
            </div>
            </div>
        </form>
    </div>

    <script type="text/javascript">
        const url = "<?php echo e(url('/admin/mutabaah/detail/')); ?>";
        function selectPeriod(e) {
            e.preventDefault();
            const selectHalaqohValue = document.getElementById("select-halaqoh").value;
            const formData = new FormData(e.target);
            formData.delete('halaqoh');
            const queryString = new URLSearchParams(formData).toString();
            console.debug("query string ", queryString);
            window.location = url + "/"+selectHalaqohValue +"?"+queryString;
        }

    </script>
    <?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/harian/select-time.blade.php ENDPATH**/ ?>