<?php
    $placeholder = Arr::has($options, 'placeholder') ? Arr::get($options, 'placeholder') : title_case(str_replace('_', ' ', $name));
    $value = old($name, Arr::get($options, 'value'));
    $extra_class = $errors->has($name) ? ' is-danger' : '';

    $is_narrow = Arr::get($options, 'narrow') ? ' is-narrow' : '';
?>

<?php if($orientation == 'horizontal'): ?>
    <div class="field is-horizontal">
        <div class="field-label is-normal">
            <label class="label"><?php echo e(title_case(str_replace('_', ' ', $name))); ?></label>
        </div>
        <div class="field-body">
            <div class="field<?php echo e($is_narrow); ?>">
                <div class="control">
                    <textarea class="textarea<?php echo e($extra_class); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" cols="30" rows="<?php echo e(Arr::get($options, 'rows')); ?>" placeholder="<?php echo e($placeholder); ?>" <?php echo e(Arr::has($options, 'disabled') ? 'disabled' : ''); ?>><?php echo e($value); ?></textarea>
                </div>
                <?php if($errors->has($name)): ?>
                    <p class="help is-danger">
                       <?php echo e($errors->first($name)); ?>

                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="field">
        <label class="label"><?php echo e(title_case(str_replace('_', ' ', $name))); ?></label>
        <div class="control">
            <textarea class="textarea<?php echo e($extra_class); ?>" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" cols="30" rows="<?php echo e(Arr::get($options, 'rows')); ?>" placeholder="<?php echo e($placeholder); ?>" <?php echo e(Arr::has($options, 'disabled') ? 'disabled' : ''); ?>><?php echo e($value); ?></textarea>
        </div>
        <?php if($errors->has($name)): ?>
            <p class="help is-danger">
               <?php echo e($errors->first($name)); ?>

            </p>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\vendor\realcahsowan\laravel-bulma-form\src/../resources/views/textarea.blade.php ENDPATH**/ ?>