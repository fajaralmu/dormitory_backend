<?php
     $juz_label = (string) $juz; 
     $raw_juz = explode( '_', $juz_label);     

    if(Str::contains ($juz_label, '_a')){
        $juz_label = $raw_juz[0].' Awal';
    }
    elseif(Str::contains ($juz_label, '_b')){
        $juz_label = $raw_juz[0].' Akhir';
    }    
    if(sizeof($raw_juz) == 1){
        array_push($raw_juz, null);
    }
?>
<?php $__env->startSection('content'); ?>
    <h1 class="title">Detail Penilaian PTS</h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light"><?php echo e(Str::limit($student->user->name, 25)); ?> | JUZ <?php echo e($juz_label); ?></h4>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('tester.pts.students.show', $student)); ?>" class="button is-outlined is-primary">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks Juz</span>
            </a>
        </div>
    </div>

    <table class="table is-fullwidth is-vcentered">
        <thead>
            <tr>
                <th>Hal</th>
                <th class="has-text-centered">Kelancaran</th>
                <th class="has-text-centered">Fashohah</th>
                <th class="has-text-centered">Tajwid</th>
                <th>Score</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $student->pts_scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($penilaian->page); ?></td>
                    <td class="has-text-centered"><?php echo e($penilaian->raw_score['kelancaran']); ?></td>
                    <td class="has-text-centered"><?php echo e($penilaian->raw_score['fashohah']); ?></td>
                    <td class="has-text-centered"><?php echo e($penilaian->raw_score['tajwid']); ?></td>
                    <td><?php echo e($penilaian->score); ?></td>
                    <td class="has-text-right">
                        <a href="<?php echo e(route('tester.pts.students.penilaian.details.show', [$student, $juz, $penilaian])); ?>" class="button is-text">
                            <i class="fas fa-file-alt"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php
                    $pts_detail_score = $student->getPtsDetailScores($raw_juz[0], $raw_juz[1]);
                ?>
                <td><b>Rata rata</b></td>
                <td class="has-text-centered"><?php echo e($pts_detail_score['kelancaran']); ?></td>
                <td class="has-text-centered"><?php echo e($pts_detail_score['fashohah']); ?></td>
                <td class="has-text-centered"><?php echo e($pts_detail_score['tajwid']); ?></td>
                <td><?php echo e($pts_detail_score['score']); ?></td>
                <td></td>
            </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/tester/pts/students/penilaian/details/index.blade.php ENDPATH**/ ?>