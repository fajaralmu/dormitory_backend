<?php
    $labels = [
        'a' => 'Sangat Baik', 
        'b' => 'Baik', 
        'c' => 'Kurang', 
        'd' => 'Butuh Bimbingan Lebih',
    ];

    $descriptions = [
        'a' => 'Alhamdulillah Ananda telah mampu membaca Al Quran sesuai dengan kaidah ilmu tajwid dengan sangat baik.',
        'b' => 'Alhamdulillah Ananda telah mampu membaca Al Quran sesuai dengan kaidah ilmu tajwid dengan baik.',
        'c' => 'Alhamdulillah Ananda telah mampu membaca Al Quran dengan cukup baik. Namun masih perlu bimbingan intensif dalam mempelajari ilmu tajwid.',
        'd' => 'Ananda masih sangat membutuhkan bimbingan intensif dalam meningkatkan bacaan Al Qur’an.',
    ];
?>



<?php $__env->startSection('detail'); ?>
    <h1 class="title">Penilaian Individual</h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light"><i class="fas fa-user-circle"></i> <?php echo e($rapor->siswa->user->name); ?></h4>
        <p class="subtitle is-size-6 has-text-info"><?php echo e($rapor->siswa->kelas->sekolah->nama); ?>, Kelas: <?php echo e($rapor->siswa->kelas->level . $rapor->siswa->kelas->rombel); ?></p>
    </div>

    <div class="level">
        <div class="level-left">
            <a class="button is-primary" href="<?php echo e(route('musyrif.penilaian-individual.create', ['siswa' => $rapor->siswa->id])); ?>">
                <span class="icon"><i class="fas fa-edit"></i></span>
                <span>Edit</span>
            </a>
        </div>
    </div>

    <?php $__currentLoopData = ['fashohah', 'tajwid', 'adab', 'catatan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('components.card', ['title' => title_case($item)]); ?>
            <div>
                <?php if(in_array($item, ['fashohah', 'tajwid',  'adab'])): ?>
                    
                    <?php echo e(strtoupper($rapor->{$item})); ?>

                <?php else: ?>
                    <?php echo e($rapor->{$item}); ?>

                <?php endif; ?>
            </div>
        <?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/penilaian-individual/show.blade.php ENDPATH**/ ?>