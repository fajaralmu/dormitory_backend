<div class="field" style="display: grid; grid-template-columns: 20% 40%">
    <label class="label">List Display</label>
    <div class="control">
        <div class="select">
            <select id="<?php echo e($id); ?>">
                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
        </div>
    </div>
</div><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/components/singleselect.blade.php ENDPATH**/ ?>