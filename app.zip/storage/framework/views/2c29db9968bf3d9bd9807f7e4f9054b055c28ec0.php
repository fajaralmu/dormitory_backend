<aside id="sidebar" style="margin-top: 0.75rem; overflow-y:scroll; height: 90vh" class="menu">
    <p class="menu-label" id="utama">
        Utama
    </p>
    <ul class="menu-list">
        <li>
            <a href="<?php echo e(route('admin.home')); ?>">
                <i class="fas fa-tachometer-alt"></i> Dasbor
            </a>
        </li>
        
        <li>
            <a href="<?php echo e(route('admin.halaqoh.index')); ?>">
                <i class="fas fa-folder"></i> Halaqoh
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.penilaian-periodik.index')); ?>">
                <i class="fas fa-folder"></i> Penilaian Periodik
            </a>
        </li>
         
        <li>
            <a href="<?php echo e(route('admin.penilaian-individual.index')); ?>">
                <i class="fas fa-folder"></i> Penilaian Individual
            </a>
        </li>
    </ul>
    <p class="menu-label" id="pts">
        PTS
    </p>
    <ul class="menu-list" >
        <li>
            <a href="<?php echo e(route('admin.pts.penguji.index')); ?>">
                <i class="fas fa-folder"></i> Penguji
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.pts.progres-penguji.index')); ?>">
                <i class="fas fa-folder"></i> Rekapitulasi
            </a>
        </li>
    </ul>
    <p class="menu-label" id="penilaian">
        Penilaian Akhir
    </p> 
    <ul class="menu-list" >
        <li>
            <a href="<?php echo e(route('admin.pas.penguji.index')); ?>">
                <i class="fas fa-folder"></i> Penguji
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.pas.peta-juz.index')); ?>">
                <i class="fas fa-folder"></i> Peta Juz
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.pas.kriteria-bobot.index')); ?>">
                <i class="fas fa-folder"></i> Kriteria & Bobot
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.pas.munaqosyah.index')); ?>">
                <i class="fas fa-folder"></i> Munaqosyah
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.pas.progres-penguji.index')); ?>">
                <i class="fas fa-folder"></i> Rekapitulasi
            </a>
        </li>
    </ul>
     <p class="menu-label" id="pengaturan">
        Pengaturan
     </p> 
    <ul class="menu-list" >
        <li>
            <a href="<?php echo e(route('admin.settings.umum.index')); ?>">
                <i class="fas fa-cog"></i> Umum
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.settings.level-target.index')); ?>">
                <i class="fas fa-cog"></i> Level & Target
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.settings.stamp.index')); ?>">
                <i class="fas fa-stamp"></i> Stamp
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.settings.events.index')); ?>">
                <i class="fas fa-calendar-alt"></i> Events Timeline
            </a>
        </li>

    </ul>
    <p class="menu-label" id="laporan">
        Laporan
    </p> 
    <ul class="menu-list" >
        <li>
            <a href="<?php echo e(route('admin.laporan.index')); ?>">
                <i class="fas fa-folder"></i> Hasil Penilaian PAS
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.laporan-pts.index')); ?>">
                <i class="fas fa-folder"></i> Hasil Penilaian PTS
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.mutabaah.index')); ?>" class="navbar-item">
                <i class="fas fa-calendar-alt"></i> Kegiatan Harian
            </a>
        </li>
    </ul>
</aside>

<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/sidebars/admin.blade.php ENDPATH**/ ?>