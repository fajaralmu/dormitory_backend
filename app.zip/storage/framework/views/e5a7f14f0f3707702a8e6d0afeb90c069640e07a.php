<?php $__env->startSection('extra_style'); ?>
  <style>
    figure.image svg {
      width: 100%;
      height: 100%;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="section has-text-centered">
    <div class="columns">
      <div class="column is-6 is-offset-3">
        <div class="font-logo">
          <i class="fas fa-quran fa-5x"></i>
        </div>
      </div>
    </div>
      
    <h1 class="title" style="margin-top: 20px;"><?php echo e(config('app.name')); ?></h1>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/welcome.blade.php ENDPATH**/ ?>