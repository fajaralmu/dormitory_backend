<?php $__env->startSection('content'); ?>
    <script type="text/javascript">
       
        const URL_EVENTS_V2 = "<?php echo e(url('/musyrif/harianv2')); ?>";
        const URL_EVENTS_V1 = "<?php echo e(url('/musyrif/harian')); ?>";
        const date = new Date();
        const eventItemData = {
            id: 0,
            day: date.getDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear(),
            description: "",
            active: true,
            populate: function(event) {
                this.id = event.id;
                this.day = event.day;
                this.month = event.month;
                this.year = event.year;
                this.description = event.description;
                this.active = event.active;
            },
            setDefault: function() {
                this.id = 0;
                this.description = "";
                this.active = true;
            }

        };
        var selectedMonth = eventItemData.month;
        var selectedYear = eventItemData.year;
    </script> 
    <h1 class="title">Mutabaah Halaqoh <?php echo e($halaqoh->nama); ?></h1>
    <div>
        <?php $__env->startComponent('components.card', ['title' => 'Options']); ?>
        <div class="columns">
            <form target="_blank" action="<?php echo e(url('/musyrif/harianv2/mutabaah/edit')); ?>" method="GET" class="column">
                <div class="fields">
                    <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Periode"]); ?>
                    <div class="field is-grouped">
                        <p class="control select">
                            <select autocomplete="off" name="day" class="select">
                                <?php for($i = 1; $i <= 31; $i++): ?>
                                    <option value=<?php echo e($i); ?>><?php echo e($i); ?></option> 
                                <?php endfor; ?>
                            </select>
                        </p>
                        <p class="control select">
                            <select autocomplete="off"  name="month" class="select">
                                <?php $__currentLoopData = App\Utils\DateUtil::$MONTH_NAMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($loop->index + 1); ?>><?php echo e($month); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </p>
                        <p class="control">
                        <input type="number" class="input" name="year" value="<?php echo e(date("Y")); ?>" />
                        </p>
                    </div>
                    <?php echo $__env->renderComponent(); ?>
                    <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Periode"]); ?>
                    <div class="select">
                        <select autocomplete="off" name="time" class="select">
                            <option value="morning">Pagi</option>
                            <option value="afternoon">Sore</option>
                        </select>
                    </div>
                    <?php echo $__env->renderComponent(); ?>
                    <?php $__env->startComponent('components.inputhorizontal', ['label'=>'']); ?>
                        <button type="submit" class="button is-primary">
                            <span class="icon"><i class="fas fa-edit"></i></span>
                            <span>Isi Mutabaah</span>
                        </button>
                        <a target="_blank" href="<?php echo e(url('musyrif/mutabaah/laporandetail')); ?>" class="button is-info">
                            <span class="icon"><i class="fas fa-list"></i></span>
                            <span>Rekap Mutabaah</span>
                        </a>
                    <?php echo $__env->renderComponent(); ?>
                </div>
            </form>
            <div class="column is-one-third">
                <article class="message is-link">
                    <div class="message-header"><p>Info</p></div>
                    <div class="message-body" id="info">Info</div>
                </article>
            </div>
        </div>
        <?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('components.card', ['title' => 'Events Calendar']); ?>
        <div id="calendar-wrapper">
            <form id="calendar-navigation-form">
                <table class="table is-borderless" style="width: 100%" id="cal-input-fields">
                </table>
            </form>
            <table class="table" style="width: 100%" id="calendarTable">
                <tr><th>Please Wait....</th></tr>
            </table>
        </div>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.card', ['title' => 'Detail: Silakan Pilih Tanggal', 'id'=>'detail']); ?>
        <div class="columns">
            <form class="column is-two-third" id="events-form">
                <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Hari Aktif']); ?>
                    <input disabled id="events-active" type="radio" name="events-active" checked/>
                    <label for="events-active" >Ya</label>
                    <input disabled id="events-non-active" type="radio" name="events-active"/>
                    <label for="events-non-active">Tidak</label>         
                <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Keterangan Agenda']); ?>
                    <textarea disabled autocomplete="false" class="textarea" id="events-description" placeholder="Keterangan"
                        rows="2"></textarea>
                <?php echo $__env->renderComponent(); ?>
                
            </form>
            <?php echo $__env->make('partials.shared.calendar-legend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->renderComponent(); ?>
    </div>
    <script type="text/javascript">
        const eventActiveToggleRadios = document.getElementsByName("events-active");
        const eventDescriptionTextarea = byId("events-description");
        const info = byId("info");
        const eventActiveRadio = byId("events-active");
        const eventInActiveRadio = byId("events-non-active");
        const formCardTitle = byId("card-header-detail");

        for (let i = 0; i < eventActiveToggleRadios.length; i++) {
            const radio = eventActiveToggleRadios[i];
            radio.onchange = function(e) {
                eventItemData.active = e.target.checked && e.target.id == "events-active";
            }
        }
        eventDescriptionTextarea.onkeyup = function(e) {
            eventItemData.description = e.target.value;
        }
        eventDescriptionTextarea.value = null;

    </script>
    <!-- CALENDAR CALLBACKS -->
    <script type="text/javascript">
        addOnloadHandler(loadCalendar);
        
        //when detail BUTTON is clicked
        function dateItemClickedCallback(day, month, year) {
            if (day == null || month == null || year == null) {
                return;
            }

            setFormTitle(day, month, year, null);
            setEventItemData(day, month, year);

        };

        //when one month calendar loaded
        function monthDataLoadedCallback(month, year) {
            selectedMonth = month;
            selectedYear = year;
            loadEvents();
        }

    </script>
    <script type="text/javascript">
        
        function setFormTitle(day, month, year, additional) {
            const monthName = MONTHS[month - 1].name;
            additional = additional != null ? additional : "";
            formCardTitle.innerHTML = "Detail: " + day + " " + monthName + " " + year + " " +
                additional;
        }

        function fillDateItem(d, m, y) {
            const element = createHtml("div", "");
            element.id = "detail-date-element-"+d+"-"+m;
            element.className = "detail-date-element";
            return element;
        };

        function setEventItemData(day, month, year) {
            eventItemData.day = day;
            eventItemData.month = month;
            eventItemData.year = year;
            eventItemData.setDefault();

            populateDetailEventInputs(eventItemData);

            loadEventsByDayAndMonth(day, month);
        }

        function populateDetailEventInputs(eventItemData) {

            eventDescriptionTextarea.value = eventItemData.description;
            eventActiveRadio.checked = eventItemData.active == true;
            eventInActiveRadio.checked = eventItemData.active == false;
        }
        
        function populateDetailEvent(response) {
            const eventItemDataList = response.eventItemDataList;
            if ((eventItemDataList == null || 0 == eventItemDataList.length) &&
                response.eventItemData == null) {
                formCardTitle.innerHTML += ' (Belum ada data)';
                return;
            }
            const loadedEventItemData = response.eventItemData != null ? response.eventItemData : eventItemDataList[0];
            eventItemData.populate(loadedEventItemData);
            populateDetailEventInputs(eventItemData);

            setFormTitle(loadedEventItemData.day, loadedEventItemData.month, loadedEventItemData.year, " (Record id: " +
                loadedEventItemData.id + ")");

            if (loadedEventItemData.active) {
                const monthName = MONTHS[loadedEventItemData.month - 1].name;
                const stringDate = loadedEventItemData.day+" "+ monthName+ " "+loadedEventItemData.year;
                
                confirmDialog("Isi data siswa tanggal "+stringDate+"?")
                .then(function(ok){
                    if(ok){
                        const dateQueryString = "day="+loadedEventItemData.day+"&month="+loadedEventItemData.month+"&year="+loadedEventItemData.year;
                        // openInNewTab(URL_EVENTS_V2+"/mutabaah/edit?"+dateQueryString);
                        window.location.href = (URL_EVENTS_V2+"/mutabaah/edit?"+dateQueryString);
                    }
                });
            }
        }

        function populateCalendar(response) {
            clearDateElement();
            const eventItemDataList = response.eventItemDataList;
            if (null == eventItemDataList) {
                return;
            }
            const eventsCurrentMonth = getEventDaysData(eventItemDataList);
            info.innerHTML = "Aktif: "+eventsCurrentMonth.active+", non-aktif: "+eventsCurrentMonth.nonActive+", total: "+eventsCurrentMonth.total;
            for (let i = 0; i < eventItemDataList.length; i++) {
                const element = eventItemDataList[i];
                populateEventsDateItem(element);
            }
        }
        
        populateDetailEventInputs(eventItemData);
       
    </script>
    <!-- AJAX CALLS -->
    <script type="text/javascript"> 
       
        function loadEvents() {
            startLoading();
            const month = selectedMonth;
            const year = selectedYear;
            axios.get(URL_EVENTS_V1 + "/filter?filter=events&month=" + month + "&year=" + year)
                .then(function(response) {
                    const payload = response.data;
                    populateCalendar(payload);
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);

        }

        function loadEventsByDayAndMonth(day, month) {
            startLoading();
            axios.get(URL_EVENTS_V1 + "/filter?filter=events&month=" + month + "&day=" + day+"&year="+selectedYear)
                .then(function(response) {
                    const payload = response.data;
                    populateDetailEvent(payload);
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);

        } 
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/dailyactivitiesv2/index.blade.php ENDPATH**/ ?>