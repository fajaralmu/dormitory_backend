<?php
    $original_tanggal_pelaksanaan = null;
    if(Arr::has($hasil, 'tanggal_pelaksanaan')) {
        $original_tanggal_pelaksanaan = (Arr::get($hasil, 'tanggal_pelaksanaan'))->format('Y-m-d');
    }
?>

<form action="<?php echo e($route); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <?php if(isset($is_update)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="field is-horizontal">
        <div class="field-label is-normal">
            <label for="tanggal_pelaksanaan">Tanggal Pelaksanaan</label>
        </div>
        <div class="field-body">
            <div class="field is-narrow">
                <div class="control">
                    <input name="tanggal_pelaksanaan" type="date" class="input<?php echo e($errors->has('tanggal_pelaksanaan') ? ' is-danger' : ''); ?>" value="<?php echo e(old('tanggal_pelaksanaan', $original_tanggal_pelaksanaan)); ?>">
                </div>
            </div>
        </div>
    </div>

    <table class="table is-fullwidth">
        <thead>
            <tr>
                <th>Nomor</th>
                <th>Kelancaran</th>
                <th>Fashohah</th>
                <th>Tajwid</th>
            </tr>
        </thead>
        <?php for($i = 1; $i <= $settings['jumlah_soal_ujian_pekanan']; $i++): ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td>
                    <input type="number" name="kelancaran[<?php echo e($i); ?>]" class="input<?php echo e($errors->has('kelancaran.' . $i) ? ' is-danger' : ''); ?>" value="<?php echo e(old('kelancaran.' . $i, Arr::get($hasil, 'detail.kelancaran.' . $i))); ?>">
                </td>
                <td>
                    <input type="number" name="fashohah[<?php echo e($i); ?>]" class="input<?php echo e($errors->has('fashohah.' . $i) ? ' is-danger' : ''); ?>" value="<?php echo e(old('fashohah.' . $i, Arr::get($hasil, 'detail.fashohah.' . $i))); ?>">
                </td>
                <td>
                    <input type="number" name="tajwid[<?php echo e($i); ?>]" class="input<?php echo e($errors->has('tajwid.' . $i) ? ' is-danger' : ''); ?>" value="<?php echo e(old('tajwid.' . $i, Arr::get($hasil, 'detail.tajwid.' . $i))); ?>">
                </td>
            </tr>
        <?php endfor; ?>
    </table>

    <p>
        <button class="button is-primary">Submit</button>
    </p>
</form><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/penilaian-periodik/hasil/form.blade.php ENDPATH**/ ?>