 

<?php $__env->startSection('content'); ?>
    <h1 class="title">Penilaian Harian Halaqoh <?php echo e($halaqoh->nama); ?> <?php echo e($date_str); ?> <small><?php echo e(($time == 'morning' ? 'Pagi' : 'Sore')); ?></small></h1>
    <?php echo $__env->make('admin.laporan.harian.select-time', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startComponent('components.card', ['title'=> 'Formulir']); ?>
        <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Tampilan Input"]); ?>
            <div class="select" style="margin-bottom:10px">
                <form>
                <select autocomplete="off" onchange="updateDisplayedInput(event);">
                    <option value="all">Semua</option>
                    <option value="general">Umum</option>
                    <option value="recitation">Setoran</option>
                    <option value="rule-violation">Pelanggaran</option>
                    <option value="other">Lain Lain</option>
                </select>
                </form>
            </div>
        <?php echo $__env->renderComponent(); ?>
        <form id="input-daily-activities" onsubmit="submitDailyActivities(event)">
            <div class="columns">
                <div class="column is-one-fifth input-section" >
                    <table class="table">
                        <thead>
                            <tr><th class="has-background-warning" colspan="2">Siswa</th></tr>
                            <tr  style="height: 100px"><th>No</th><th>Nama<br/>Siswa</th></tr></thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="row <?php echo e(($loop->index % 2 == 0) ? 'has-background-light':''); ?> ">
                                <td>
                                    <?php echo e($loop->index + 1); ?>

                                </td>
                                <td class="student-name"><?php echo e($student->name); ?> <strong><?php echo e($student->level . $student->rombel); ?></strong>
                                    <input class="input-row" name="siswa_id" type="hidden" value="<?php echo e($student->id); ?>" />
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="column input-section" style="overflow: scroll">
                    <table class="table">
                        <thead>
                            <tr>
                                <th style="margin-right:2px" class="group-general has-background-light has-text-centered" colspan="5">Umum</th>
                                <th style="margin-right:2px" class="group-recitation has-background-success has-text-centered" colspan="6">Data Setoran</th>
                                <th style="margin-right:2px" class="group-rule-violation has-background-warning has-text-centered" colspan="7">Pelanggaran</th>
                                <th class="group-other has-background-light has-text-centered">Lain</th>
                            </tr>
                            <tr style="height: 100px">
                                <th class="group-general">Record Id</th>
                                <th class="group-general">Waktu</th>
                                <th class="group-general">Kehadiran</th>
                                <th class="group-general">Opening</th>
                                <th class="group-general">Closing</th>
                                
                                <th class="group-recitation">Setor</th>
                                <th class="group-recitation">Juz Mulai</th>
                                <th class="group-recitation">Hal</th>
                                <th class="group-recitation">Juz Akhir</th>
                                <th class="group-recitation">Hal</th>
                                <th class="group-recitation">Jenis</th>
                                
                                <th class="group-rule-violation">luar area</th>
                                <th class="group-rule-violation">tidak berseragam</th>
                                <th class="group-rule-violation">bercanda</th>
                                <th class="group-rule-violation">tidur</th>
                                <th class="group-rule-violation">curang</th>
                                <th class="group-rule-violation">adab</th>
                                <th class="group-rule-violation">bermain gadget</th>
                                
                                <th class="group-other">Catatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="daily-activities-input-row row <?php echo e(($loop->index % 2 == 0) ? 'has-background-light':''); ?> " id="daily-activities-row-<?php echo e($student->id); ?>">
                                    <td class="group-general">
                                        <p style="font-size: 0.7em" class="input-row" data-name="id">No data</p>
                                    </td>
                                    <td class="group-general">
                                        <input class="input-row" name="siswa_id" type="hidden" value="<?php echo e($student->id); ?>" />
                                        <input size="8" class="input-row" name="time" disabled value="<?php echo e(($time == 'morning' ? 'Pagi' : 'Sore')); ?>" />
                                    </td>
                                    <td class="group-general">
                                        <select disabled class="select input-row" name="presence"  >
                                            <option value="h">Hadir</option>
                                            <option value="s">Sakit</option>
                                            <option value="i">Izin</option>
                                            <option value="a">Alpa</option>
                                        </select></td>
                                    <td class="group-general"><p class="input-row check-opening" data-type="checkbox"  data-name="opening"   ></p></td>
                                    <td class="group-general"><p class="input-row check-closing" data-type="checkbox" data-name="closing"  ></p></td>
                                    
                                    <td class="group-recitation"><p class="input-row check-setoran"  data-type="checkbox" data-name="is_recited"  ></p></td>
                                    <td class="group-recitation"><p class="input-row"  data-name="juz_start"   ></p></td>
                                    <td class="group-recitation"><p class="input-row"  data-name="juz_page_start"  ></p></td>
                                    <td class="group-recitation"><p class="input-row"  data-name="juz_end"   ></td>
                                    <td class="group-recitation"><p class="input-row"  data-name="juz_page_end"   ></p></td>
                                    <td class="group-recitation"><select disabled class="select input-row" name="recitation_type"  >
                                        <option value="0">Murojaah</option>
                                        <option value="1">Baru</option>
                                        <option value="2">Ujian</option>
                                    </select></td>
                                   
                                    
                                    <td class="group-rule-violation"><p class="input-row" data-type="checkbox"  data-name="rule_break_area"  ></p></td>
                                    <td class="group-rule-violation"><p class="input-row" data-type="checkbox"  data-name="rule_break_dresscode"  ></p></td>
                                    <td class="group-rule-violation"><p class="input-row" data-type="checkbox" data-name="rule_break_joke"  ></p></td>
                                    <td class="group-rule-violation"><p class="input-row" data-type="checkbox" data-name="rule_break_sleep"  ></p></td>
                                    <td class="group-rule-violation"><p class="input-row" data-type="checkbox" data-name="rule_break_cheat"  ></p></td>
                                    <td class="group-rule-violation"><p class="input-row" data-type="checkbox" data-name="rule_break_attitude"  ></p></td>
                                    <td class="group-rule-violation"><p class="input-row" data-type="checkbox" data-name="rule_break_play_gadget"  ></p></td>
                                    
                                    <td class="group-other"><p class="input-row"  data-name="description"  ></p></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>
    <?php echo $__env->renderComponent(); ?>
    <script type="text/javascript"> 
        const dailyActivities  = <?php echo json_encode($dailyActivities); ?>;
       
        function populateDailyActivitiesInput(dailyActivities)
        {
            for (let i = 0; i < dailyActivities.length; i++) {
                const dailyActivity = dailyActivities[i];
                const rowInput = document.getElementById("daily-activities-row-"+dailyActivity.siswa_id);
                const inputs = rowInput.getElementsByClassName("input-row");
                for (let j = 0; j < inputs.length; j++) {
                    const input = inputs[j];
                    const name = input.getAttribute("data-name");
                    const type = input.getAttribute("data-type");
                    if (type == "checkbox") {
                        input.innerHTML = dailyActivity[name] == true ? "ya":"-";
                    } else if (input.tagName == "SELECT") {
                        input.value = dailyActivity[input.name];
                    } else {
                        input.innerHTML = dailyActivity[name];
                    }
                }
            }
        }
    </script>
    <script type="text/javascript">

        function updateDisplayedInput(e) {
            e.preventDefault();
            const value = e.target.value;
            if (value == 'all') {
                setAllInputDisplay(null);
                return;
            }
            setAllInputDisplay('none');
            const inputs = document.getElementsByClassName("group-"+value);
            for (let i = 0; i < inputs.length; i++) {
                const element = inputs[i];
                element.style.removeProperty('display');
            }
        }

        function setAllInputDisplay(display) {
            const generalInputs = document.getElementsByClassName("group-general");
            const recitationInputs = document.getElementsByClassName("group-recitation");
            const ruleViolationInputs = document.getElementsByClassName("group-rule-violation");
            const otherInputs = document.getElementsByClassName("group-other");
            const all = [...generalInputs, ...recitationInputs, ...ruleViolationInputs, ...otherInputs];
            for (let i = 0; i < all.length; i++) {
                const element = all[i];
                if (display == null) {
                    element.style.removeProperty('display');
                } else {
                    element.style.display = display;
                }
            }
        } 
        document.getElementById("select-time").value = "<?php echo e($time); ?>";
        populateDailyActivitiesInput(dailyActivities );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/harian/detail.blade.php ENDPATH**/ ?>