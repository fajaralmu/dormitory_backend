<!DOCTYPE html>
<html lang="en" class="has-navbar-fixed-top">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Tahfiz App | Penilaian Akhir Semester</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bulma.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.css')); ?>">
</head>
<body>
    <?php
        $kelas = $student->kelas;
        $is_mobile = $agent->isMobile(); 
    ?>
    <?php echo $__env->make('tester.pas.students.penilaian.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div>
        <div style="padding: 10px 20px;" class="notification is-radiusless is-warning">
            <div class="level">
                <div class="level-left">
                    <strong><?php echo e(Str::limit($student->user->name, 25)); ?></strong>
                    <span style="margin: 0 10px;">|</span>
                    <span style="margin-right: 10px;" class="is-hidden-mobile">Penilaian akhir semester </span>
                    <strong>(JUZ <?php echo e(App\Traits\Quran::getJuzLabel($juz)); ?>)</strong>
                </div>
                <div class="level-right is-hidden-mobile">
                    <a href="<?php echo e(route('tester.pas.students.show', $student)); ?>" class="button is-dark is-rounded">
                        <span class="icon">
                            <i class="fas fa-list"></i>
                        </span>
                        <span>Daftar Juz Diuji</span>
                    </a>
                </div>
            </div>
        </div>

        <div id="app">
            <?php if($is_last_level): ?>
                <examination-last-level is_mobile="<?php echo e($is_mobile); ?>" max_scores="<?php echo e(json_encode($max_scores)); ?>"></examination-last-level>
            <?php else: ?>
                <examination is_mobile="<?php echo e($is_mobile); ?>" max_scores="<?php echo e(json_encode($max_scores)); ?>"></examination>
            <?php endif; ?>
        </div>
        <div class="is-hidden-desktop" style="position: fixed;bottom: 15px; right: 20px;">
            <a href="<?php echo e(route('tester.pas.students.show', $student)); ?>" class="button is-white">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Juz Diuji</span>
            </a>
        </div>
    </div>

    
    <script src="<?php echo e(asset('js/burger.js')); ?>"></script>
    <script src="<?php echo e(mix('js/examination.js')); ?>"></script>
</body>
</html><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/tester/pas/students/penilaian/show.blade.php ENDPATH**/ ?>