 <?php $__env->startSection('detail'); ?>
<h1 class="title">Halaqoh <span class="tag is-dark">Members</span></h1>

<div class="box">
	<h4 class="title is-4"><?php echo e($halaqoh->nama); ?> <span class="has-text-info has-text-weight-light is-size-5">(Ust. <?php echo e($halaqoh->pegawai->user->name); ?>)</span></h4>
</div>

<?php if($halaqoh->members->count()): ?>
	<table class="table is-fullwidth is-vcentered">
		<thead>
			<tr>
				<th>#</th>
				<th>Nama Siswa</th>
				<th>Sekolah</th>
				<th>Kelas</th>
				<th class="has-text-centered">Kategori</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $halaqoh->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
					$sekolah = $schools->where('id', $member->siswa->kelas->sekolah_id)->first();
					$jurusan = config('school.pilihan_jurusan.' . $member->siswa->kelas->jurusan);
					$kelas = $member->siswa->kelas->level . $member->siswa->kelas->rombel;

					if ($sekolah->jenjang === 'menengah_atas') {
						$kelas .= ' (' . $jurusan . ')';
					}
				?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($member->siswa->user->name); ?></td>
					<td><?php echo e($sekolah->nama); ?></td>
					<td><?php echo e($kelas); ?></td>
					<td class="has-text-centered"><span class="tag is-dark"><?php echo e($member->level); ?></span></td>
					<td class="has-text-right">
						  <a href="<?php echo e(url('musyrif/'.$halaqoh->id.'/member/'.$member->id)); ?>" class="button is-text has-text-primary">
							<i class="fas fa-list"></i>
						</a>  
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php else: ?>
	<div class="notification is-warning">
		No members yet.
	</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/dashboard.blade.php ENDPATH**/ ?>