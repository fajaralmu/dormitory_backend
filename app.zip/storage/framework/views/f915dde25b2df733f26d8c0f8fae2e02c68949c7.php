<?php $__env->startSection('content'); ?>
    <h1 class="title">Penguji <span class="tag is-dark">Penilaian Akhir</span></h1>

    <div class="box">
        <h4 class="title is-4"><?php echo e($penguji->pegawai->user->name); ?></h4>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.pas.penguji.students.index', $penguji)); ?>" class="button is-dark is-outlined">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks Siswa Diuji</span>
            </a>
        </div>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'New siswa diuji']); ?>
        <?php echo $form; ?>

    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('extra_script'); ?>
    <script>
        var students = <?php echo json_encode($students, 15, 512) ?>;

        var kelasSelection = document.querySelector('select#kelas');
        var studentSelection = document.querySelector('select#siswa');
        kelasSelection.addEventListener('change', function() {
            var studentsOptions = '<option value="none">-- Choose Siswa --</option>';
            if (this.value == 'none') {
                studentSelection.innerHTML = studentsOptions;
            } else {
                for (id in students[this.value]) {
                    studentsOptions += '<option value="' + id + '">' + students[this.value][id] + '</option>';
                }

                studentSelection.innerHTML = studentsOptions;
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pas/penguji/students/create.blade.php ENDPATH**/ ?>