<?php $__env->startSection('content'); ?>
    <div style="width: 100%; text-align: center">
        <article class="message is-danger">
            <div class="message-header">
            <p>Terjadi Kesalahan</p>
            </div>
            <div class="message-body">
                <?php if(is_null($message)): ?>
                    Silakan hubungi admin terkait
                <?php else: ?>
                    <?php echo e($message); ?>

                <?php endif; ?>
            </div>
        </article>
    </div>
    <script type="text/javascript">
        document.title = "Kesalahan";
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/shared/error-page.blade.php ENDPATH**/ ?>