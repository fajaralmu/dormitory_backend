<?php $__env->startSection('detail'); ?>

    <script type="text/javascript">
        const URL_EVENTS = "<?php echo e(url('/musyrif/harianv2')); ?>";
        const day = "<?php echo e(request()->get('day')); ?>";
        const month = "<?php echo e(request()->get('month')); ?>";
        const year = "<?php echo e(request()->get('year')); ?>";
        const queryString ="filter=only_daily_activity&day="+day+
            "&month="+month+"&year="+year;
        const presenceInfo = <?php echo json_encode($presenceInfo); ?>;
        const dailyActivities  = <?php echo json_encode($dailyActivities); ?>;

    </script> 

    <h1 class="title">Penilaian Harian <?php echo e($date_str); ?> <?php echo e(($time == 'morning' ? 'Pagi' : 'Sore')); ?></h1>
    <?php echo $__env->make('musyrif.dailyactivitiesv2.select-time', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php $__env->startComponent('components.card', ['title'=> 'Formulir']); ?>
        <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Tampilan Input"]); ?>
            <div class="select" style="margin-bottom:10px">
                <form>
                <select autocomplete="off" onchange="updateDisplayedInput(event);">
                    <option value="all">Semua</option>
                    <option value="general">Umum</option>
                    <option value="recitation">Setoran</option>
                    <option value="rule-violation">Pelanggaran</option>
                    <option value="other">Lain Lain</option>
                </select>
                </form>
            </div>
        <?php echo $__env->renderComponent(); ?>
        <form id="input-daily-activities" onsubmit="submitDailyActivities(event)">
            <div class="columns">
                <div class="column is-one-fifth input-section" >
                    <table class="table">
                        <thead>
                            <tr><th class="has-background-warning" colspan="2">Siswa</th></tr>
                            <tr  style="height: 100px"><th>No</th><th>Nama<br/>Siswa</th></tr></thead>
                        <tbody>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="row <?php echo e(($loop->index % 2 == 0) ? 'has-background-light':''); ?> ">
                                <td>
                                    <?php echo e($loop->index + 1); ?>

                                </td>
                                <td class="student-name"><?php echo e($student->name); ?> <strong><?php echo e($student->level . $student->rombel); ?></strong>
                                    <input class="input-row" name="siswa_id" type="hidden" value="<?php echo e($student->id); ?>" />
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <div class="column input-section" style="overflow: scroll">
           
            <table class="table" style="table-layout: fixed"> 
                <thead>
                    <tr>
                        <th style="margin-right:2px" class="group-general has-background-light has-text-centered" colspan="5">Umum</th>
                        <th style="margin-right:2px" class="group-recitation has-background-success has-text-centered" colspan="6">Data Setoran</th>
                        <th style="margin-right:2px" class="group-rule-violation has-background-warning has-text-centered" colspan="7">Pelanggaran</th>
                        <th class="group-other has-background-light has-text-centered" colspan="2">Lain</th>
                    </tr>
                    <tr style="height: 100px">
                        <th class="group-general">Record Id</th>
                        <th class="group-general">Waktu</th>
                        <th class="group-general">Kehadiran</th>
                        <th class="group-general"><div style="width:70px; ">Opening <br/> 
                            <a onclick="checkall('opening')" class="tag is-success" >
                                  <i class="fas fa-check"></i>
                            </a>
                            <a onclick="uncheckall('opening')" class="tag is-danger" >
                                <i class="fas fa-times"></i>
                            </a>
                            </div>
                        </th>
                        <th class="group-general"><div style="width:70px; ">Closing <br/>
                            <a onclick="checkall('closing')" class="tag is-success" ><i class="fas fa-check"></i></a>
                          <a onclick="uncheckall('closing')" class="tag is-danger" ><i class="fas fa-times"></i></a>
                        </div>
                        </th>
                        
                        <th class="group-recitation"><div style="width:70px; ">Setoran <br/>
                            <a onclick="checkall('setoran')" class="tag is-success" ><i class="fas fa-check"></i></a>
                          <a onclick="uncheckall('setoran')" class="tag is-danger" ><i class="fas fa-times"></i></a>
                          </div>
                        </th>
                        <th class="group-recitation">Juz Mulai</th>
                        <th class="group-recitation">Juz Akhir</th>
                        <th class="group-recitation">Hal Mulai</th>
                        <th class="group-recitation">Hal Akhir</th>
                        <th class="group-recitation">Jenis Setoran
                            <select autocomplete="off" onchange="setAllRecitationType(event)">
                                <option value="1">Baru</option>
                                <option value="0">Murojaah</option>
                                <option value="2">Ujian</option>
                            </select>

                        </th>
                        
                        <th class="group-rule-violation">luar area</th>
                        <th class="group-rule-violation">tidak berseragam</th>
                        <th class="group-rule-violation">bercanda</th>
                        <th class="group-rule-violation">tidur</th>
                        <th class="group-rule-violation">curang</th>
                        <th class="group-rule-violation">adab</th>
                        <th class="group-rule-violation">bermain gadget</th>
                        
                        <th class="group-other">Catatan <br/>
                            <a class="tag is-danger" onclick="clearNotes()">Clear All</a>
                        </th>
                        <th class="group-other">Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="daily-activities-input-row row <?php echo e(($loop->index % 2 == 0) ? 'has-background-light':''); ?> " id="daily-activities-row-<?php echo e($student->id); ?>">
                            <td class="group-general">
                                <input id="record-id-<?php echo e($student->id); ?>" autocomplete="off" size="8" value="No data" class="input-row" name="id" disabled /> 
                            </td>
                            <td class="group-general">
                                <input autocomplete="off" class="input-row" name="siswa_id" type="hidden" value="<?php echo e($student->id); ?>" />
                                <input autocomplete="off" type="hidden" size="8" class="input-row" name="time" disabled value="<?php echo e(($time)); ?>" />
                                <label><?php echo e(($time=='morning'?'Pagi':'Sore')); ?></label>
                            </td>
                            <td class="group-general"><select class="select input-row" name="presence" id="kehadiran">
                                    <option value="h">Hadir</option>
                                    <option value="s">Sakit</option>
                                    <option value="i">Izin</option>
                                    <option value="a">Alpa</option>
                                </select></td>
                            <td class="group-general"><input class="input-row check-opening" autocomplete="off" name="opening"  type="checkbox" /></td>
                            <td class="group-general"><input class="input-row check-closing" autocomplete="off" name="closing" type="checkbox" /></td>
                            
                            <td class="group-recitation" ><input class="input-row check-setoran" autocomplete="off" name="is_recited" type="checkbox" /></td>
                            <td class="group-recitation"><input size="5" class="input-row" autocomplete="off" name="juz_start" type="number" min="1" max="30" /></td>
                            <td class="group-recitation"><input size="5" class="input-row" autocomplete="off" name="juz_end" type="number" min="1" max="30" /></td>
                            <td class="group-recitation"><input size="5" class="input-row" autocomplete="off" name="juz_page_start" type="number" min="1" max="30" /></td>
                            <td class="group-recitation"><input size="5" class="input-row" autocomplete="off" name="juz_page_end" type="number" min="1" max="30" /></td>
                            <td class="group-recitation">
                                
                                <select autocomplete="off" class="input-row" name="recitation_type">
                                    <option value="1">Baru</option>
                                    <option value="0">Murojaah</option>
                                    <option value="2">Ujian</option>
                                </select>
                            </td>
                            
                            <td class="group-rule-violation"><input class="input-row" autocomplete="off" name="rule_break_area" type="checkbox" /></td>
                            <td class="group-rule-violation"><input class="input-row" autocomplete="off" name="rule_break_dresscode" type="checkbox" /></td>
                            <td class="group-rule-violation"><input class="input-row" autocomplete="off" name="rule_break_joke" type="checkbox" /></td>
                            <td class="group-rule-violation"><input class="input-row" autocomplete="off" name="rule_break_sleep" type="checkbox" /></td>
                            <td class="group-rule-violation"><input class="input-row" autocomplete="off" name="rule_break_cheat" type="checkbox" /></td>
                            <td class="group-rule-violation"><input class="input-row" autocomplete="off" name="rule_break_attitude" type="checkbox" /></td>
                            <td class="group-rule-violation"><input class="input-row" autocomplete="off" name="rule_break_play_gadget" type="checkbox" /></td>
                            
                            <td class="group-other"><textarea rows="1" class="input-row input-notes" autocomplete="off" name="description" ></textarea></td>
                            <td class="group-other"><a class="button is-danger is-small" id="action-delete-<?php echo e($student->id); ?>">Delete</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        </div>
        <div class="has-text-centered">
            <div class="control">
                <input class="button is-primary" value="Simpan" type="Submit" />
                <a class="button is-danger" onclick="deleteAllRecord()">Hapus Semua Data</a>
            </div>
        </div>
        </form>
    <?php echo $__env->renderComponent(); ?>

    <!-- Components -->
    <script type="text/javascript"> 
        function setAllRecitationType (e) {
            const inputs = document.getElementsByName('recitation_type');
            for (let i = 0; i < inputs.length; i++) {
                const input = inputs[i];
                input.value = e.target.value;
            }
        }
        function clearNotes() {
            confirmDialog("Clear Catatan?").then(function(ok){
                if (!ok) return;
                const inputs = document.getElementsByClassName("input-notes");
                for (let j = 0; j < inputs.length; j++) {
                    const input = inputs[j];
                    input.value = null;
                }
            })
        }
        function checkall(code) {
            confirmDialog("<b>Check</b> "+(new String(code).toUpperCase())+" ALL?").then(function(ok){
                if (!ok) return;
                const inputs = document.getElementsByClassName("check-"+code);
                for (let j = 0; j < inputs.length; j++) {
                    const input = inputs[j];
                    input.checked = true;
                }
            })
        }
        function uncheckall(code) {
            confirmDialog("<b>UnCheck</b> "+(new String(code).toUpperCase())+" ALL?").then(function(ok){
                if (!ok) return;
                const inputs = document.getElementsByClassName("check-"+code);
                for (let j = 0; j < inputs.length; j++) {
                    const input = inputs[j];
                    input.checked = false;
                }
            })
        }
        
        function populateDailyActivitiesInput(dailyActivities)
        {
            for (let i = 0; i < dailyActivities.length; i++) {
                const dailyActivity = dailyActivities[i];
                const studentId = dailyActivity.siswa_id;
                const rowInput = document.getElementById("daily-activities-row-"+studentId);
                const inputs = rowInput.getElementsByClassName("input-row");
                for (let j = 0; j < inputs.length; j++) {
                    const input = inputs[j];
                    const inputName = input.name;
                    if (input.type == "checkbox") {
                        input.checked = dailyActivity[inputName] == true;
                    } else {
                        input.value = dailyActivity[inputName];
                    }
                }

                //action events
                const deleteBtn = document.getElementById("action-delete-"+studentId);
                deleteBtn.onclick = function(e) { deleteRecord(dailyActivity.id)}
            }
        }
    </script>
    <script type="text/javascript">

        function updateDisplayedInput(e) {
            e.preventDefault();
            const value = e.target.value;
            if (value == 'all') {
                setAllInputDisplay(null);
                return;
            }
            setAllInputDisplay('none');
            const inputs = document.getElementsByClassName("group-"+value);
            for (let i = 0; i < inputs.length; i++) {
                const element = inputs[i];
                element.style.removeProperty('display');
            }
        }

        function setAllInputDisplay(display) {
            const generalInputs = document.getElementsByClassName("group-general");
            const recitationInputs = document.getElementsByClassName("group-recitation");
            const ruleViolationInputs = document.getElementsByClassName("group-rule-violation");
            const otherInputs = document.getElementsByClassName("group-other");
            const all = [...generalInputs, ...recitationInputs, ...ruleViolationInputs, ...otherInputs];
            for (let i = 0; i < all.length; i++) {
                const element = all[i];
                if (display == null) {
                    element.style.removeProperty('display');
                } else {
                    element.style.display = display;
                }
            }
        }
        
        function submitDailyActivities(e) {
            e.preventDefault();
            const form = e.target;
            confirmDialog("Submit Data?").then(function(ok){
                if (ok) {  storeData(form); }
            });
        }

        function getDailyActivityData(inputs) {
            const dailyActivity = {};
            for (let j = 0; j < inputs.length; j++) {
                const input = inputs[j];
                let value;
                if (input.type == "checkbox") {
                    value = input.checked == true;
                } else if (input.type == "number") {
                    if (input.value == null || input.value == "") {
                        value = null;
                    } else {
                        value = parseInt(input.value);
                    }
                } else {
                    value = input.value;
                }
                dailyActivity[input.name] = value;
            }
            return dailyActivity;
        }

        function deleteRecord(id) {
            confirmDialog("Hapus record?").then(function(ok) {
                if (ok) {  callDelete(id); }
            })
        }

        function deleteAllRecord() {
            confirmDialog("Hapus Semua record?").then(function(ok) {
                if (ok) {  callDeleteAll(); }
            })
        }

        document.getElementById("select-time").value = "<?php echo e($time); ?>";
        populateDailyActivitiesInput(dailyActivities );
    </script>
    <script type="text/javascript" id="AJAX-CALLS">

        function callDelete(id) {
            startLoading();
            axios.delete(URL_EVENTS + "/"+id)
                .then(function(response) {
                    infoDialog("Record deleted").then(function(e){
                        window.location.reload();
                    });
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);
        }
        function callDeleteAll() {
            startLoading();
            const deleteUrl = URL_EVENTS + "/allrecord?time=<?php echo e($time); ?>&day=<?php echo e(request()->get('day')); ?>&month=<?php echo e(request()->get('month')); ?>&year=<?php echo e(request()->get('year')); ?>";
            axios.delete(deleteUrl)
                .then(function(response) {
                    infoDialog("Record deleted").then(function(e){
                        window.location.reload();
                    });
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);
        }
        function storeData(form) {
            const inputRows = form.getElementsByClassName("daily-activities-input-row");
            const dailyActivities = [];
            for (let i = 0; i < inputRows.length; i++) {
                const element = inputRows[i];
                const inputs = element.getElementsByClassName("input-row");
                const dailyActivity = getDailyActivityData(inputs);
                dailyActivities.push(dailyActivity);
            }

            // console.debug(dailyActivities);
            
            const endPoint = URL_EVENTS+"?"+queryString;

            startLoading();
            const payload = { dailyActivityList:  dailyActivities};
            axios.post(endPoint, payload).then(function(response){
                infoDialog("Success").then(null);
                populateRecordIds(response.data);
            }).catch(function(e){
                alert("Operation failed: "+e);
            }).finally(stopLoading);
        }

        function populateRecordIds(response) {
            const dailyActivityList = response.dailyActivityList;
            for (let i = 0; i < dailyActivityList.length; i++) {
                const element = dailyActivityList[i];
                const recordIdInput = byId("record-id-"+element.siswa_id);
                if (recordIdInput) {
                    recordIdInput.value = element.id == 0 ? "Saved": element.id;
                }
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/dailyactivitiesv2/edit.blade.php ENDPATH**/ ?>