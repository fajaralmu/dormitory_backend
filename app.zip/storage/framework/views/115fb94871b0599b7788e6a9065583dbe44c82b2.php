 <?php $__env->startSection('detail'); ?>
    <?php
        $rapor_pts_link =  url('musyrif/'.$halaqoh->id.'/member/'.$member->id.'?action=rapor_pts');
        $rapor_pas_link = url('musyrif/'.$halaqoh->id.'/member/'.$member->id.'?action=rapor_pas');
    ?>
    <h1 class="title">Halaqoh <span class="tag is-dark">Members</span></h1>

    <h4 class="title is-4 has-text-weight-light">
        <span class="icon">
            <i class="fas fa-user-circle"></i>
        </span>
        <span><?php echo e($member->siswa->user->name); ?></span>
    </h4>

    <?php if($member->level === 'basic'): ?>
        <?php
            $target_route = route('admin.halaqoh.members.targets.create', [$halaqoh, $member]);

            if ($member->targets->count()) {
                $target = $member->targets->first();
                $target_route = route('admin.halaqoh.members.targets.edit', [$halaqoh, $member, $target]);
            }
            
        ?>
        <div class="level">
            <div class="level-left">
                <a href="<?php echo e($target_route); ?>" class="button is-info">
                    <span class="icon">
                        <i class="fas fa-list"></i>
                    </span>
                    <span>Target Hafalan</span>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <div class="box" id="v">
        <ul>
            <li>Sekolah: <strong><?php echo e($member->siswa->kelas->sekolah->nama); ?></strong></li>
            <li>Kelas: <strong><?php echo e($member->siswa->kelas->level . $member->siswa->kelas->rombel); ?></strong></li>
            <li>Musyrif: <strong>Ust. <?php echo e($halaqoh->pegawai->user->name); ?></strong></li>
            <li>Kategori: <strong><?php echo e(Str::title($member->level)); ?></strong></li>
            <li style="padding-top:20px">
                
                <?php if($is_fullday): ?> 
                    <a class="button is-link" href="<?php echo e($rapor_pts_link); ?>" target="_blank">Cetak Rapor PTS</a>
                <?php endif; ?>
                <a class="button is-link" href="<?php echo e($rapor_pas_link); ?>" target="_blank">Cetak Rapor PAS</a>
                 
            </li>
        </ul>
    </div> 
    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/halaqoh-detail.blade.php ENDPATH**/ ?>