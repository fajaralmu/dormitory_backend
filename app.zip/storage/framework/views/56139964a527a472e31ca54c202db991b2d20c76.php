<?php $__env->startSection('content'); ?>
    <h1 class="title">Halaqoh <span class="tag is-dark">Signature</span></h1>

    <div class="box">
        <h4 class="title is-4"><?php echo e($halaqoh->nama); ?> <span class="has-text-info has-text-weight-light is-size-5">(Ust. <?php echo e($halaqoh->pegawai->user->name); ?>)</span></h4>
    </div>

    <div class="columns">
        <div class="column">
            <?php $__env->startComponent('components.card', ['title' => 'Upload Signature']); ?>
                <?php echo $form; ?>

            <?php echo $__env->renderComponent(); ?>
        </div>
        <?php if(! is_null($halaqoh->pegawai->signature)): ?>
            <div class="column has-text-centered">
                <?php $__env->startComponent('components.card', ['title' => 'Preview TTD']); ?>
                    <img src="<?php echo e(Storage::url('signatures/' . $halaqoh->pegawai->signature)); ?>" alt="">
                <?php echo $__env->renderComponent(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/halaqoh/signature.blade.php ENDPATH**/ ?>