<?php $__env->startSection('content'); ?>
    <h1 class="title">Munaqosyah <span class="tag is-dark">Penilaian Akhir</span></h1>

    <?php $__env->startComponent('components.card', ['title' => 'Detail Score Munaqosyah']); ?>
        <div class="box has-background-warning">
            <h4 class="title is-4">
                <span class="icon">
                    <i class="fas fa-user-circle"></i>
                </span>
                <span class="has-text-weight-light"><?php echo e($student->user->name); ?></span>
            </h4>
        </div>

        <?php echo $form; ?>

    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pas/munaqosyah/show.blade.php ENDPATH**/ ?>