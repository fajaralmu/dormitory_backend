  
<?php $__env->startSection('content'); ?>
    <h1 class="title">Laporan Hasil Penilaian PAS</h1>

    <div class="box">
        <p>Kelas: <strong><?php echo e($kelas->level . $kelas->rombel); ?> <?php echo e($kelas->sekolah->nama); ?></strong></p>
    </div>

    <table class="table is-fullwidth is-vcentered">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama Siswa</th>
                <th>Kategori</th>
                <th class="has-text-centered">Harian</th>
                <th class="has-text-centered">Rapor Pts</th>
                <th class="has-text-centered">Pas</th>
                <th class="has-text-centered">Nilai Rapor</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($student->user->name); ?></td>
                    <td>
                        <?php if(! empty($student->category_label)): ?>
                            <span class="tag is-dark is-uppercase">
                                <?php echo e($student->category_label); ?>

                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="has-text-centered"><?php echo e(number_format($student->daily_score_average, 2)); ?></td>
                    <td class="has-text-centered"><?php echo e(number_format($student->pts_final_score, 2)); ?></td>
                    <td class="has-text-centered"><?php echo e(number_format($student->pas_score, 2)); ?></td>
                    <td class="has-text-centered"><?php echo e(number_format($student->final_score, 2)); ?></td>
                    <td class="has-text-right">
                        <a target="_blank" href="<?php echo e(route('admin.laporan.cetak.show', [$kelas, $student])); ?>" class="button is-text">
                            <i class="fas fa-print"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/pas/show-fullday.blade.php ENDPATH**/ ?>