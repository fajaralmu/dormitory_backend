<?php
    $aspects = [
        'kkm',
        'jumlah_soal_ujian_pekanan',
        'nilai_maksimal_ujian_semester',
    ];
    $settings = array_only($configuration->settings, $aspects);
?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Settings <span class="tag is-dark">Umum</span></h1>

    <?php $__env->startComponent('components.card', ['title' => 'Kepala Tahfiz']); ?>
        <?php echo $form; ?>

    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.card', ['title' => 'Tanda Tangan Pegawai']); ?>
    <form onsubmit="openSignaturePage(event)" >
        <div class="select">
        <select id="select-employee" class="select" name="employee">
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
        <button type="submit" class="button is-link">
            <span class="icon"><i class="fas fa-edit"></i></span>
            <span>Edit Signature</span>
        </button>
    </form>
    <?php echo $__env->renderComponent(); ?>


    <script type="text/javascript">
        const schools = <?php echo json_encode($schools); ?>;
        const employees = <?php echo json_encode($employees); ?>;

        var is_fullday = false;
        const SCORE_PROPORTIONS = {
            //all school
            periodicScoreProportion:0, semesterScoreProportion:0, munaqosyahScoreProportion:0, munaqosyahActive:true,
            //fullday pts
            ptsDailyProportion:0, ptsExamProportion:0,
            //fullday pas
            pasDailyProportion:0, pasPtsProportion:0, pasExamProportion:0
        };
        const URL_GET_SCHOOL_SCORE_PROPORTION = "<?php echo e(url('/admin/settings/school-score-proportion')); ?>";
        const URL_SAVE_SCHOOL_SCORE_PROPORTION = "<?php echo e(url('/admin/settings/school-score-proportion')); ?>";
        
        const periodic_proportion = '<?php echo e($configuration->settings["score_proportion"]["periodic"]); ?>';
        const semester_proportion = '<?php echo e($configuration->settings["score_proportion"]["semester"]); ?>';
        
        function clearScoreProportion(){
            
            setIsFullday(false);
            for (const key in SCORE_PROPORTIONS) {
                if (SCORE_PROPORTIONS.hasOwnProperty(key)) {
                    SCORE_PROPORTIONS[key] = 0;
                    if(byId(key)){
                        byId(key).value = 0;
                    }
                }
            }
        }
 
    </script>

    <?php $__env->startComponent('components.card', ['title' => 'Bobot Penilaian Dalam Persen']); ?>
        <form id="scoreProportionForm">
            
            <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Sekolah']); ?>
            <div  class="select">
                <select id="select-school" >
                    <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($school->id); ?>"><?php echo e($school->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Bobot Periodik']); ?>
                <input class="input input-proportion" data="periodicScoreProportion" id="periodicScoreProportion" type="number" max="100" min="0" />
            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Bobot Semester']); ?>
                <input class="input input-proportion" data="semesterScoreProportion" id="semesterScoreProportion" type="number" max="100" min="0" />
            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Bobot Munaqosyah']); ?>
                <input class="input input-proportion" data="munaqosyahScoreProportion" id="munaqosyahScoreProportion" type="number" max="100" min="0" />
            <?php echo $__env->renderComponent(); ?>
            <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Munaqosyah Aktif']); ?>
                <input class="input-proportion" data="munaqosyahActive" id="munaqosyahActive" type="checkbox" />
            <?php echo $__env->renderComponent(); ?>
            <article class="message is-primary">
                <div class="message-header">
                  <p>Keterangan</p>
                  
                </div>
                <div class="message-body">
                   <ol>
                        <li>Nilai semester terdiri dari nilai ujian dan nilai munaqosyah (kelas 3 & 6)</li>
                        <li>Bobot semester + bobot periodik = 100</li>
                   </ol>
                </div>
              </article>
            <div id="fullday-score-proportions">
                <div class="field" >
                    <label class="label">Bobot PTS Fullday</label>
                </div>
                <div class="field has-addons">
                    <div class="control"><a class="button is-static">Harian</a></div>
                    <div class="control">
                        <input class="input input-proportion" data="ptsDailyProportion" id="ptsDailyProportion" type="number" max="100" min="0" />
                    </div>
                    <div class="control"><a class="button is-static">Ujian PTS</a></div>
                    <div class="control">
                        <input class="input input-proportion" data="ptsExamProportion" id="ptsExamProportion" type="number" max="100" min="0" />
                    </div>
                </div>
                <div class="field" >
                    <label class="label" >Bobot PAS Fullday</label>
                </div>
                <div class="field has-addons">
                    <div class="control"><a class="button is-static">Harian</a></div>
                    <div class="control">
                        <input class="input input-proportion" data="pasDailyProportion" id="pasDailyProportion" type="number" max="100" min="0" />
                    </div>
                    <div class="control"><a class="button is-static">Nilai PTS</a></div>
                    <div class="control">
                        <input class="input input-proportion" data="pasPtsProportion" id="pasPtsProportion" type="number" max="100" min="0" />
                    </div>
                    <div class="control"><a class="button is-static">Ujian PAS</a></div>
                    <div class="control">
                        <input class="input input-proportion" data="pasExamProportion" id="pasExamProportion" type="number" max="100" min="0" />
                    </div>
                </div>
           
            </div>
            <div class="field is-horizontal" style="margin-top: 20px">
                <div class="field">
                    <button type="submit" class="button is-primary">
                        Simpan Bobot Penilaian&nbsp;<span id="school-name"></span>
                    </button>
                </div>
                <div class="field">
                    <div class="field">
                        <div id="loading-score" style="visibility: hidden; margin:10px" class="control is-loading">Please Wait ...</div>
                    </div>
                </div>
            </div>
        </form>
    <?php echo $__env->renderComponent(); ?>

    <!-- script for bobot penilaian -->
    <script type="text/javascript">
        const selectSchool = byId("select-school"); 
        const proportionInputs = document.getElementsByClassName("input-proportion"); 
        var currentSchoolId = "";

        function initInputOnKeyup(){
            for (let i = 0; i < proportionInputs.length; i++) {
                const input = proportionInputs[i];
                input.onchange = function(e){
                    const data = e.target.getAttribute("data");
                    const type = e.target.type;
                    let value = null;
                    if (type == 'checkbox') {
                        value = e.target.checked;
                    } else {
                        const intValue = parseInt(e.target.value);
                        if(intValue > 100 || intValue < 0){
                            input.value = 0;
                            return;
                        }
                        value = intValue;
                    }
                    SCORE_PROPORTIONS[data] = value;
                }
            }
        }

        function getSchoolProportion(){
           
            startLoading();
            const endpoint = URL_GET_SCHOOL_SCORE_PROPORTION + "/" + selectSchool.value;
            axios.get(endpoint)
            .then(function(response){
                if(null == response.data){
                    alert("Data Not Found");
                    return;
                }
                populateScoreProportionInputs(response.data);
            }).catch(function(e){
                console.error(e);
                alert("Server Error");
            }).finally(stopLoading);;
        }

        function populateScoreProportionInputs(data){
            clearScoreProportion();
            setIsFullday(data.is_fullday);
            setValueToInput("periodicScoreProportion", data.periodic);
            setValueToInput("munaqosyahScoreProportion", data.munaqosyah);
            setValueToInput("semesterScoreProportion", data.semester); 
            setValueToInput("munaqosyahActive", data.munaqosyah_active); 

            if(data.is_fullday){
                populateFulldayScoreProportion(data);
            }

            byId("school-name").innerHTML = selectSchool.selectedOptions[0].innerHTML;
            currentSchoolId = selectSchool.value;
        }

/**ptsDailyProportion, ptsExamProportion,
pasDailyProportion, pasPtsProportion, pasExamProportion**/
        function populateFulldayScoreProportion(data){
            //pts
            if(data.pts != null){
                setValueToInput("ptsDailyProportion", data.pts.daily);
                setValueToInput("ptsExamProportion", data.pts.pts_exam);
            }
            //pas
            if(data.pas != null){
                setValueToInput("pasDailyProportion", data.pas.daily); 
                setValueToInput("pasPtsProportion", data.pas.pts_score); 
                setValueToInput("pasExamProportion", data.pas.pas_exam); 
            }
        }

        function setValueToInput(input_id, value){
            const input = byId(input_id);
            if (input == null) return;
            if (input.type=='checkbox') {
                input.checked = value == true;
            } else {
                input.value = value;
            }
            SCORE_PROPORTIONS[input_id] = value;
        }

        function setIsFullday(is_fullday){
            this.is_fullday = is_fullday;
            if(is_fullday){
                byId("fullday-score-proportions").style.display = 'block';
            } else {
                byId("fullday-score-proportions").style.display = 'none';
            }
        }

        function saveScoreProportion(){
            startLoading();
            const payload = {
                periodic: SCORE_PROPORTIONS.periodicScoreProportion,
                munaqosyah: SCORE_PROPORTIONS.munaqosyahScoreProportion,
                semester: SCORE_PROPORTIONS.semesterScoreProportion,
                school_id: currentSchoolId,
                munaqosyah_active: SCORE_PROPORTIONS.munaqosyahActive

            }
            if(is_fullday){
                payload['pts'] = {
                    'daily':SCORE_PROPORTIONS.ptsDailyProportion,
                    'pts_exam':SCORE_PROPORTIONS.ptsExamProportion
                };
                payload['pas'] = {
                    'daily':SCORE_PROPORTIONS.pasDailyProportion,
                    'pas_exam':SCORE_PROPORTIONS.pasExamProportion,
                    'pts_score':SCORE_PROPORTIONS.pasPtsProportion
                };
            }
            axios.post(URL_GET_SCHOOL_SCORE_PROPORTION, payload)
            .then(function(response){
                infoDialog("Update success").then(function(e){
                   // populateScoreProportionInputs(response.data);
                })
                
            }).catch(function(e){
                console.error(e);
                alert("Server Error");
            }).finally(stopLoading);
        }

        function startLoading(){
            byId("loading-score").style.visibility = 'visible';
        }

        function stopLoading(){
            byId("loading-score").style.visibility = 'hidden';
        }

        scoreProportionForm.onsubmit = function(e){
            e.preventDefault();
            confirmDialog("Save Bobot Penilaian?").then(function(ok){
                if(ok){
                    saveScoreProportion();
                }
            });
        }

        selectSchool.onchange = function(e){
            confirmDialog("Change School?").then(function(ok){
                if(ok){
                    getSchoolProportion();
                } else {
                    selectSchool.value = currentSchoolId;
                }
            });
        }
        initInputOnKeyup();
        getSchoolProportion();
    </script>
    
    <script>
        const tahfizHeadForm = document.getElementById("form-kepala-tahfiz");
        function updateLabel() {
            const labels = tahfizHeadForm.getElementsByTagName("label");
            for (let i = 0; i < labels.length; i++) {
                const element = labels[i];
                const html = element.innerHTML;
                if (html.toLowerCase().startsWith("kepala")) {
                    const schoolId = html.split(" ")[1];
                    console.debug("schoolId: ", schoolId);
                    const school = getObjectByKey(schools, 'id', schoolId);
                    element.innerHTML = "Kepala "+school.nama;
                }
            }
        } 

        function openSignaturePage(e) {
            e.preventDefault();
            const selecteEmployee = document.getElementById("select-employee");
            openInNewTab("<?php echo e(url('/admin/settings/signature/')); ?>/"+selecteEmployee.value );
        }

        updateLabel();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/settings/umum/index.blade.php ENDPATH**/ ?>