<?php $__env->startSection('content'); ?>
    <h1 class="title">Settings <span class="tag is-dark">Umum</span></h1>

    <div class="columns">
        <div class="column">
            <?php $__env->startComponent('components.card', ['title' => 'Unggah Tanda Tangan']); ?>
                <?php echo $form; ?>

            <?php echo $__env->renderComponent(); ?>
        </div>
        <?php if(!is_null($signature_image_data)): ?>
            <div class="column has-text-centered">
                <?php $__env->startComponent('components.card', ['title' => 'Preview Tanda Tangan']); ?>
                    <img src="data:image/png;base64, <?php echo e($signature_image_data); ?>" alt="">
                <?php echo $__env->renderComponent(); ?>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/settings/signature/index.blade.php ENDPATH**/ ?>