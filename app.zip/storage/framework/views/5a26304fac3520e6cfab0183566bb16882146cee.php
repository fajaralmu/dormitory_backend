<?php
    $original_tanggal_pelaksanaan = null;
    if(Arr::has($hasil, 'tanggal_pelaksanaan')) {
        $original_tanggal_pelaksanaan = (Arr::get($hasil, 'tanggal_pelaksanaan'))->format('Y-m-d');
    }
?>

<form action="<?php echo e($route); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <?php if(isset($is_update)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="field is-horizontal">
        <div class="field-label is-normal">
            <label for="tanggal_pelaksanaan">Tanggal Pelaksanaan</label>
        </div>
        <div class="field-body">
            <div class="field is-narrow">
                <div class="control">
                    <input name="tanggal_pelaksanaan" type="date" class="input<?php echo e($errors->has('tanggal_pelaksanaan') ? ' is-danger' : ''); ?>" value="<?php echo e(old('tanggal_pelaksanaan', $original_tanggal_pelaksanaan)); ?>">
                </div>
            </div>
        </div>
        <div class="field-label is-normal">
            <div class="control"> 
                <label class="radio">
                    <?php if(old('is_after_pts', Arr::get($hasil, 'is_after_pts')) == 0): ?>
                        <input type="radio" name="is_after_pts" value="false" checked>
                    <?php else: ?>
                        <input type="radio" name="is_after_pts" value="false">
                    <?php endif; ?>
                    Selebum PTS
                </label>
                <label class="radio">
                    <?php if(old('is_after_pts', Arr::get($hasil, 'is_after_pts')) == 1): ?>
                        <input type="radio" name="is_after_pts" value="true" checked>
                    <?php else: ?> 
                        <input type="radio" name="is_after_pts" value="true">
                    <?php endif; ?>
                    Setelah PTS
                </label>
              </div> 
        </div>
    </div>

    <table class="table is-fullwidth">
        <thead>
            <tr>
                <th>Pemahaman Ilmu Tajwid</th>
                <th>Karakter Muslim</th> 
            </tr>
        </thead>
            <tr>
                <td>
                    <input type="number" name="tajwid" class="input<?php echo e($errors->has('tajwid') ? ' is-danger' : ''); ?>" value="<?php echo e(old('tajwid', Arr::get($hasil, 'tajwid'))); ?>">
                </td>
                <td>
                    <input type="number" name="karakter" class="input<?php echo e($errors->has('karakter') ? ' is-danger' : ''); ?>" value="<?php echo e(old('karakter', Arr::get($hasil, 'karakter'))); ?>">
                </td> 
            </tr>
    </table>
    <p>
        <button class="button is-primary">Submit</button>
    </p>
</form><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/penilaian-periodik/hasil/form_fullday.blade.php ENDPATH**/ ?>