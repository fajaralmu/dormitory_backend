<?php $__env->startSection('content'); ?>
  <div style="margin: 0 auto;">
    <div class="notification is-info">
      <span class="icon">
         <i class="fas fa-info-circle"></i>
      </span>
      <?php if(count($halaqohs)): ?>
	      <span>Please choose one of halaqohs below</span>
			<?php endif; ?>
		</div>

		<div class="columns">
			<?php if(count($halaqohs)): ?>
				<?php $__currentLoopData = $halaqohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="column" style="min-width: 350px;">
						<div class="box has-text-centered">
							<a href="<?php echo e(route('halaqoh.gateway.show', $halaqoh)); ?>">
								<h4 class="title is-4">Halaqoh</h4>
								<hr>
								<div style="margin-top: 20px;" class="icon">
									<i class="fas fa-heart fa-4x"></i>
								</div>
								<hr>
								<h4 class="title is-4"><?php echo e($halaqoh->nama); ?></h4>
							</a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/halaqoh-gateway.blade.php ENDPATH**/ ?>