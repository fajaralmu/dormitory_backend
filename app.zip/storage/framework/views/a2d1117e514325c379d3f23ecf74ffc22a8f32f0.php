<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('/css/pages/rapor.css')); ?>" rel="stylesheet">
    <title>Rapor PTS | Tahfidz</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bulma.css')); ?>">
    <style>
        td,
        tr,
        tbody,
        thead {
            background-color: transparent;
        }

        /* body {
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
        } */
        body {
            font-size: 1.2rem;

        }

        table.table.is-vcentered tr td {
            vertical-align: middle;
        }

        hr {
            background-color: #000;
            height: 1px;
        }

        .center {
            text-align: center;
        }

        .box,
        .table {
            background-color: transparent;
            font-size: 0.9em;
        }

        .borderless  th,
        .borderless td {
            border: none
        }

        table {
            font-size: 0.9em;
        }
        .container{
            padding-left: 2px;
            padding-right: 2px;
        } 

    </style>
</head>

<body>
    <div class="container is-fluid">
        <div class="header"  >
            
            <div class="has-text-centered" style="margin-bottom: 1.5rem;">
                <h3 class="title is-size-4">LAPORAN HASIL BELAJAR TAHFIDZ Al-QUR’AN</h3>
                <h4 class="subtitle title is-size-5">SISWA MTs KAFILA IBNU MAS’UD </h4>
            </div>
             
        </div>
        <div class="box">
            <table class="table borderless is-fullwidth is-vcentered">
                <tr>
                    <th  >Nama</th>
                    <td><?php echo e($student->user->name); ?></td>
                    <th>Kelas</th>
                    <td> <?php echo e($student->kelas->level . $student->kelas->rombel); ?> </td>
                </tr>
                <tr>
                    <th>NIS</th>
                    <td> <?php echo e($student->nis); ?> </td>
                    <th>Kategori</th>
                    <td> <?php echo e(strtoupper($kategori)); ?> </td>
                </tr>
                <tr>
                    <th>Tahun Ajaran</th>
                    <td><?php echo e(config('school.tahun_ajaran')); ?></td>
                    <th>Periode</th>
                    <td>Tengah Semester</td>
                </tr>
            </table>
        </div>
       
        <h4 class="is-size-6 has-text-weight-bold is-uppercase  section-title">Pengetahuan Dan Sikap</h4>
        <div class="box">
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Aspak Penilaian</th>
                        <th class="has-text-centered">Nilai</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Pemahaman Ilmu Tajwid</td>
                        <td class="has-text-centered"><?php echo e(number_format($daily_score_summary['tajwid'], 2)); ?></td>
                        <td class="has-text-centered"><?php echo e($daily_score_summary['tajwid_predikat']); ?></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>10 Karakter Muslim</td>
                        <td class="has-text-centered"><?php echo e(number_format($daily_score_summary['karakter'], 2)); ?></td>
                        <td class="has-text-centered"><?php echo e($daily_score_summary['karakter_predikat']); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <h4 class="is-size-6 has-text-weight-bold is-uppercase  section-title">Detail Penilaian</h4>
        <div class="box">
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th class="has-text-centered">Harian</th>
                        <th class="has-text-centered">PTS</th>
                        <th class="has-text-centered">PAS</th>
                        <th class="has-text-centered">Nilai Rapor</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="has-text-centered"><?php echo e(number_format($daily_score_summary['total'], 2)); ?></td>
                        <td class="has-text-centered"><?php echo e(number_format($nilai_pts, 2)); ?></td>
                        <td class="has-text-centered">-</td>
                        <td class="has-text-centered"><?php echo e(number_format($nilai_akhir, 2)); ?></td>
                        
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="bottom no-break-page" style="width: 100%; margin-bottom: 30px ; font-size: 0.9em">
            <p class="has-text-centered">Jakarta, <?php echo e($tanggal_cetak); ?> <br> Mengetahui,</p>
            <table style="width: 100%; table-layout: fixed">
                <tr>
                <?php $__currentLoopData = $signatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dir => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>    
                <div>
                        <div class="has-text-centered">
                            <p class="has-text-weight-bold" style="margin: 20px 0 -2px 0;"><?php echo e($details['as']); ?></p>
                            <div style="height: 100px;position:relative;">
                                <?php if($dir === 'left' && !is_null($stempel)): ?>
                                    <img style="height: 110%;position:absolute;top: 10px;left: 70px;transform: rotate(350deg);"
                                        src="<?php echo e(Storage::url('stamps/' . $stempel)); ?>" alt="">
                                <?php endif; ?>
                                <?php if(!is_null($details['image'])): ?>
                                    <img style="height: 100%;"
                                        src="<?php echo e(Storage::url('signatures/' . $details['image'])); ?>" alt="">
                                        
                                <?php endif; ?>
                            </div>
                            <p ><?php echo e($details['name']); ?></p>
                        </div>
                    </div>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </table>
           
        </div>
        <div class="page-break"></div>
        <h4 class="is-size-6 has-text-weight-bold is-uppercase has-text-centered section-title">Daftar Nilai Ujian</h4>
        <div class="box">
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th>Juz</th>
                        <th class="has-text-centered">Kelancaran</th>
                        <th class="has-text-centered">Fashohah</th>
                        <th class="has-text-centered">Tajwid</th>
                        <th class="has-text-centered">Nilai Juz</th>
                        
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $juz_part = null;

                        $juz_label = (string) $juz;
                        $pure_juz = $juz;
                        $raw_juz = explode( '_', $juz_label);

                        if(Str::contains ($juz_label, '_a')){
                        $juz_part = 'a';
                        $pure_juz = $raw_juz[0];
                        }
                        elseif(Str::contains ($juz_label, '_b')){
                        $juz_part = 'b';
                        $pure_juz = $raw_juz[0];
                        }
                        if(sizeof( $raw_juz) == 1){
                        array_push( $raw_juz, null);
                        }

                        $pts_detail_score = $student->getPtsDetailScores($raw_juz[0], $raw_juz[1]);
                        ?>
                        <tr>
                            <td><?php echo e(App\Traits\Quran::getJuzLabel($juz)); ?></td>
                            <td class="has-text-centered"><?php echo e($pts_detail_score['kelancaran']); ?></td>
                            <td class="has-text-centered"><?php echo e($pts_detail_score['fashohah']); ?></td>
                            <td class="has-text-centered"><?php echo e($pts_detail_score['tajwid']); ?></td>
                            <td class="has-text-centered"><?php echo e($pts_detail_score['score']); ?></td>
                            <td class="has-text-centered"><?php echo e($pts_detail_score['predikat']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="bottom no-break-page" style="width: 100%; margin-top:5px; font-size: 0.9em">
            <div class="columns">
                <div class="column is-three-fifths">
                   
                    
                </div>
                <div class="column has-text-centered">
                    <?php
                        $musyrif_details = $signatures['right']; //as musyrif
                    ?>
                        <p class="has-text-centered">Jakarta, <?php echo e($tanggal_cetak); ?></p>
                        <p class="has-text-weight-bold" style="margin: 0 0 -2px 0;">
                            <?php echo e($musyrif_details['as']); ?>

                        </p>
                        <div style="height: 90px;position:relative;">
                            <?php if(!is_null($musyrif_details['image'])): ?>
                                    <img style="height: 100%;"
                                        src="<?php echo e(Storage::url('signatures/' . $musyrif_details['image'])); ?>" alt="">
                                    
                            <?php endif; ?>
                        </div>
                        <p><?php echo e($musyrif_details['name']); ?></p>
                             
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/pts/cetak/show-fullday.blade.php ENDPATH**/ ?>