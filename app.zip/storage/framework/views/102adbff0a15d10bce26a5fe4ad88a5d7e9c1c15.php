<?php $__env->startSection('content'); ?>
    <h1 class="title">List <span class="tag is-dark">Penilaian Periodik</span></h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light">
            <span class="icon">
                <i class="fas fa-user"></i>
            </span>
            <span><?php echo e($siswa->user->name); ?></span>
        </h4>
    </div>

    <?php if($is_fullday == false && $siswa->periodic_scores->count()): ?>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Nilai</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $siswa->periodic_scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->tanggal_pelaksanaan->format('d F Y')); ?></td>
                        <td><?php echo e($item->nilai); ?></td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('admin.penilaian-periodik.details.show', [$siswa, $item])); ?>" class="button is-text">
                                <i class="fas fa-list"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php elseif($is_fullday == true && $siswa->daily_scores->count()): ?>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>#</th>
                    <td>Tanggal Pelaksanaan</td>
                    <td>Pehamahan Ilmu Tajwid</td>
                    <td>Karakter Muslim</td>
                    <td></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $siswa->daily_scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->tanggal_pelaksanaan->format('d F Y')); ?> <?php echo e($item->is_after_pts?"Setelah":"Sebelum"); ?> PTS</td>
                        <td><?php echo e($item->tajwid); ?></td>
                        <td><?php echo e($item->karakter); ?></td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('admin.penilaian-periodik.details.show', [$siswa, $item])); ?>" class="button is-text">
                                <i class="fas fa-list"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/penilaian-periodik/details/index.blade.php ENDPATH**/ ?>