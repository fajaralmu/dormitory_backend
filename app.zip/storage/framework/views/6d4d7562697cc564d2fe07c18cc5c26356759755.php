<?php
    $global_basic = Arr::get($settings, 'global_basic', []);
    $total_examined = 0;
    $total_target = 0;
?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Penguji <span class="tag is-dark">Penilaian Akhir</span></h1>

    <div class="box">
        <h4 class="title is-4"><?php echo e($penguji->pegawai->user->name); ?></h4>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.pas.penguji.students.create', $penguji)); ?>" class="button is-primary is-rounded">
                <span class="icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span>Siswa Diuji Baru</span>
            </a>
        </div>
        <div class="level-right">
            <div class="tags has-addons are-medium">
                <span class="tag is-dark">Total target</span>
                <span id="total-target" class="tag is-info">0</span>
                <span class="tag is-dark">Total diuji</span>
                <span id="total-examined" class="tag is-info">0</span>
            </div>
        </div>
    </div>

    <?php if($penguji->members->count()): ?>
        
        <?php $__env->startComponent('components.card', ['title' => 'Daftar siswa diuji']); ?>
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Musyrif</th>
                        <th>Kategori</th>
                        <th class="has-text-centered">Target</th>
                        <th class="has-text-centered">Diuji</th>
                        <th class="has-text-centered">Diselesaikan</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $penguji->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $membership = $member->siswa->halaqohs->first();
                            $kategori = array_get($membership, 'level');
                            $halaqoh_id = array_get($membership, 'halaqoh_id');
                            $total_target += $member->siswa->getPasTarget();
                            $total_examined+=$member->siswa->getPasExamined();
                        ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($member->siswa->user->name); ?></td>
                            <td><?php echo e(Arr::get($member->siswa->kelas, 'level') . Arr::get($member->siswa->kelas, 'rombel')); ?></td>
                            <td><?php echo e($halaqoh_id ? Arr::get($musyrifs, $halaqoh_id) : 'Undefined'); ?></td>
                            <td><span class="tag is-dark"><?php echo e($kategori); ?></span></td>
                            <td class="has-text-centered"><?php echo e($member->siswa->getPasTarget()); ?></td>
                            <td class="has-text-centered"><?php echo e($member->siswa->getPasExamined()); ?></td>
                            <td class="has-text-centered"><?php echo e($member->siswa->getPasFinished()); ?></td>
                            <td class="has-text-right">
                                <a href="<?php echo e(route('admin.pas.penguji.students.edit', [$penguji, $member])); ?>" class="button is-text">
                                    <i class="fas fa-exchange-alt"></i>
                                </a>
                                <?php echo $__env->make('components.delete-button', ['url' => route('admin.pas.penguji.students.destroy', [$penguji, $member])], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <script type="text/javascript">
                document.getElementById("total-target").innerHTML = "<?php echo e($total_target); ?>";
                document.getElementById("total-examined").innerHTML = "<?php echo e($total_examined); ?>";
            </script>
        <?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <div class="notification is-warning">
            No data siswa diuji yet.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pas/penguji/students/index.blade.php ENDPATH**/ ?>