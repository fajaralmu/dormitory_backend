 

<?php $__env->startSection('content'); ?>
    <h1 class="title">Students</h1>

    <div class="columns">
        <div class="column">
            <div class="box">
                <h4 class="title is-4">
                    <span class="icon">
                        <i class="fas fa-user-circle"></i>
                    </span>
                    <span class="has-text-weight-light"><?php echo e($student->user->name); ?></span>
                </h4>
                <div class="content">
                    <ul>
                        <li>Kelas: <?php echo e(Arr::get($student->kelas, 'level') . Arr::get($student->kelas, 'rombel')); ?></li>
                        <li>Musyrif: <?php echo e($student->getHalaqohMembership()->halaqoh->pegawai->user->name); ?></li>
                        <li>Kategori: <?php echo e($student->getHalaqohMembership()->level); ?></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="column is-4">
            <?php $__env->startComponent('components.card', ['title' => 'Nilai Akhir']); ?>
                <p class="is-size-1"><?php echo e(number_format($nilai_akhir, 2)); ?></p>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'Juz Diuji']); ?>
        <?php if(count($targets)): ?>
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th>Juz</th>
                        <th class="has-text-centered">Kelancaran</th>
                        <th class="has-text-centered">Fashohah</th>
                        <th class="has-text-centered">Tajwid</th>
                        <th class="has-text-centered">Nilai</th>
                        <th class="has-text-centered">Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php 
                                $juz_label = (string) $juz;      
                                $raw_juz =  explode( '_', $juz_label);

                                if(Str::contains ($juz_label, '_a')){
                                    $juz_label = $raw_juz[0].' Awal';
                                }
                                elseif(Str::contains ($juz_label, '_b')){
                                    $juz_label = $raw_juz[0].' Akhir';
                                }           
                                if(sizeof($raw_juz) == 1){
                                    array_push($raw_juz, null);
                                }
                                $pts_detail_score = $student->getPtsDetailScores($raw_juz[0], $raw_juz[1]);           
                            ?>

                            <td><?php echo e($juz_label); ?></td>       
                            <td class="has-text-centered"><?php echo e($pts_detail_score['kelancaran']); ?></td>  
                            <td class="has-text-centered"><?php echo e($pts_detail_score['fashohah']); ?></td> 
                            <td class="has-text-centered"><?php echo e($pts_detail_score['tajwid']); ?></td>                   
                            <td class="has-text-centered"><?php echo e(Arr::get($accumulations, $juz, 0)); ?></td>
                            <td class="has-text-centered">
                                <?php if(Arr::has($accumulations, $juz)): ?>
                                    <i class="fas fa-check-circle has-text-success"></i>
                                <?php else: ?>
                                    <i class="fas fa-question-circle has-text-warning"></i>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($unstoreds->contains($juz) ? 'Tidak disetorkan': ''); ?></td>
                            <td class="has-text-right">
                                 
                                <?php if(Arr::has($accumulations, $juz)): ?>
                                    <a href="<?php echo e(route('tester.pts.students.penilaian.details.index', [$student, $juz])); ?>" class="button is-text" title="Detail penilaian">
                                        <i class="fas fa-list"></i>
                                    </a>
                                    <form style="display: inline;" action="<?php echo e(route('tester.pts.unlock_scores', [$student, $juz])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button class="button is-text has-text-primary" title="Unlock penilaian">
                                            <i class="fas fa-unlock"></i>
                                        </button>
                                    </form>
                                <?php else: ?>
                                <form style="display:inline" method="POST" action="<?php echo e(route('tester.pts.unstored', [$student, $juz])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="button is-text has-text-danger">
                                        <i class="fas fa-heart-broken"></i>
                                    </button>
                                </form>
                                    <a href="<?php echo e(route('tester.pts.students.penilaian.show', [$student, $juz])); ?>" class="button is-text has-text-info">
                                    <i class="fas fa-play"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="notification is-warning">
                <span class="icon">
                    <i class="fas fa-info-circle"></i>
                </span>
                <span>No juz target yet.</span>
            </div>
        <?php endif; ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/tester/pts/students/show.blade.php ENDPATH**/ ?>