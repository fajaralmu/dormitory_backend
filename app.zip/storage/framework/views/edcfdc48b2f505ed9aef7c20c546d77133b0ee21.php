<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link href="<?php echo e(asset('css/fonts.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bulma.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/tahfiz.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/tahfiz.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fontawesome.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sidemenuevents.js')); ?>"></script>
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- ALpine -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.3.5/dist/alpine.min.js" defer></script>
    <?php echo $__env->yieldContent('extra_style'); ?>
    <?php echo $__env->yieldContent('head_script'); ?>
    
    <!-- Additional Resoucres -->
    <?php if(isset($additional_style_paths) && !is_null($additional_style_paths)): ?>
        <?php if(is_array($additional_style_paths)): ?>
            <?php $__currentLoopData = $additional_style_paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stylePath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <link rel="stylesheet" href="<?php echo e(asset('css/pages/' . $stylePath . '.css?version=1')); ?>" />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/pages/' . $additional_style_paths . '.css?version=1')); ?>" />
        <?php endif; ?>
    <?php endif; ?>
    <?php if(isset($additional_script_paths) && !is_null($additional_script_paths)): ?>
        <?php if(is_array($additional_script_paths)): ?>
            <?php $__currentLoopData = $additional_script_paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scriptPath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script src="<?php echo e(asset('js/pages/' . $scriptPath . '.js?v=').time()); ?>"></script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <script src="<?php echo e(asset('js/pages/' . $additional_script_paths . '.js?v=').time()); ?>"></script>
        <?php endif; ?>
    <?php endif; ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div id="app" class="columns" style="margin: 0;">
        <div class="column is-2 is-hidden-touch is-paddingless has-background-grey left-side">
            <nav class="navbar is-success" role="navigation" aria-label="main navigation">
                <div class="navbar-brand" style="width: 100%;">
                    <a class="navbar-item" href="/" style="width: 100%;">
                        <span class="icon is-medium">
                            <i class="fas fa-quran fa-lg"></i>
                        </span>
                        <span class="has-text-weight-bold">Tahfiz Application</span>
                    </a>
                </div>
            </nav>
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="column right-side" style="padding: 0;">
            <?php echo $__env->make('partials.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-content">
                <?php echo $__env->make('partials.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
  
    <?php echo $__env->yieldContent('modal'); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('status_script'); ?>
    <?php echo $__env->yieldContent('modal_script'); ?>
    <?php echo $__env->yieldContent('extra_script'); ?>

    <!-- Dropdown menu initializations -->

    <script>
        const TAHFIZ_APP_SIDEBAR_CODE = "tahfiz_app_sidebar_code";
        const menuLabels = document.getElementsByClassName("menu-label");
        const menuLists = document.getElementsByClassName("menu-list");

        addOnloadHandler(hideMenus);
        addOnloadHandler(initMenu); 

        const oldOnload =  document.body.onload;
        document.body.onload = function(e){
            if(oldOnload){
                oldOnload(e);
            }
            for (let i = 0; i < BODY_ONLOAD_HANDLER.length; i++) {
                const handler = BODY_ONLOAD_HANDLER[i];
                handler(e);
            }
        }
    </script>
     <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/layouts/app.blade.php ENDPATH**/ ?>