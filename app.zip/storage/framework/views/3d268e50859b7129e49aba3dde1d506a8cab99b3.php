<?php $__env->startSection('content'); ?>
    <h1 class="title">Laporan Hasil Penilaian PAS</h1>

    <table class="table is-fullwidth is-vcentered">
        <thead>
            <tr>
                <th>Sekolah</th>
                <th>Jenjang</th>
                <th>Kelas</th>
                <th>Rombel</th>
                <th>Jurusan</th>
                <th>Siswa</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kelases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $school = $schools->where('id', $kelas->sekolah_id)->first();
                ?>
                <tr>
                    <td><?php echo e(Arr::get($school, 'nama')); ?></td>
                    <td>
                        <span class="tag is-dark">
                            Sekolah <?php echo e(Str::title(str_replace('_', ' ', Arr::get($school, 'jenjang')))); ?>

                        </span>
                    </td>
                    <td><?php echo e($kelas->level); ?></td>
                    <td><?php echo e($kelas->rombel); ?></td>
                    <td><?php echo e(config('school.pilihan_jurusan')[$kelas->jurusan]); ?></td>
                    <td><?php echo e($kelas->students_count); ?></td>
                    <td class="has-text-right">
                        <a href="<?php echo e(route('admin.laporan.show', $kelas->id)); ?>" class="button is-text">
                            <i class="fas fa-list"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/pas/index.blade.php ENDPATH**/ ?>