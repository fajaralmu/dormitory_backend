<?php if(Str::contains(
        request()
            ->route()
            ->getPrefix(),
        'tester',
    )): ?>
    <a href="<?php echo e(route('tester.home')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-home"></i>
        </span>
        <span style="margin-left: 5px;">Home</span>
    </a>

    <a href="<?php echo e(route('tester.panduan.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-life-ring"></i>
        </span>
        <span style="margin-left: 5px;">Panduan</span>
    </a>

    <?php if($user_is_musyrif &&
    !Str::contains(
        request()
            ->route()
            ->getPrefix(),
        'musyrif',
    )): ?>
        <a href="<?php echo e(route('musyrif.home')); ?>" class="navbar-item">
            <span class="icon">
                <i class="fas fa-heart"></i>
            </span>
            <span style="margin-left: 5px;">Ruang Musyrif</span>
        </a>
    <?php endif; ?>
	<a href="<?php echo e(route('tester.pts.students.index')); ?>" class="navbar-item">
		<span class="icon">
			<i class="fas fa-users"></i>
		</span>
		<span style="margin-left: 5px;">Siswa PTS</span>
	</a>
    <a href="<?php echo e(route('tester.pas.students.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-users"></i>
        </span>
        <span style="margin-left: 5px;">Siswa PAS</span>
	</a> 

    <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link">
            Laporan
        </a>

        <div class="navbar-dropdown">
            <a href="#" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-chart-bar"></i>
                </span>
                <span style="margin-left: 5px;">Statistik</span>
            </a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/navbars/tester.blade.php ENDPATH**/ ?>