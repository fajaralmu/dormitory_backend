<?php $__env->startSection('content'); ?>
    <h1 class="title">Halaqoh <span class="tag is-dark">Members</span></h1>

    <h4 class="title is-4 has-text-weight-light">
        <span class="icon">
            <i class="fas fa-user-circle"></i>
        </span>
        <span><?php echo e($member->siswa->user->name); ?></span>
    </h4>

    <?php if($member->level === 'basic'): ?>
        <?php
            $target_route = route('admin.halaqoh.members.targets.create', [$halaqoh, $member]);

            if ($member->targets->count()) {
                $target = $member->targets->first();
                $target_route = route('admin.halaqoh.members.targets.edit', [$halaqoh, $member, $target]);
            }
        ?>
        <div class="level">
            <div class="level-left">
                <a href="<?php echo e($target_route); ?>" class="button is-info">
                    <span class="icon">
                        <i class="fas fa-list"></i>
                    </span>
                    <span>Target Hafalan</span>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <div class="box">
        <ul>
            <li>Sekolah: <strong><?php echo e($member->siswa->kelas->sekolah->nama); ?></strong></li>
            <li>Kelas: <strong><?php echo e($member->siswa->kelas->level . $member->siswa->kelas->rombel); ?></strong></li>
            <li>Musyrif: <strong>Ust. <?php echo e($halaqoh->pegawai->user->name); ?></strong></li>
            <li>Kategori: <strong><?php echo e(Str::title($member->level)); ?></strong></li>
        </ul>
    </div>

    <?php if($errors->any()): ?>
        <div class="notification is-danger">
            <p>Please fill the form correctly.</p>
        </div>
    <?php endif; ?>

    <div class="columns">
        <div class="column">
            <?php $__env->startComponent('components.card', ['title' => 'Edit']); ?>
                <form action="<?php echo e(route('admin.halaqoh.members.update', [$halaqoh, $member])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="field is-horizontal">
                        <div class="field-label is-normal">
                            <label class="label">Musyrif</label>
                        </div>
                        <div class="field-body">
                            <div class="field">
                                <div class="control">
                                    <div class="select<?php echo e($errors->has('kategori') ? ' is-danger' : ''); ?>">
                                        <select name="musyrif" id="musyrif">
                                            <option value="none">-- Pilih Musyrif --</option>
                                            <?php $__currentLoopData = $halaqohs_choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($id); ?>"><?php echo e($label); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <?php if($errors->has('musyrif')): ?>
                                    <p class="help is-danger">
                                       <?php echo e($errors->first('musyrif')); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="field is-horizontal">
                        <div class="field-label is-normal">
                            <label class="label">Kategori</label>
                        </div>
                        <div class="field-body">
                            <div class="field">
                                <div class="control">
                                    <div class="select<?php echo e($errors->has('kategori') ? ' is-danger' : ''); ?>">
                                        <select name="kategori" id="kategori">
                                            <option value="none">-- Pilih Kategori --</option>
                                            <?php $__currentLoopData = ['basic', 'reguler', 'mutawassitoh', 'mumayyazah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category); ?>"><?php echo e(Str::title($category)); ?></option> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <?php if($errors->has('kategori')): ?>
                                    <p class="help is-danger">
                                       <?php echo e($errors->first('kategori')); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="field is-horizontal">
                        <div class="field-label">
                            <!-- Left empty for spacing -->
                            <label for="" class="label"></label>
                        </div>
                        <div class="field-body">
                            <div class="field">
                                <div class="control">
                                    <button type="submit" class="button is-primary">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php echo $__env->renderComponent(); ?>
        </div>
        <div class="column">
            <?php $__env->startComponent('components.card', ['title' => 'Halaqoh History']); ?>
                <?php if($member->transfer_history || $member->level_history): ?>
                    <?php
                        $histories = array_merge(
                            array_get($member, 'transfer_history', []),
                            array_get($member, 'level_history', [])
                        );

                        $histories = collect($histories)->sortBy('at');
                    ?>

                    <table class="table is-fullwidth is-vcentered">
                        <thead>
                            <tr>
                                <th>#</th>
                                
                                <th>From</th>
                                <th>To</th>
                                <th>At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $from = Str::title($history['from']);
                                    $to = Str::title($history['to']);
                                    $at = (Carbon\Carbon::createFromFormat('U', $history['at']))->diffForHumans();

                                    // $aspect = (is_int($history['from']) && is_int($history['to'])) ? 'Musyrif' : 'Kategori';

                                    if (is_int($history['from'])) {
                                        $from = array_get($musyrifs, $history['from']);
                                    }

                                    if (is_int($history['to'])) {
                                        $to = array_get($musyrifs, $history['to']);
                                    }
                                ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    
                                    <td><?php echo e($from); ?></td>
                                    <td><?php echo e($to); ?></td>
                                    <td><?php echo e($at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="notification is-warning">
                        No history yet.
                    </div>
                <?php endif; ?>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <script>

        document.getElementById("kategori").value = "<?php echo e($member->level); ?>";
        document.getElementById("musyrif").value = "<?php echo e($member->halaqoh_id); ?>";

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/halaqoh/members/edit.blade.php ENDPATH**/ ?>