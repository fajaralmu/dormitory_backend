<?php if($orientation == 'horizontal'): ?>
    <div class="field is-horizontal">
        <div class="field-label">
            <!-- Left empty for spacing -->
            <label for="" class="label"></label>
        </div>
        <div class="field-body">
            <div class="field">
                <div class="control">
                    <button type="<?php echo e($type); ?>" class="button <?php echo e(Arr::get($options, 'class')); ?>">
                        <?php echo e(title_case($name)); ?>

                    </button>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="field">
        <div class="control">
            <button type="<?php echo e($type); ?>" class="button <?php echo e(Arr::get($options, 'class')); ?>">
                <?php echo e(title_case($name)); ?>

            </button>
        </div>
    </div>
<?php endif; ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\vendor\realcahsowan\laravel-bulma-form\src/../resources/views/button.blade.php ENDPATH**/ ?>