<?php $__env->startSection('content'); ?>
    <h1 class="title">Penguji <span class="tag is-dark">PTS</span></h1>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.pts.penguji.index')); ?>" class="button is-dark is-outlined">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks Penguji</span>
            </a>
        </div>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'Data Penguji PTS Baru']); ?>
        <?php echo $form; ?>

    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pts/penguji/create.blade.php ENDPATH**/ ?>