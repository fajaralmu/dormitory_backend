<?php $__env->startSection('content'); ?>
    <script type="text/javascript">
       
        const URL_EVENTS = "<?php echo e(url('/admin/mutabaah')); ?>"; 
        const halaqohList =<?php echo json_encode($halaqohList); ?>;
        const date = new Date();
        const eventItemData = {
            id: 0,
            day: date.getDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear(),
            description: "",
            active: true,
            populate: function(event) {
                this.id = event.id;
                this.day = event.day;
                this.month = event.month;
                this.year = event.year;
                this.description = event.description;
                this.active = event.active;
            },
            setDefault: function() {
                this.id = 0;
                this.description = "";
                this.active = true;
            }

        };
        let selectedMonth = eventItemData.month;
        let selectedYear = eventItemData.year;
        
        let selectedHalaqohId = null;
 
    </script>
    <?php if(sizeof($halaqohList) > 0): ?>
        <script type="text/javascript">
            selectedHalaqohId = "<?php echo e($halaqohList[0]->id); ?>"; 
        </script>
    <?php endif; ?>
    <h1 class="title">Penilaian Harian</h1>
    <div>
        <?php $__env->startComponent('components.card', ['title' => 'Options']); ?>
        <div class="columns">
            <form class="column is-8" onsubmit="loadEvents(); return false;">
                <div class="fields">
                <?php $__env->startComponent('components.inputhorizontal', ["label"=>"Halaqoh"]); ?>
                    <div class="select"><select id="select-halaqoh" autocomplete="off">
                        <?php $__currentLoopData = $halaqohList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($halaqoh->id); ?>">
                                <?php echo e($halaqoh->pegawai->user->name); ?> - <?php echo e($halaqoh->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select></div>
                <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('components.inputhorizontal', ["label"=>""]); ?>
                    <input class="button is-primary" type="submit" value="Submit" />
                    <a onClick = "openSummaryPage()" class="button is-link" >Summary</a>
                <?php echo $__env->renderComponent(); ?>
                </div>
            </form>
            <div class="column">
                <article class="message is-link">
                    <div class="message-header"><p>Info</p></div>
                    <div class="message-body" id="info">Info</div>
                </article>
            </div>
        </div>
        <?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('components.card', ['title' => 'Events Calendar']); ?>
        <div id="calendar-wrapper">
            <form id="calendar-navigation-form">
                <table class="table is-borderless" style="width: 100%" id="cal-input-fields">
                </table>
            </form>
            <table class="table" style="width: 100%" id="calendarTable">
                <tr><th>Please Wait....</th></tr>
            </table>
        </div>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.card', ['title' => 'Detail: Silakan Pilih Tanggal', 'id'=>'detail']); ?>
        <div class="columns">
            <form class="column is-two-third" onsubmit="return false;" id="events-form">
                <div class="field">
                    <label class="label">Hari Aktif</label>
                    <div class="control">
                        <input disabled id="events-active" type="radio" name="events-active" checked/><!--
                        --><label for="events-active" >Ya</label><!--
                        --><input disabled id="events-non-active" type="radio" name="events-active"/><!--
                        --><label for="events-non-active">Tidak</label>         
                </div>
                </div>
                <div class="field">
                    <label class="label">Keterangan Agenda</label>
                    <textarea disabled autocomplete="false" class="textarea" id="events-description" placeholder="Keterangan"
                        rows="2"></textarea>
                </div>
                
            </form>
            <?php echo $__env->make('partials.shared.calendar-legend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->renderComponent(); ?>
    </div>
    <script type="text/javascript">
        
        const eventActiveToggleRadios = document.getElementsByName("events-active");
        const eventDescriptionTextarea = byId("events-description");
        const selectHalaqoh = byId("select-halaqoh");
        const info = byId("info");
        const eventActiveRadio = byId("events-active");
        const eventInActiveRadio = byId("events-non-active");
        const formCardTitle = byId("card-header-detail");
        

        addOnloadHandler(function(e){

            for (let i = 0; i < eventActiveToggleRadios.length; i++) {
                const radio = eventActiveToggleRadios[i];
                radio.onchange = function(e) {
                    eventItemData.active = e.target.checked && e.target.id == "events-active";
                }
            }
            eventDescriptionTextarea.onkeyup = function(e) {
                eventItemData.description = e.target.value;
            }
            eventDescriptionTextarea.value = null;
            selectHalaqoh.onchange = function(e) {
                selectedHalaqohId = e.target.value;
            }
            
        });
        addOnloadHandler(loadCalendar);

    </script>
    <!-- CALENDAR CALLBACKS -->
    <script type="text/javascript">
        
        
        //when detail BUTTON is clicked
        function dateItemClickedCallback(day, month, year) {
            if (day == null || month == null || year == null) {
                return;
            }

            setFormTitle(day, month, year, null);
            setEventItemData(day, month, year);

        };

        //when one month calendar loaded
        function monthDataLoadedCallback(month, year) {
            console.debug("monthDataLoadedCallback: ", month,"-",year);
            selectedMonth = month;
            selectedYear = year;
            loadEvents();
        }

    </script>
    <script type="text/javascript">

       
        function setFormTitle(day, month, year, additional) {
            const monthName = MONTHS[month - 1].name;
            additional = additional != null ? additional : "";
            formCardTitle.innerHTML = "Detail: " + day + " " + monthName + " " + year;
                additional;
        }

        function fillDateItem(d, m, y) {
            const element = createHtml("div", "");
            element.id = "detail-date-element-"+d+"-"+m;
            element.className = "detail-date-element";
            return element;
        };

        function setEventItemData(day, month, year) {
            eventItemData.day = day;
            eventItemData.month = month;
            eventItemData.year = year;
            eventItemData.setDefault();

            populateDetailEventInputs(eventItemData);

            loadEventsByDayAndMonth(day, month);
        }

        function populateDetailEventInputs(eventItemData) {

            eventDescriptionTextarea.value = eventItemData.description;
            eventActiveRadio.checked = eventItemData.active == true;
            eventInActiveRadio.checked = eventItemData.active == false;
        }
        
        function populateDetailEvent(response) {
            const eventItemDataList = response.eventItemDataList;
            if ((eventItemDataList == null || 0 == eventItemDataList.length) &&
                response.eventItemData == null) {
                formCardTitle.innerHTML += ' (Belum ada data)';
                return;
            }
            const loadedEventItemData = response.eventItemData != null ? response.eventItemData : eventItemDataList[0];
            eventItemData.populate(loadedEventItemData);
            populateDetailEventInputs(eventItemData);

            setFormTitle(loadedEventItemData.day, loadedEventItemData.month, loadedEventItemData.year, " (Record id: " +
                loadedEventItemData.id + ")");
            if (loadedEventItemData.active) {
                const monthName = MONTHS[loadedEventItemData.month - 1].name;
                const stringDate = loadedEventItemData.day+" "+ monthName+ " "+loadedEventItemData.year;
                
                confirmDialog("lihat data tanggal "+stringDate+"?")
                .then(function(ok){
                    if(ok){
                        const dateQueryString = "day="+loadedEventItemData.day+"&month="+loadedEventItemData.month+"&year="+loadedEventItemData.year;
                        openInNewTab("/admin/mutabaah/detail/"+selectedHalaqohId+"?"+dateQueryString);
                    }
                });
            }
        }

        function populateCalendar(response) {
            clearDateElement();
            const eventItemDataList = response.eventItemDataList;
            if (null == eventItemDataList) {
                return;
            }
            const eventsCurrentMonth = getEventDaysData(eventItemDataList);
            info.innerHTML = "Aktif: "+eventsCurrentMonth.active+", non-aktif: "+eventsCurrentMonth.nonActive+", total: "+eventsCurrentMonth.total;
            for (let i = 0; i < eventItemDataList.length; i++) {
                const element = eventItemDataList[i];
                populateEventsDateItem(element);
            }
        }

        function openSummaryPage() {
            openInNewTab("/admin/mutabaah/laporan/"+selectHalaqoh.value);
        }
        
        populateDetailEventInputs(eventItemData);

    </script>
    <!-- AJAX CALLS -->
    <script type="text/javascript"> 
       
        function loadEvents() {
            if (!selectedHalaqohId) {
                return;
            }
            startLoading();
            //
            axios.get(URL_EVENTS + "/" + selectedHalaqohId + "?filter=events&month=" + selectedMonth + "&year=" + selectedYear)
                .then(function(response) {
                    const payload = response.data;
                    populateCalendar(payload);
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);

        }

        function loadEventsByDayAndMonth(day, month) {
            startLoading();
            axios.get(URL_EVENTS + "/"+selectedHalaqohId+"?filter=events&month=" + month + "&day=" + day+"&year="+selectedYear)
                .then(function(response) {
                    const payload = response.data;
                    populateDetailEvent(payload);
                }).catch(function(e) {
                    console.error(e);
                    alert("Operation Failed");
                }).finally(stopLoading);

        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/harian/index.blade.php ENDPATH**/ ?>