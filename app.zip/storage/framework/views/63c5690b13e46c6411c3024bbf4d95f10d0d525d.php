<?php
$aspects = [ 'kategori_halaqoh', 'target_hafalan' ];
$settings = array_only($configuration->settings, $aspects);
?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Settings <span class="tag is-dark">Umum</span></h1> 
    <div class="settings-content">

        <!-- OPTIONS -->
        <form onsubmit="event.preventDefault(); submitJuzMapping()">
        <div class="card">
            <header class="card-header">
                <p class="card-header-title">Options</p>
            </header>
            <div class="card-content">
                <div class="columns">
                    <div class="field column is-one-fifth">
                        <label class="label">Sekolah</label>
                        <div class="select"><select id="select-school">
                                <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option level="<?php echo e($school->jenjang); ?>" value="<?php echo e($school->id); ?>"><?php echo e($school->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></div>
                    </div>
                    <div class="field column is-one-fifth">
                        <label class="label">Tipe Target</label>
                        <div class="select"><select id="select-target-type"  >
                                <option value="hafalan">Target Hafalan</option>
                                <option value="ujian">Peta Ujian</option>
                        </select></div>
                    </div>
                    <div class="field column is-one-fifth" id="exam-type-wrapper" style="visibility: hidden">
                        <label class="label">Tipe Ujian</label>
                        <div class="select" ><select id="select-exam-type"  >
                                <option value="pts">PTS</option><option value="pas">PAS</option>
                        </select></div>
                    </div>
                </div>
                <div id="option-fields" class="columns">
                    <div class="field column">
                        <label class="label">Kategori</label>
                        <div class="select"><select id="select-category" class="controlled-select" control-variable="selectedCategory">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category); ?>"><?php echo e(strtoupper($category)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></div>
                    </div>
                    <div class="field column">
                        <label class="label">Kelas</label>
                        <div class="select"><select id="select-level" class="controlled-select" control-variable="selectedLevel">
                        </select></div>
                    </div>
                    <div class="field column">
                        <label class="label">Semester</label>
                        <div class="select"><select id="select-semester" class="controlled-select" control-variable="selectedSemester">
                                <option value="1">Semester 1</option><option value="2">Semester 2</option>
                        </select></div>
                    </div>
                    <div class="field column">
                        <label class="label">Detail Juz</label>
                        <div id="toggle-detail-juz" onclick="toggleDetailJuz()" class="input">
                            <i class="fa fa-toggle-off" aria-hidden="true"></i>&nbsp;OFF
                        </div>
                    </div>
                    <div class="field column">
                        <label class="label">Action</label>
                        <div>
                            <button id="btn-save-data" type="submit" class="button is-primary">Save</button>
                            <button id="btn-clear-radios" onclick="clearInputJuzRadiosAndTempData()"  class="button is-danger">&nbsp;Clear</button>
                        </div>
                    </div>
                </div>
                <div class="control" id="is-murojaah-wrapper" >
                    <label class="checkbox"><input type="checkbox" id="is-murojaah"> Hanya Murojaah | ignore all selected juz </label>
                </div>
            </div> 
        </div>
        </form>
        <br/>
    
        <!-- JUZ INPUTS -->
        <div id="available_juz" class="columns is-multiline">
            <?php $__currentLoopData = $available_juz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column is-one-fifth">
                    <div class="card">
                        <header class="card-header">
                            <p class="card-header-title"> Juz <?php echo e($juz); ?> </p>
                        </header>
                        <div id="card-content-<?php echo e($juz); ?>" class="card-content">
                            <div class="radio-wrapper" style="display: block">
                                <input type="radio" juz="<?php echo e($juz); ?>" class="input-radio-juz" value="<?php echo e($juz); ?>"
                                    content="full" name="radio-juz-<?php echo e($juz); ?>" /> Full
                            </div>
                            <div style="display: none" class="additional-juz radio-wrapper">
                                <input type="radio" juz="<?php echo e($juz); ?>" class="input-radio-juz" value="<?php echo e($juz); ?>_a"
                                    content="a" name="radio-juz-<?php echo e($juz); ?>" /> 1/2 Awal
                            </div>
                            <div style="display: none" class="additional-juz radio-wrapper">
                                <input type="radio" juz="<?php echo e($juz); ?>" class="input-radio-juz" value="<?php echo e($juz); ?>_b"
                                    content="b" name="radio-juz-<?php echo e($juz); ?>" /> 1/2 Akhir
                            </div>
                        </div>
                        <footer class="card-footer">
                            <a data="<?php echo e($juz); ?>" class="card-footer-item clear-radio-juz"><i class="fas fa-sync-alt" ></i><span style="padding-left: 5px">Clear</span></a>
                        </footer>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    
    <script type="text/javascript">
        const selectSchool = document.getElementById('select-school');
        const selectLevel = document.getElementById('select-level');
        const selectCategory = document.getElementById("select-category");
        const selectSemester = document.getElementById("select-semester");
        const selectTargetType = document.getElementById("select-target-type");
        const selectExamType = document.getElementById("select-exam-type");
        
        const checkBoxIsMurojaah = document.getElementById("is-murojaah");

        const schoolLevels = <?php echo $school_levels; ?>;

        const btnSaveData = document.getElementById("btn-save-data");
        const inputJuzRadios = document.getElementsByClassName("input-radio-juz");
        const inputJuzAdditionalRadios = document.getElementsByClassName("additional-juz");
        const btnToggleDetailJuz = document.getElementById("toggle-detail-juz");

        const inputJuzRadiosWrappers = document.getElementsByClassName("radio-wrapper");

        const URL_GET_LEVEL_TARGET = "<?php echo e(url('/admin/settings/get-level-target')); ?>";
        const URL_SUBMIT_LEVEL_TARGET = "<?php echo e(url('/admin/settings/level-target')); ?>"; 

        //default values
        selectedCategory = selectCategory.value;
        selectedSemester = selectSemester.value;
        selectedSchoolId = selectSchool.value;
        selectedLevel = selectLevel.value;
        selectedTargetType = selectTargetType.value;
        selectedExamType = selectExamType.value;

        selectTargetType.value = "hafalan";
        checkBoxIsMurojaah.checked = false;

    </script>
    <script type="text/javascript">
        function toggleDetailJuz() {

            showDetailJuz = !showDetailJuz;
            if (showDetailJuz) {
                btnToggleDetailJuz.innerHTML = "<i class=\"fa fa-toggle-on\"   aria-hidden=\"true\"></i>&nbsp;ON";
            } else {
                btnToggleDetailJuz.innerHTML = "<i class=\"fa fa-toggle-off\"   aria-hidden=\"true\"></i>&nbsp;OFF";
            }
            for (let i = 0; i < inputJuzAdditionalRadios.length; i++) {
                const radioLabel = inputJuzAdditionalRadios[i];
                if (showDetailJuz) {
                    radioLabel.style.display = "block";
                } else {
                    radioLabel.style.display = "none";
                }
            }

        } 

        function initEventListener() {
            selectSchool.onchange = function(e) {
                selectSchoolOnChange();               
            }
            selectTargetType.onchange = function(e) {
               selectTargetTypeOnChange();
            }
            checkBoxIsMurojaah.onchange = function(e) {
               checkBoxIsMurojaahOnChange();
            }
            selectExamType.onchange = function(e) {
                selectExamTypeOnChange();
            }
            initControlledSelectEvents();
            initRadioEvents();
        }

        function selectExamTypeOnChange(){
            selectedExamType = selectExamType.value;
            reloadJuzData();
        }

        function selectSchoolOnChange(){
            confirmDialog("Switch Sekolah? Pastikan konfigurasi sudah tersimpan")
                    .then(function(confirm){
                        if(confirm){
                            updateSchoolLevelOptions();
                        }else{
                            selectSchool.value = selectedSchoolId;
                        }
                    }); 
           
        }

        function selectTargetTypeOnChange(){
            confirmDialog("Switch Target? Pastikan konfigurasi sudah tersimpan")
                    .then(function(confirm){
                        if(confirm){
                            selectedTargetType =  selectTargetType.value;
                            if(selectedTargetType == 'hafalan'){
                                showElement(byId("is-murojaah-wrapper"));
                                setIsExam(false); 
                            }else{
                                checkBoxIsMurojaah.checked = false;
                                hideElement(byId("is-murojaah-wrapper"));
                                setIsExam(true);
                            }
                            getSchoolConfig(); 
                        }else{
                            selectTargetType.value = selectedTargetType;
                        }
                    }); 
           
        }

        function setIsExam(value){
            isExam = value;
            if(isExam){
                showElement(byId("exam-type-wrapper"));
            }else{
                hideElement(byId("exam-type-wrapper"));
            }
        }

        function checkBoxIsMurojaahOnChange(){
            if(selectedTargetType == "ujian"){
                alert("Murojaah disabled when ujian");
                checkBoxIsMurojaah.checked = false;
                return;
            }
            if(checkBoxIsMurojaah.checked){
                confirmDialog("Murojaah will ignore all juz, continue?")
                    .then(function(confirm){
                        if(confirm){
                            putJuzMapping("murojaah");
                        }else{
                            checkBoxIsMurojaah.checked = false;
                        }
                    });
               
            }else{
                clearJuzData("murojaah");
            }
        }

        function initRadioEvents() {
            clearInputJuzRadios();
            for (let i = 0; i < inputJuzRadios.length; i++) {
                const radio = inputJuzRadios[i];
                const value = radio.value;
                radio.onchange = function(e) {

                    setInputRadioJuzCheck(e.target, e.target.checked);
                }
            }

            for (let i = 0; i < inputJuzRadiosWrappers.length; i++) {
                const radioWrapper = inputJuzRadiosWrappers[i];
                radioWrapper.onclick = function(e){
                    const radio = radioWrapper.children[0];
                    if(radio.checked == false){
                        radio.checked = true; 
                    }else{
                        radio.checked = false; 
                    }
                    setInputRadioJuzCheck(radio, radio.checked );
                }
            }
        }

        function setInputRadioJuzCheck(radio, isChecked) {
            const className = isChecked ? "card-content has-background-grey-light" : "card-content";
            radio.checked = isChecked;
            const juz = radio.getAttribute("juz");
            document.getElementById("card-content-" + juz).setAttribute("class", className);
            if (radio.checked) {
                putJuzMapping(radio.value);
            } else {
                //clearJuzData(radio.getAttribute("juz"));
            }
        }

        function clearInputJuzRadios() {
            for (let i = 0; i < inputJuzRadios.length; i++) {
                setInputRadioJuzCheck(inputJuzRadios[i], false);
            }
        }

        function clearInputJuzRadiosAndTempData() {
            confirmDialog("Clear Data?").then(function(confirm){
                if(confirm){
                    checkBoxIsMurojaah.checked = false;
                    for (let i = 0; i < inputJuzRadios.length; i++) {
                        setInputRadioJuzCheck(inputJuzRadios[i], false);
                        clearJuzData(inputJuzRadios[i].getAttribute("juz"));
                    }
                }else{

                }
            }) 
        }

        function initControlledSelectEvents() {
            const controlledSelect = document.getElementsByClassName("controlled-select");
            for (let i = 0; i < controlledSelect.length; i++) {
                const select = controlledSelect[i];
                const variableName = select.getAttribute("control-variable");
                const oldEvent = select.onchange;
                select.onchange = function(e) {
                    if(oldEvent){
                        oldEvent(e);
                    }
                    const value = e.target.value;
                    // console.debug(variableName,":", value);
                    window[variableName] = value;

                    reloadJuzData();
                   
                }
            }
        }

        function reloadJuzData(){
            clearInputJuzRadios();
            populateJuzData();
        }

        function updateSchoolLevelOptions() {
            selectedSchoolId = selectSchool.value; 

            const options = selectSchool.options[selectSchool.selectedIndex];
            const level = options.getAttribute("level");
            if (!level || level == "") {
                return;
            }
            const selectedLevels = schoolLevels[level];

            selectedLevel = selectedLevels[0];

            //Class name aliases
            const htmls = [];
            for (let i = 0; i < selectedLevels.length; i++) {
                const level = selectedLevels[i];
                const num = level > 9? level - 9 : level - 6;
                const school = level > 9 ? "MA":"MTs";
                const label = level+" ("+num+ " " + school+")";
                htmls.push(label);
            }
            populateSelectBox(selectLevel, selectedLevels, htmls);
            getSchoolConfig();
        }

    </script>
    <!--JUZ MANIPULATION -->
    <script style="text/javascript">
        const buttonClearOneJuz = document.getElementsByClassName("clear-radio-juz");

        function initJuzManipulationEvent() {
            for (let i = 0; i < buttonClearOneJuz.length; i++) {
                const btn = buttonClearOneJuz[i];
                const juz = btn.getAttribute("data");
                btn.onclick = function(e) {
                    clearSelectedJuz(juz);
                }
            }
        }

        function clearSelectedJuz(juz) {
            console.warn("clearSelectedJuz ", juz);
            const radios = document.getElementsByName("radio-juz-" + juz);
            for (let i = 0; i < radios.length; i++) {
                setInputRadioJuzCheck(radios[i], false);
                clearJuzData(juz);
            }
        }
 

    </script>
    <!-- JUZ MAPPING -->
    <script type="text/javascript"> 

       addOnloadHandler(function(e){
            
            initEventListener();
            updateSchoolLevelOptions();
            initJuzManipulationEvent();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/settings/level-target/index.blade.php ENDPATH**/ ?>