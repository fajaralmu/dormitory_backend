<div id="<?php echo e($id ?? str_slug($title)); ?>" class="card<?php echo e($extra_class ?? ''); ?>" style="margin-bottom: 20px;">
  <?php if(isset($title)): ?>
    <header class="card-header">
      <p class="card-header-title" id="card-header-<?php echo e($id ?? str_slug($title)); ?>">
        <?php echo $title; ?>

      </p>
      <a href="#" class="card-header-icon" aria-label="more options">
        <span class="icon">
          <i class="fas fa-angle-down" aria-hidden="true"></i>
        </span>
      </a>
    </header>
  <?php endif; ?>

  <?php if(isset($image)): ?>
    <div class="card-image">
      <figure class="image">
        <img src="<?php echo e($image); ?>">
      </figure>
    </div>
  <?php endif; ?>

  <div class="card-content">
    <?php echo e($slot); ?>

  </div>

  <?php if(isset($footer)): ?>
    <footer class="card-footer">
      <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($url); ?>" class="card-footer-item"><?php echo $label; ?></a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </footer>
  <?php endif; ?>
</div><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/components/card.blade.php ENDPATH**/ ?>