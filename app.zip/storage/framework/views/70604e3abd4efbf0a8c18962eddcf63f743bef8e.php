<aside id="sidebar" style="margin-top: 0.75rem;" class="menu">
    <p class="menu-label" id="utama">
        Utama
    </p>
    <ul class="menu-list">
        <li>
            <a href="<?php echo e(route('musyrif.home')); ?>">
                <i class="fas fa-tachometer-alt"></i> Dasbor
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('musyrif.panduan.index')); ?>">
                <i class="fas fa-life-ring"></i> Panduan
            </a>
        </li>
        <?php if($user_is_penguji): ?>
            <li>
                <a href="<?php echo e(route('tester.home')); ?>">
                    <i class="fas fa-book-reader"></i> Ruang Penguji
                </a>
            </li>
        <?php endif; ?>
        <li>
            <a href="<?php echo e(route('musyrif.penilaian-periodik.index')); ?>">
                <i class="fas fa-folder"></i> Penilaian Periodik
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('musyrif.penilaian-individual.index')); ?>">
                <i class="fas fa-folder"></i> Penilaian Individual
            </a>
        </li>
    </ul>
    <p class="menu-label" id="mutahaab-harian">
        Mutabaah Harian
    </p>
    <ul class="menu-list">
        
        
        <li>
            <a href="<?php echo e(route('musyrif.harianv2.index')); ?>" class="navbar-item">
                    <i class="fas fa-edit"></i> Isi Mutabaah
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('musyrif/mutabaah/laporan')); ?>" class="navbar-item">
                    <i class="fas fa-list"></i> Laporan Mutabaah
            </a>
        </li>
    </ul>

    <p class="menu-label">
        Laporan
    </p>
    <ul class="menu-list">
        <li>
            <a href="#">
                <i class="fas fa-chart-bar"></i> Statistik
            </a>
        </li>
    </ul>
</aside>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/sidebars/musyrif.blade.php ENDPATH**/ ?>