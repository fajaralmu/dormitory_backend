<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Cetak Rapor | Tahfidz</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bulma.css')); ?>">
    <style>
        td,
        tr,
        tbody,
        thead {
            background-color: transparent;
        }

        /* body {
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
        } */
        body {
            font-size: 1.2rem;
            background-image: url("<?php echo e(asset('img/kiis-bg.jpg')); ?>");
            background-repeat: no-repeat;
            background-position: center;

        }

        table.table.is-vcentered tr td {
            vertical-align: middle;
        }

        hr {
            background-color: #000;
            height: 1px;
        }

        table#details {
            border-color: #000;
        }

        table#details th,
        table#details td {
            border-color: #000;
        }

        .center {
            text-align: center;
        }

        .box,
        .table {
            background-color: transparent;
            font-size:0.9em;
        }

        table{
            font-size:0.9em;
        }

    </style>
</head>

<body>
    <div class="container is-fluid">
        <div class="header" style="display: grid; grid-template-columns: 20% 60% 20%">
            <div class="center"><img height="80" width="80" src="<?php echo e(asset('img/kiis.jpg')); ?>" /></div>
            <div class="has-text-centered" style="margin-bottom: 20px;">
                <h3 class="title is-size-4">Laporan Penilaian Tahfidz Al Quran</h3>
                
            </div>
            <div class="center"><img height="80" width="80" src="<?php echo e(asset('img/logo.png')); ?>" /></div>
        </div>
        <div class="box">
            <table class="table is-fullwidth is-vcentered"  >
                <tr>
                    <th style="width: 300px;">Nama</th>
                    <td><?php echo e($student->user->name); ?></td>
                </tr>
                <tr>
                    <th>NIS</th>
                    <td> <?php echo e($student->nis); ?> </td>
                </tr> 
                <tr>
                    <th>Kelas</th>
                    <td> <?php echo e($student->kelas->level . $student->kelas->rombel); ?> </td>
                </tr>
                <tr>
                    <th>Kategori</th>
                    <td> <?php echo e(strtoupper($kategori)); ?> </td>
                </tr>
                <tr>
                    <th>Tahun Ajaran / Semester</th>
                    <td><?php echo e(config('school.tahun_ajaran')); ?> / <?php echo e(config('school.semester')); ?></td>
                </tr>
                <tr>
                    <th>Periode</th>
                    <td>Tengah Semester</td>
                </tr>
            </table>
        </div>

        <h4 class="is-size-5 has-text-weight-bold is-uppercase" style="margin: 50px 0 20px 0;">Rangkuman Penilaian</h4>
        <div class="box">
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>Juz</th>
                    <th class="has-text-centered">Kelancaran</th>
                    <th class="has-text-centered">Fashohah</th>
                    <th class="has-text-centered">Tajwid</th>
                    <th class="has-text-centered">Score</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $juz_part = null;

                        $juz_label = (string) $juz;
                        $pure_juz = $juz;
                        $raw_juz = explode( '_', $juz_label);

                        if(Str::contains ($juz_label, '_a')){ 
                            $juz_part = 'a';
                            $pure_juz =  $raw_juz[0];
                        }
                        elseif(Str::contains ($juz_label, '_b')){ 
                            $juz_part = 'b';
                            $pure_juz =  $raw_juz[0];
                        }
                        if(sizeof( $raw_juz) == 1){
                            array_push( $raw_juz, null);
                        }
                        $penilaian = $student->getPtsAccumulationScore($pure_juz, $juz_part);
                        $pts_detail_score = $student->getPtsDetailScores($raw_juz[0], $raw_juz[1]);  
                    ?>
                    <tr>
                        <td><?php echo e(App\Traits\Quran::getJuzLabel($juz)); ?></td>
                        <td class="has-text-centered"><?php echo e($pts_detail_score['kelancaran']); ?></td>  
                        <td class="has-text-centered"><?php echo e($pts_detail_score['fashohah']); ?></td> 
                        <td class="has-text-centered"><?php echo e($pts_detail_score['tajwid']); ?></td>      
                        <td class="has-text-centered"><?php echo e(($penilaian)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>

    </div>
</body>

</html>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/pts/cetak/show.blade.php ENDPATH**/ ?>