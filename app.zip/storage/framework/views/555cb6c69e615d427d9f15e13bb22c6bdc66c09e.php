<?php if(session('status')): ?>
	<div id="status" class="notification is-warning animated fadeInDownBig">
		<button class="delete"></button>
		<p>
			<span class="icon">
				<i class="fas fa-info-circle fa-lg"></i>
			</span>
			<span><?php echo e(session('status')); ?></span>
		</p>
	</div>

	<?php $__env->startSection('status_script'); ?>
		<script>
	        // fade out status notification
	        /*setTimeout(function () {
	            var statusEl = document.getElementById('status');
	            statusEl.style.opacity = 0;
	            statusEl.style.transition = 'opacity 1000ms';
	        }, 3000);*/

	        var closeStatusBtn = document.querySelector('#status > button.delete');
	        closeStatusBtn.addEventListener('click', function () {
	        	var statusEl = document.getElementById('status');
	            statusEl.classList.replace('fadeInDownBig', 'fadeOutRightBig');
	        });
	    </script>
	<?php $__env->stopSection(); ?>
<?php endif; ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/status.blade.php ENDPATH**/ ?>