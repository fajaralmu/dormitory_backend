<div class="field is-horizontal">
  <div class="field-label is-normal"><label class="label"><?php echo e($label ?? ""); ?></label></div>
  <div class="field-body">
      <div class="field">
          <div class="control">
            <?php echo e($slot); ?>

          </div>
      </div>
  </div>
</div>
 <?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/components/inputhorizontal.blade.php ENDPATH**/ ?>