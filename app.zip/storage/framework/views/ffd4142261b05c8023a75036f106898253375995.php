<div class="box">
	<h4 class="title is-4">
		
		<span>Delete Confirmation</span>
	</h4>
	<div class="box" style="background: #eaeaea;">
		<p>Are you sure to delete this item?</p>
	</div>
	<div class="has-text-right" style="margin-top: 10px;">
		<button id="yes" class="button is-primary is-uppercase">Yes</button>
	</div>
</div>

<?php $__env->startSection('extra_script'); ?>
	##parent-placeholder-3ec8bb2ec1819811b81ddbf0bedf06eaae655576##
	<script>
		var modalDeleteConfirmation = document.getElementById('delete-confirmation')
		var deleteBtns = document.querySelectorAll('button[name="delete-item"]');

		deleteBtns.forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var form = this.parentElement;
                var yesBtn = document.querySelector('#delete-confirmation button#yes');

                yesBtn.addEventListener('click', function() {
                    // submit form
                    form.submit();

                    // hide modal dialog
                    modalDeleteConfirmation.classList.remove('is-active');
                });

                modalDeleteConfirmation.classList.add('is-active');
            });
        });
	</script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/delete-confirmation.blade.php ENDPATH**/ ?>