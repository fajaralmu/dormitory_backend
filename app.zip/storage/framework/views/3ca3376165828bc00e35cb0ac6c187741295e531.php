<?php if($type == 'hidden'): ?>
    <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e(Arr::get($options, 'value')); ?>">
<?php else: ?>
    <?php
        $placeholder = Arr::has($options, 'placeholder') ? Arr::get($options, 'placeholder') : title_case(str_replace('_', ' ', $name));
        $value = old($name, Arr::get($options, 'value'));
        $extra_class = $errors->has($name) ? ' is-danger' : '';
        $custom_class = Arr::get($options, 'custom_class');
        $input_id = Arr::get($options, 'id');

        $is_narrow = Arr::get($options, 'narrow') ? ' is-narrow' : '';
        $label = Arr::get($options, 'label', $name);
    ?>

    <?php if($orientation == 'horizontal'): ?>
        <div id="<?php echo e($input_id); ?>" class="field is-horizontal <?php echo e($custom_class); ?>">
            <div class="field-label is-normal">
                <?php if(Arr::has($options, 'label_uppercase')): ?>
                    <label class="label"><?php echo e(strtoupper(str_replace('_', ' ', $label))); ?></label>
                <?php else: ?>
                    <label class="label"><?php echo e(title_case(str_replace('_', ' ', $label))); ?></label>
                <?php endif; ?>
            </div>
            <div class="field-body">
                <div class="field<?php echo e($is_narrow); ?>">
                    <div class="control">
                        <input id="<?php echo e($input_id); ?>" class="input<?php echo e($extra_class); ?>" type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" placeholder="<?php echo e($placeholder); ?>" <?php echo e(extra_attribute($options)); ?>>
                    </div>
                    <?php if($errors->has($name)): ?>
                        <p class="help is-danger">
                           <?php echo e($errors->first($name)); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div id="<?php echo e($input_id); ?>" class="field <?php echo e($custom_class); ?>">
            <?php if(Arr::has($options, 'label_uppercase')): ?>
                <label class="label"><?php echo e(strtoupper(str_replace('_', ' ', $label))); ?></label>
            <?php else: ?>
                <label class="label"><?php echo e(title_case(str_replace('_', ' ', $label))); ?></label>
            <?php endif; ?>
            <div class="control">
                <input class="input<?php echo e($extra_class); ?>" type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" placeholder="<?php echo e($placeholder); ?>" <?php echo e(extra_attribute($options)); ?>>
            </div>
            <?php if($errors->has($name)): ?>
                <p class="help is-danger">
                   <?php echo e($errors->first($name)); ?>

                </p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\vendor\realcahsowan\laravel-bulma-form\src/../resources/views/input.blade.php ENDPATH**/ ?>