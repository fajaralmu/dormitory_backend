<?php $__env->startSection('content'); ?>
    <h1 class="title">Detail Penilaian</h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light"><?php echo e(Str::limit($student->user->name, 25)); ?> | JUZ <?php echo e($juz); ?></h4>
    </div>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('tester.pas.students.penilaian.details.index', [$student, $juz])); ?>" class="button is-outlined is-primary">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks Scores Per Halaman</span>
            </a>
        </div>
    </div>

    <div class="box">
        <table class="table is-fullwidth">
            <tr>
                <td>Nilai Halaman</td>
                <td class="has-text-right"><?php echo e($detail->score); ?></td>
            </tr>
            <tr>
                <td>Kelancaran</td>
                <td class="has-text-right"><?php echo e($detail->raw_score['kelancaran']); ?></td>
            </tr>
            <tr>
                <td>Fashohah</td>
                <td class="has-text-right"><?php echo e($detail->raw_score['fashohah']); ?></td>
            </tr>
            <tr>
                <td>Tajwid</td>
                <td class="has-text-right"><?php echo e($detail->raw_score['tajwid']); ?></td>
            </tr>
        </table>
    </div>

    <div class="columns">
        <?php $__currentLoopData = $detail->mistakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column">
                <?php $__env->startComponent('components.card', ['title' => Str::title($label)]); ?>
                    <table class="table is-fullwidth">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(Str::title(str_replace('_', ' ', $key))); ?></td>
                                <td class="has-text-right"><?php echo e($value); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php echo $__env->renderComponent(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/tester/pas/students/penilaian/details/show.blade.php ENDPATH**/ ?>