<nav class="navbar is-dark" role="navigation" aria-label="main navigation">
	<div class="navbar-brand is-hidden-desktop">
		<a class="navbar-item" href="/">
			<span class="icon is-medium">
				<i class="fas fa-quran fa-lg"></i>
			</span>
			<span class="has-text-weight-bold">Tahfiz Application</span>
		</a>

		<a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
			<span aria-hidden="true"></span>
			<span aria-hidden="true"></span>
			<span aria-hidden="true"></span>
		</a>
	</div>

	<div id="navbarBasicExample" class="navbar-menu">
		<div class="navbar-start is-hidden-desktop">
			<?php if(Str::contains(request()->route()->getPrefix(), 'tester')): ?>
				<?php echo $__env->make('partials.navbars.tester', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>

			<?php if(Str::contains(request()->route()->getPrefix(), 'musyrif')): ?>
				<?php echo $__env->make('partials.navbars.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>

			<?php if(Auth::user()->hasRole(['admin_tahfiz'])): ?>
				<?php echo $__env->make('partials.navbars.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>
		</div>

		<div class="navbar-end">
			<div class="navbar-item">
				<div class="buttons">
					<a class="button">
						<span class="icon">
							<i class="fas fa-user-circle"></i>
						</span>
						<span><?php echo e(Auth::user()->name); ?></span>
					</a>
					<a class="button is-danger" onclick="event.preventDefault();
						document.getElementById('logout-form').submit();">
						<span class="icon">
							<i class="fas fa-sign-out-alt"></i>
						</span>
						<span><?php echo e(__('Logout')); ?></span>
					</a>

					<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
						<?php echo csrf_field(); ?>
					</form>
				</div>
			</div>
		</div>
	</div>
</nav><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/navigation.blade.php ENDPATH**/ ?>