<?php $__env->startSection('content'); ?>
    <h1 class="title">Pegawai <span class="tag is-dark">Signature</span></h1>

    <div class="box">
        <h4 class="title is-4"><?php echo e($pegawai->user->name); ?> </h4>
        <a class="button" href="<?php echo e(route('admin.settings.umum.index')); ?>">
            <span class="icon"><i class="fas fa-angle-left"></i></span>
            <span>Kembali</span>
        </a>
    </div>

    <div class="columns">
        <div class="column">
            <?php $__env->startComponent('components.card', ['title' => 'Upload Signature']); ?>
                <?php echo $form; ?>

            <?php echo $__env->renderComponent(); ?>
        </div>
        <?php if(! is_null($pegawai->signature)): ?>
            <div class="column has-text-centered">
                <?php $__env->startComponent('components.card', ['title' => 'Preview TTD']); ?>
                    <img src="<?php echo e(Storage::url('signatures/' . $pegawai->signature)); ?>" alt="">
                <?php echo $__env->renderComponent(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/settings/signature/edit.blade.php ENDPATH**/ ?>