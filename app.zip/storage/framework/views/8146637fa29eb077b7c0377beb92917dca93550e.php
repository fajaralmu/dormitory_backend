<?php $__env->startComponent('components.inputhorizontal', ["label"=>$label]); ?>
    <div class="field is-grouped">
        <p class="control select">
            <select autocomplete="off" name="<?php echo e($names[0]); ?>" class="select">
                <?php for($i = 1; $i <= 31; $i++): ?>
                    <option <?php echo e((int)date('d') == $i ? 'selected' : ''); ?>  value=<?php echo e($i); ?>><?php echo e($i); ?></option>
                <?php endfor; ?>
            </select>
        </p>
        <p class="control select">
            <select autocomplete="off"  name="<?php echo e($names[1]); ?>" class="select">
                <?php $__currentLoopData = App\Utils\DateUtil::$MONTH_NAMES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e((int)date('m') == $loop->index+1 ? 'selected' : ''); ?>   value=<?php echo e($loop->index + 1); ?>><?php echo e($month); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </p>
        <p class="control">
        <input type="number" autocomplete="off" class="input" name="<?php echo e($names[2]); ?>" value="<?php echo e(date("Y")); ?>"/>
        </p>
    </div>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/components/selectperiod.blade.php ENDPATH**/ ?>