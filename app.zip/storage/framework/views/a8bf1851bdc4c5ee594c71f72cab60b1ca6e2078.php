<?php if(Str::contains(request()->route()->getPrefix(), 'admin')): ?>
    <a href="<?php echo e(route('admin.home')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-home"></i>
        </span>
        <span style="margin-left: 5px;">Home</span>
    </a>

    <a href="<?php echo e(route('admin.halaqoh.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-folder"></i>
        </span>
        <span style="margin-left: 5px;">Halaqoh</span>
    </a>

    <a href="<?php echo e(route('admin.penilaian-periodik.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-folder"></i>
        </span>
        <span style="margin-left: 5px;">Penilaian Periodik</span>
    </a>

     

    <a href="<?php echo e(route('admin.penilaian-individual.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-folder"></i>
        </span>
        <span style="margin-left: 5px;">Penilaian Individual</span>
    </a>

    <div x-data="{open: false}" class="navbar-item has-dropdown is-hoverable">
        <a x-on:click="open = !open" class="navbar-link">
            Penilaian PTS
        </a>

        <div class="navbar-dropdown" x-show="open">
            <a href="<?php echo e(route('admin.pts.penguji.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Penguji</span>
            </a>
            <a href="<?php echo e(route('admin.pts.progres-penguji.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Rekapitulasi</span>
            </a>
        </div>
    </div>


    <div x-data="{open: false}" class="navbar-item has-dropdown is-hoverable">
        <a x-on:click="open = !open" class="navbar-link">
            Penilaian Akhir
        </a>

        <div class="navbar-dropdown" x-show="open">
            <a href="<?php echo e(route('admin.pas.penguji.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Penguji</span>
            </a>

            <a href="<?php echo e(route('admin.pas.peta-juz.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Peta Juz</span>
            </a>

            <a href="<?php echo e(route('admin.pas.kriteria-bobot.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Kriteria & Bobot</span>
            </a>

            <a href="<?php echo e(route('admin.pas.munaqosyah.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Munaqosyah</span>
            </a>

            <a href="<?php echo e(route('admin.pas.progres-penguji.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Rekapitulasi</span>
            </a>
        </div>
    </div>

    <div x-data="{open: false}" class="navbar-item has-dropdown is-hoverable">
        <a x-on:click="open = !open" class="navbar-link">
            Pengaturan
        </a>

        <div class="navbar-dropdown" x-show="open">
            <a href="<?php echo e(route('admin.settings.umum.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-cog"></i>
                </span>
                <span style="margin-left: 5px;">Umum</span>
            </a>

            <a href="<?php echo e(route('admin.settings.level-target.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-cog"></i>
                </span>
                <span style="margin-left: 5px;">Level & Target</span>
            </a>
            <a href="<?php echo e(route('admin.settings.events.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-calendar-alt"></i>
                </span>
                <span style="margin-left: 5px;">Events Timeline</span>
            </a>
        </div>
    </div>

    <div x-data="{open: false}" class="navbar-item has-dropdown is-hoverable">
        <a x-on:click="open = !open" class="navbar-link">
            Laporan
        </a>

        <div class="navbar-dropdown" x-show="open">
            <a href="<?php echo e(route('admin.laporan.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Hasil Penilaian PAS</span>
            </a>
            <a href="<?php echo e(route('admin.laporan-pts.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-folder"></i>
                </span>
                <span style="margin-left: 5px;">Hasil Penilaian PTS</span>
            </a>
            <a href="<?php echo e(route('admin.mutabaah.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-calendar-alt"></i>
                </span>
                <span style="margin-left: 5px;">Kegiatan Harian</span>
            </a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/navbars/admin.blade.php ENDPATH**/ ?>