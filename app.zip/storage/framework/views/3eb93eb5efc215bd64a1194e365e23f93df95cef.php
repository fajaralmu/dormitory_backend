<?php if(Str::contains(request()->route()->getPrefix(), 'musyrif')): ?>
    <a href="<?php echo e(route('musyrif.home')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-home"></i>
        </span>
        <span style="margin-left: 5px;">Home</span>
    </a>

    <a href="<?php echo e(route('musyrif.panduan.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-life-ring"></i>
        </span>
        <span style="margin-left: 5px;">Panduan</span>
    </a>

    <?php if($user_is_penguji && ! Str::contains(request()->route()->getPrefix(), 'tester')): ?>
        <a href="<?php echo e(route('tester.home')); ?>" class="navbar-item">
            <span class="icon">
                <i class="fas fa-book-reader"></i>
            </span>
            <span style="margin-left: 5px;">Ruang Penguji</span>
        </a>
    <?php endif; ?>

    <a href="<?php echo e(route('musyrif.penilaian-periodik.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-folder"></i>
        </span>
        <span style="margin-left: 5px;">Penilaian Periodik</span>
    </a>

    <a href="<?php echo e(route('musyrif.penilaian-individual.index')); ?>" class="navbar-item">
        <span class="icon">
            <i class="fas fa-folder"></i>
        </span>
        <span style="margin-left: 5px;">Penilaian Individual</span>
    </a>

    <div x-data="{ open: false }" class="navbar-item has-dropdown is-hoverable">
        <a x-on:click="open = !open" class="navbar-link">
            Mutabaah Harian
        </a>

        <div class="navbar-dropdown" x-show="open">
            
            
            <a href="<?php echo e(route('musyrif.harianv2.index')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-edit"></i>
                </span>
                <span style="margin-left: 5px;">Isi Mutabaah</span>
            </a>
            <a href="<?php echo e(url('musyrif/mutabaah/laporan')); ?>" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span style="margin-left: 5px;">Laporan Mutabaah</span>
            </a>
        </div>
    </div>

    <div x-data="{ open: false }" class="navbar-item has-dropdown is-hoverable">
        <a x-on:click="open = !open" class="navbar-link">
            Laporan
        </a>

        <div class="navbar-dropdown" x-show="open">
            <a href="#" class="navbar-item">
                <span class="icon">
                    <i class="fas fa-chart-bar"></i>
                </span>
                <span style="margin-left: 5px;">Statistik</span>
            </a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/navbars/musyrif.blade.php ENDPATH**/ ?>