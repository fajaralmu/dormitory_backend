<?php $__env->startSection('content'); ?>
    <div class="notification is-info">
        <span class="icon">
            <i class="fas fa-info-circle"></i>
        </span>
        <span>Welcome, quran tester.</span>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/tester/dashboard.blade.php ENDPATH**/ ?>