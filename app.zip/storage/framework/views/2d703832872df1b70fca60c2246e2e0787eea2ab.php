<?php
    $semester = config('school.semester');
    $global_basic = Arr::get($settings, 'global_basic');
    $total_examined = 0;
    $total_target = 0;
?>

<?php $__env->startSection('content'); ?>
    <h1 class="title">Rekapitulasi <span class="tag is-dark">Penilaian Tengah Semester</span></h1>

    <div class="tabs is-boxed is-centered">
        <ul>
            <li class="is-active">
                <a>Proges Penguji</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.pts.hasil-penilaian-siswa.index')); ?>">Hasil Penilaian Siswa</a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.pts.detail-score')); ?>">Detail Nilai Siswa</a>
            </li>
        </ul>
    </div>
    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.pts.progres-penguji.index')); ?>" class="button is-outlined is-primary">
                <span class="icon">
                    <i class="fas fa-list"></i>
                </span>
                <span>Indeks</span>
            </a>
        </div>
    </div>
    <div class="box">
        <h4 class="title is-4"><?php echo e($tester->pegawai->user->name); ?></h4>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'Progres Penilaian Siswa']); ?>
        <div class="tags has-addons are-medium">
            <span class="tag is-dark">Total target</span>
            <span id="total-target" class="tag is-info">0</span>
            <span class="tag is-dark">Total diuji</span>
            <span id="total-examined" class="tag is-info">0</span>
        </div>
        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Siswa</th>
                    <th>Kelas</th>
                    <th class="has-text-centered">Target</th>
                    <th class="has-text-centered">Diuji</th>
                    <th class="has-text-centered">Diselesaikan</th>
                    <th class="has-text-centered">Nilai Akhir</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tester->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $kelas = $member->siswa->kelas;
                        $accumulations = $member->siswa->pts_accumulations;
                        $halaqoh_membership = $member->siswa->halaqohs->first();
                        $kategori = Arr::get($halaqoh_membership, 'level');

                        // if ($kategori === 'basic') {
                        //     $global_basic_for_level = [7, 8, 10, 11]; // TODO: move this to config

                        //     if (in_array( Arr::get($kelas, 'level'), $global_basic_for_level)) {
                        //         $targets = Arr::get($global_basic,  Arr::get($kelas, 'level') . '.' . $semester);
                        //     } else {
                        //         $targets = Arr::get($halaqoh_membership->targets->first(), 'peta_juz', []);
                        //     }
                        // } else {
                        //     $targets = Arr::get($settings, 'pemetaan_juz_ujian.' . $kategori . '.' . Arr::get($kelas, 'level') . '.' . $semester, []);
                        // }

                      //  $nilai_akhir = $summary_accumulation / count($targets); //$accumulations->sum('score') / count($targets);
                    ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($member->siswa->user->name); ?></td>
                        <td><?php echo e(Arr::get($member->siswa->kelas, 'level') . Arr::get($member->siswa->kelas, 'rombel')); ?></td>
                        <td class="has-text-centered"><?php echo e(($member->siswa->getPtsTarget())); ?></td>
                        <td class="has-text-centered"><?php echo e(($member->siswa->getPtsExamined())); ?></td>
                        <td class="has-text-centered"><?php echo e(($member->siswa->getPtsFinished())); ?></td>
                        <td class="has-text-centered"><?php echo e(number_format($member->final_score, 2)); ?></td>
                        <td class="has-text-right">
                            <a class="button is-text has-text-dark" href="<?php echo e(route('admin.pts.hasil-penilaian-siswa.show', $member->siswa->id)); ?>">
                                <i class="fas fa-list"></i>
                            </a>
                        </td>
                    </tr>
                    <?php
                        $total_target+=$member->siswa->getPtsTarget();
                        $total_examined+=$member->siswa->getPtsExamined();
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php echo $__env->renderComponent(); ?>
    <script text="text/javascript">
        document.getElementById("total-target").innerHTML = <?php echo e($total_target); ?>;
        document.getElementById("total-examined").innerHTML = <?php echo e($total_examined); ?>;
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pts/rekapitulasi/progres-penguji/show.blade.php ENDPATH**/ ?>