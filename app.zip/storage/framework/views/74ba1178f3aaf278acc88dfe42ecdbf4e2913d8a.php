<?php $__env->startSection('content'); ?>
    <h1 class="title">Settings PAS <span class="tag is-dark">Kriteria & Bobot</span></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pas/kriteria-bobot/index.blade.php ENDPATH**/ ?>