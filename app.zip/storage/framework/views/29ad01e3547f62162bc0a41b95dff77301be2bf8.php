<?php $__env->startSection('content'); ?>
	<div class="columns">
		<div class="column is-6 is-offset-3">
			<div class="notification is-info">
        <span class="icon">
            <i class="fas fa-info-circle"></i>
        </span>
        <span>You are logged in!</span>
	    </div>
	    <img width="100%" src="<?php echo e(asset('img/quran.png')); ?>" alt="<?php echo e(config('app.name')); ?>">
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/teacher/dashboard.blade.php ENDPATH**/ ?>