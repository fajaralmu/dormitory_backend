

<?php if(isset($url)): ?>
    <form action="<?php echo e($url); ?>" class="delete-forms" method="POST" style="display: inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button name="delete-item" class="button is-text has-text-danger">
            <span class="icon">
                <i class="fas fa-trash"></i>
            </span>
        </button>
    </form>
<?php else: ?>
    <button name="delete-item" class="button is-text has-text-danger">
        <span class="icon">
            <i class="fas fa-trash"></i>
        </span>
    </button>
<?php endif; ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/components/delete-button.blade.php ENDPATH**/ ?>