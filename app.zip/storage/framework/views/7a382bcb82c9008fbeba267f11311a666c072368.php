<?php $__env->startSection('content'); ?>
    <h1 class="title">Penguji <span class="tag is-dark">Penilaian Akhir</span></h1>

    <div class="level">
        <div class="level-left">
            <a href="<?php echo e(route('admin.pas.penguji.create')); ?>" class="button is-primary is-rounded">
                <span class="icon">
                    <i class="fas fa-plus"></i>
                </span>
                <span>Penguji Baru</span>
            </a>
        </div>
    </div>

    <?php if($pengujis->count()): ?>
        <?php $__env->startComponent('components.card', ['title' => 'Data Penguji Akhir Semester']); ?>

        <?php $__env->startComponent('components.singleselect', ['id'=>'select-display', 
            'options'=> [''=>'--choose display--', 'table'=>'Table', 'card'=>'Card']]); ?>
        <?php echo $__env->renderComponent(); ?>

        <?php if(isset($listDisplay) && $listDisplay == 'card'): ?>
        <div class="columns is-multiline">
            <?php $__currentLoopData = $pengujis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penguji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column is-one-third">
                    <div class="card">
                        <header class="card-header">
                        </header>
                        <div class="card-content ">
                            <div class="card-image has-text-centered" >
                                <img width="200" height="100"
                                src="<?php echo e(asset('img/quran.png')); ?>" />
                            </div>
                            <h5 style="margin-top: 7px; font-style: bold; text-align: center"><?php echo e($penguji->pegawai->user->name); ?></h5>

                        </div>
                        <footer class="card-footer" style="display: grid; grid-template-columns: 33% 33% 33%">
                            <span class="tag is-info is-light is-large">
                                <?php echo e($penguji->members_count); ?>

                            </span>
                            <a href="<?php echo e(route('admin.pas.penguji.students.index', $penguji)); ?>" class="button is-text">
                                <i class="fas fa-list"></i>
                            </a>
                            <div>
                                <?php echo $__env->make('components.delete-button', ['url' => route('admin.pas.penguji.destroy', $penguji)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </footer>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
            <table class="table is-fullwidth is-vcentered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Penguji</th>
                        <th class="has-text-centered">Siswa</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pengujis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penguji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($penguji->pegawai->user->name); ?></td>
                            <td class="has-text-centered"><?php echo e($penguji->members_count); ?></td>
                            <td class="has-text-right">
                                <a href="<?php echo e(route('admin.pas.penguji.students.index', $penguji)); ?>" class="button is-text">
                                    <i class="fas fa-list"></i>
                                </a>
                                <?php echo $__env->make('components.delete-button', ['url' => route('admin.pas.penguji.destroy', $penguji)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <?php echo $__env->renderComponent(); ?>
        <script>
            function init(){
                gotoPageWhenChanged("select-display", function(value){
                   return "/admin/pas/penguji?display="+value;
                }); 

                <?php if(isset($listDisplay)  ): ?>
                   byId("select-display").value = "<?php echo e($listDisplay); ?>";
                <?php endif; ?>

            }

            init();
        </script>
    <?php else: ?>
        <div class="notification is-warning">
            No data penguji yet.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pas/penguji/index.blade.php ENDPATH**/ ?>