<nav class="navbar">
  <div class="navbar-brand">
    <a class="navbar-item" href="/">
        <span class="icon is-medium">
          <i class="fas fa-quran fa-lg"></i>
        </span>
        <span class="has-text-weight-bold">Tahfiz Application</span>
    </a>
    <span class="navbar-burger burger" data-target="navbarMenu">
      <span></span>
      <span></span>
      <span></span>
    </span>
  </div>
  <div id="navbarMenu" class="navbar-menu">
    <?php if(Auth::check()): ?>
      <div class="navbar-start">
        
        <?php if($user_is_penguji && ! Str::contains(request()->route()->getPrefix(), 'tester')): ?>
          <a href="<?php echo e(route('tester.home')); ?>" class="navbar-item">
            <span class="icon">
              <i class="fas fa-book-reader"></i>
            </span>
            <span style="margin-left: 5px;">Ruang Penguji</span>
          </a>
        <?php endif; ?>

        <?php if($user_is_musyrif && ! Str::contains(request()->route()->getPrefix(), 'musyrif')): ?>
          <a href="<?php echo e(route('musyrif.home')); ?>" class="navbar-item">
            <span class="icon">
              <i class="fas fa-heart"></i>
            </span>
            <span style="margin-left: 5px;">Ruang Musyrif</span>
          </a>
        <?php endif; ?>

        <?php if(Auth::user()->hasRole(['admin_tahfiz']) && ! Str::contains(request()->route()->getPrefix(), 'admin')): ?>
          <a href="<?php echo e(route('admin.home')); ?>" class="navbar-item">
            <span class="icon">
              <i class="fas fa-cogs"></i>
            </span>
            <span style="margin-left: 5px;">Admin</span>
          </a>
        <?php endif; ?>
      </div>
    <?php endif; ?>
    <div class="navbar-end">
      <div class="navbar-item">
        <div class="buttons">
          <?php if(Auth::guest()): ?>
            <a href="/login" class="button is-dark is-rounded">
              <span class="icon">
                  <i class="fas fa-sign-in-alt"></i>
              </span>
              <span>Login</span>
            </a>
          <?php else: ?>
            <a class="button">
              <span class="icon">
                <i class="fas fa-user-circle"></i>
              </span>
              <span><?php echo e(Auth::user()->name); ?></span>
            </a>
            <a class="button is-danger is-rounded" onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
              <span class="icon">
                <i class="fas fa-sign-out-alt"></i>
              </span>
              <span><?php echo e(__('Logout')); ?></span>
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</nav><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/navbars/navbar-front.blade.php ENDPATH**/ ?>