<?php $__env->startSection('content'); ?>
    <h1 class="title">Peserta <span class="tag is-dark">PTS</span></h1>

    <div class="box">
        <h4 class="title is-4 has-text-weight-light">
            <span class="icon">
                <i class="fas fa-user-circle"></i>
            </span>
            <span><?php echo e($member->siswa->user->name); ?></span>
        </h4>
        <p class="subtitle is-size-6">
            Current tester: <strong><?php echo e($member->penguji_pts->pegawai->user->name); ?></strong>
        </p>
    </div>

    <?php $__env->startComponent('components.card', ['title' => 'Tukar Penguji PTS']); ?>
        <form action="<?php echo e(route('admin.pts.penguji.students.update', [$penguji, $member])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="field is-horizontal">
                <div class="field-label is-normal">
                    <label class="label">Penguji Tujuan</label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="control">
                            <div class="select">
                                <select name="new_tester">
                                    <option value="none">Pilih Penguji Tujuan</option>
                                    <?php $__currentLoopData = $testers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="field is-horizontal">
                <div class="field-label">
                    <!-- Left empty for spacing -->
                    <label for="" class="label"></label>
                </div>
                <div class="field-body">
                    <div class="field">
                        <div class="control">
                            <button type="submit" class="button is-success">
                                Submit
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pts/penguji/students/edit.blade.php ENDPATH**/ ?>