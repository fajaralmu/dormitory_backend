<?php
    $title = 'Create Penilaian Individual';

    if ($rapor) {
        $title = 'Edit Penilaian Individual';
    }
?>



<?php $__env->startSection('detail'); ?>
    <h1 class="title">Penilaian Individual</h1>

    <?php $__env->startComponent('components.card', ['title' => $title]); ?>
		<?php echo $form; ?>

    <?php echo $__env->renderComponent(); ?>

    <script type="text/javascript">
        const form = document.getElementById("form-penilaian-individual");
        form.onsubmit = function(e){
            const inputCatatan = document.getElementsByName("catatan")[0];
            if (inputCatatan.value && inputCatatan.value.length > 210) {
                infoDialog("Maksimal Catatan adalah 210 karakter").then(null);
                e.preventDefault();
                 
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/penilaian-individual/create.blade.php ENDPATH**/ ?>