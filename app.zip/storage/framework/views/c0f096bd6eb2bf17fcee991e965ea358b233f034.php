<?php $__env->startSection('content'); ?>
    <h1 class="title">Rekapitulasi <span class="tag is-dark">Penilaian Tengah Semester</span></h1>

    <div class="tabs is-boxed is-centered">
        <ul>
            <li>
                <a href="<?php echo e(route('admin.pts.progres-penguji.index')); ?>">Proges Penguji</a>
            </li>
            <li >
                <a href="<?php echo e(route('admin.pts.hasil-penilaian-siswa.index')); ?>">Hasil Penilaian Siswa</a>
            </li>
            <li class="is-active">
                <a>Detail Nilai Siswa</a>
            </li>
        </ul>
    </div>

    <?php if($students->count()): ?>
        <div class="level">
            <div class="level-left">
                <form action="<?php echo e(route('admin.pts.detail-score')); ?>" method="GET">
                    <div class="field is-grouped">
                        <div class="control has-icons-left">
                            <input name="siswa" type="text" value="<?php echo e($filterStudentName); ?>" class="input is-rounded" placeholder="Temukan siswa...">
                            <span class="icon is-left">
                                <i class="fas fa-search"></i>
                            </span>
                        </div>

                        <div class="control"> 
                            <div class="select is-rounded" >
                               <select  name="order">
                                    <option value="">No Order</option>
                                    <option value="asc" <?php echo e($orderType == 'asc' ? 'selected' : ''); ?>>Nama A-Z</option>
                                    <option value="desc" <?php echo e($orderType == 'desc' ? 'selected' : ''); ?>>Nama Z-A</option>
                               </select>
                            </div>
                        </div>  
                        <div class="control">
                            <button class="button is-primary"><i class="fas fa-search"></i></button>
                          </div>                  
                    </div>
                    
                    
                </form>
            </div>

            <div class="level-right">
                <div class="field is-grouped">
                    <div class="control">
                    <div class="dropdown is-right is-hoverable">
                        <div class="dropdown-trigger">
                            <button class="button is-dark" aria-haspopup="true" aria-controls="dropdown-menu4">
                                <span class="icon">
                                    <i class="fas fa-filter"></i>
                                </span>
                                <span>Filter By Halaqoh</span>
                                <span class="icon is-small">
                                    <i class="fas fa-angle-down" aria-hidden="true"></i>
                                </span>
                            </button>
                        </div>
                        <div class="dropdown-menu" id="dropdown-menu4" role="menu">
                            <div class="dropdown-content">
                                <?php $__currentLoopData = $halaqohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $halaqoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('admin.pts.detail-score', ['halaqoh' => $halaqoh['id']])); ?>" class="dropdown-item"><?php echo e($halaqoh['nama'] . ' - Ust. ' .  $halaqoh['musyrif']); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                    <div class="control">
                        <div class="dropdown is-right is-hoverable">
                            <div class="dropdown-trigger">
                                <button class="button is-info" aria-haspopup="true" aria-controls="dropdown-menu4">
                                    <span class="icon">
                                        <i class="fas fa-filter"></i>
                                    </span>
                                    <span>Filter By Kelas</span>
                                    <span class="icon is-small">
                                        <i class="fas fa-angle-down" aria-hidden="true"></i>
                                    </span>
                                </button>
                            </div>
                            <div class="dropdown-menu" id="dropdown-menu4" role="menu">
                                <div class="dropdown-content">
                                    <?php $__currentLoopData = $kelases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('admin.pts.detail-score', ['kelas' => $kelas->id])); ?>" class="dropdown-item">Kelas <?php echo e($kelas->level . $kelas->rombel); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if(request()->has('halaqoh')): ?>
            <?php
                $halqoh_filter = collect($halaqohs)->where('id', request()->halaqoh)->first();
            ?>
            <div class="notification is-info">
                Below data is filtered by halaqoh <strong><?php echo e(Arr::get($halqoh_filter, 'nama')); ?> - Ust. <?php echo e(Arr::get($halqoh_filter, 'musyrif')); ?></strong>
            </div>
        <?php endif; ?>

        <?php if(request()->has('kelas')): ?>
            <?php
                $kelas_filter = $kelases->where('id', request()->get('kelas'))->first();
            ?>
            <div class="notification is-info">
                Below data is filtered by kelas <strong><?php echo e(Arr::get($kelas_filter, 'level')); ?> - <?php echo e(Arr::get($kelas_filter, 'rombel')); ?></strong>
            </div>
        <?php endif; ?>

        <table class="table is-fullwidth is-vcentered">
            <thead>
                <tr>
                    <th>Nama Siswa</th>
                    <th class="has-text-centered">Musyrif</th>
                    <th class="has-text-centered">Penguji</th>
                    <th class="has-text-centered">Kategori</th>
                    <th class="has-text-centered">Fashohah</th>
                    <th class="has-text-centered">Tajwid</th>
                    <th class="has-text-centered">Kelancaran</th>
                    <th class="has-text-centered">Nilai Akhir</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $students->forPage(request()->get('page', 1), 30); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student['name']); ?></td>
                        <td class="has-text-centered"><?php echo e($student['musyrif']); ?></td>
                        <td class="has-text-centered"><?php echo e($student['penguji']); ?></td>
                        <td class="has-text-centered"><?php echo e($student['kategori']); ?></td>
                        <td class="has-text-centered"><?php echo e(Arr::get($student['summary_pts_detail_score'], 'fashohah')); ?></td>
                        <td class="has-text-centered"><?php echo e(Arr::get($student['summary_pts_detail_score'], 'tajwid')); ?></td>
                        <td class="has-text-centered"><?php echo e(Arr::get($student['summary_pts_detail_score'], 'kelancaran')); ?></td>
                        <td class="has-text-centered"><?php echo e(Arr::get($student['summary_pts_detail_score'], 'penilaian')); ?></td>
                        <td class="has-text-right">
                            <a href="<?php echo e(route('admin.pts.hasil-penilaian-siswa.show', $student['siswa_id'])); ?>" class="button is-text">
                                <i class="fas fa-list"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <?php echo e($pagination->appends(request()->only(['kelas', 'siswa','order']))->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/pts/rekapitulasi/hasil-penilaian-siswa/score-detail.blade.php ENDPATH**/ ?>