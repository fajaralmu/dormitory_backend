<?php $__env->startSection('detail'); ?>


    <h1 class="title">Pilihan Waktu Penilaian Harian <?php echo e($date_str); ?></h1>
    <?php echo $__env->make('musyrif.dailyactivitiesv2.select-time', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/dailyactivitiesv2/edit-select-time.blade.php ENDPATH**/ ?>