<?php $__env->startSection('content'); ?>


    <h1 class="title">Opsi Penilaian Harian <?php echo e($date_str??""); ?></h1>
    <?php echo $__env->make('admin.laporan.harian.select-time', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/harian/detail-select-time.blade.php ENDPATH**/ ?>