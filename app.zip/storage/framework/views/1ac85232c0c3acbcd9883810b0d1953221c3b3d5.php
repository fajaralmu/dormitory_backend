<?php if($halaqohs_count > 1): ?>
	<div style="margin-bottom: 15px;">
		<a href="<?php echo e(route('halaqoh.gateway')); ?>" class="button is-small is-info">
			<span class="icon">
				<i class="fas fa-heart"></i>
			</span>
			<span>Halaqoh <?php echo e($halaqoh->nama); ?></span>
		</a>
	</div>
<?php endif; ?>
<?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/halaqoh.blade.php ENDPATH**/ ?>