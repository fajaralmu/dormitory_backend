<?php $__env->startSection('content'); ?>
    <script type="text/javascript">
        const months = <?php echo json_encode(App\Utils\DateUtil::$MONTH_NAMES); ?>;
        
    </script>
    
    <h1 class="title">Laporan Detail Mutabaah Halaqoh <?php echo e($halaqoh->nama); ?></h1>
    <?php $__env->startComponent('components.card', ['title' => 'Filter']); ?>
    <form onsubmit="loadData(event)">
        <?php $__env->startComponent('components.inputhorizontal', ['label'=>'Siswa']); ?>
            <div class="select">
                <select id="select-student" name="siswa_id" autocomplete="off" >
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?> - <?php echo e($student->level.$student->rombel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.selectperiod', ['label'=>'Dari Periode', 'names' => ['day', 'month', 'year']]); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.selectperiod', ['label'=>'Sampai Periode', 'names' => ['dayTo', 'monthTo', 'yearTo']]); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('components.inputhorizontal', ["label"=>null]); ?>
            <button type="submit" class="button is-success" >
                <span class="icon"><i class="fas fa-play-circle"></i></span>
                <span>Submit</span>
            </button>
            <a href="<?php echo e(url('admin/mutabaah')); ?>" class="button is-link"><span class="icon"><i class="fas fa-arrow-circle-left"></i></span><span>Kembali</span></a>
            <a onclick="printContent()" class="button is-outlined is-dark"><span class="icon"><i class="fas fa-print"></i></span><span>Cetak</span></a>
        <?php echo $__env->renderComponent(); ?>
    </form>
    <?php echo $__env->renderComponent(); ?>

    <?php $__env->startComponent('components.card', ['title'=>'Record List']); ?>
    
    <div id="record-list-wrapper" style="overflow: scroll; padding-bottom: 20px">
        <table class="table is-bordered" id="record-list-table" >
            <thead id="list-thead">
            </thead>
            <tbody id="list-tbody">
            </tbody>
        </table>
    </div>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('components.card', ['title'=>'Summary']); ?>
    <div class="columns" id="record-summary"> 
        <table  class="table is-bordered column is-fullwidth" >
            <tr>
                <td colspan="2">Kehadiran</td>
            </tr>
            <tr>
                <th style="width: 150px">Nama</th>
                <th  style="width: 150px">Jumlah</th>
            </tr>
            <tr>
                <td>Hadir</td>
                <td><strong id="summary-presence_h" ></strong></td>
            </tr>
            <tr>
                <td>Izin</td>
                <td><strong id="summary-presence_i" ></strong></td>
            </tr>
            <tr>
                <td>Sakit</td>
                <td><strong id="summary-presence_s" ></strong></td>
            </tr>
            <tr>
                <td>Alpa</td>
                <td><strong id="summary-presence_a" ></strong></td>
            </tr>
        </table>
        <table class="table is-bordered column is-fullwidth">
            <tr>
                <td colspan="2">Pelanggaran</td>
            </tr>
            <tr>
                <th style="width: 150px">Nama</th>
                <th  style="width: 150px">Jumlah</th>
            </tr>
            <tr>
                <td>Tidak Pembukaan</td>
                <td><strong id="summary-not_opening" ></strong></td>
            </tr>
            <tr>
                <td>Tidak Penutupan</td>
                <td><strong id="summary-not_closing" ></strong></td>
            </tr>
            <tr>
                <td>Tidak Setoran</td>
                <td><strong id="summary-not_recited" ></strong></td>
            </tr>
            
        </table>
    </div>
    <?php echo $__env->renderComponent(); ?>
    <script type="text/javascript">
    //thead and tbody is declared in daily_activities_summary.js
        thead = document.getElementById("list-thead");
        tbody = document.getElementById("list-tbody");
        const URL_REPORT = "<?php echo e(url('/admin/mutabaah/laporandetail')); ?>";
        function loadData(e) {
            startLoading();
            e.preventDefault();
            const formData = new FormData(e.target);
            const request = { filter: {} };
            for (var pair of formData.entries()) {
                request.filter[pair[0]]  =  pair[1];
            }
            
            axios.post(URL_REPORT, request)
            .then(function(response) {
                populateData(response.data);
            }).catch(function(e){
                alert("Operation failed: "+e);
            }).finally(stopLoading)
        } 

        setTableHead();

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/laporan/harian/laporan-detail.blade.php ENDPATH**/ ?>