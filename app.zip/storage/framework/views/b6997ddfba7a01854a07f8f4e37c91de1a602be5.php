<?php $__env->startSection('detail'); ?>
    <h1 class="title">Penilaian Individual</h1>

    <table class="table is-fullwidth is-vcentered">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama Siswa</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $halaqoh->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $accumulation = $member->siswa->periodic_accumulations->first();
                ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($member->siswa->user->name); ?></td>
                    <td class="has-text-right">
                        <?php if(Arr::has($rapors, $member->siswa->id)): ?>
                            <?php
                                $rapor = Arr::get($rapors, $member->siswa->id);
                            ?>
                            <a class="button is-text" href="<?php echo e(route('musyrif.penilaian-individual.show', $rapor->id)); ?>">
                                <i class="fas fa-file-alt"></i>
                            </a>
                        <?php endif; ?>
                    	<a href="<?php echo e(route('musyrif.penilaian-individual.edit', $member->siswa->id)); ?>" class="button is-text">
                    		<i class="fas fa-edit"></i>
                    	</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.musyrif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/musyrif/penilaian-individual/index.blade.php ENDPATH**/ ?>