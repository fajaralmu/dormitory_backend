<?php
/* OLD FUNCTIONS HERE ARE MOVED TO HELPERS */

$submit_or_button = Arr::first($fields, function ($field) {
    return in_array(Arr::get($field, 'type'), ['submit', 'button']);
});

$formId = $id ?? Str::random();
?>

<?php if($errors->any()): ?>
    <div class="notification is-danger">
        <i class="fas fa-info-circle fa-lg"></i>
        <span>Silahkan isi formulir dengan benar.</span>
    </div>
<?php endif; ?>

<form id="<?php echo e($formId); ?>" action="<?php echo e($url); ?>" method="<?php echo e(strtolower($method) == 'get' ? 'GET' : 'POST'); ?>" <?php echo e(count(hasInputFile($fields)) ? 'enctype=multipart/form-data' : ''); ?>>
    <?php echo csrf_field(); ?>

    <?php if(strtolower($method) !== 'get'): ?>
        <?php echo method_field($method); ?>
    <?php endif; ?>

    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $view = '';
            $type = Arr::get($field, 'type');

            if (in_array($type, ['text', 'email', 'password', 'number', 'hidden', 'file', 'date', 'time'])) {
                $view = 'form_builder::input';
            }

            if (in_array($type, ['submit', 'button'])) {
                $view = 'form_builder::button';
            }

            if (in_array($type, ['select', 'textarea', 'radio', 'checkbox'])) {
                $view = 'form_builder::' . $type;
            }
        ?>

        <?php if(in_array($type, ['submit', 'button'])): ?>
            <?php
                break;
            ?>
        <?php endif; ?>

        <?php if(strlen($view) > 0): ?>
            <?php echo $__env->make($view, [
                'orientation' => $orientation,
                'type' => $type,
                'name' => Arr::get($field, 'name'),
                'options' => Arr::get($field, 'options'),
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(isset($injected) && ! is_null($injected)): ?>
        <?php echo $injected; ?>

    <?php endif; ?>

    <?php if(! is_null($submit_or_button)): ?>
        <?php echo $__env->make('form_builder::button', [
            'orientation' => $orientation,
            'type' => Arr::get($submit_or_button, 'type'),
            'name' => Arr::get($submit_or_button, 'name'),
            'options' => Arr::get($submit_or_button, 'options'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</form>

<?php $__env->startSection('extra_script'); ?>
    ##parent-placeholder-3ec8bb2ec1819811b81ddbf0bedf06eaae655576##
    <script>
        var formId = '#<?php echo e($formId); ?>';
        var form = document.querySelector(formId);
        form.addEventListener('submit', function (e) {
            e.preventDefault();

            var lfb__all_inputs = document.querySelectorAll(formId + ' input');
            lfb__all_inputs.forEach(function (input) {
                input.disabled = false;
            });

            var lfb__all_textareas = document.querySelectorAll(formId + ' textarea');
            lfb__all_textareas.forEach(function (textarea) {
                textarea.disabled = false;
            });

            var lfb__all_selects = document.querySelectorAll(formId + ' select');
            lfb__all_selects.forEach(function (select) {
                select.disabled = false;
            });

            form.submit();
        });
    </script>
<?php $__env->stopSection(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\vendor\realcahsowan\laravel-bulma-form\src/../resources/views/master.blade.php ENDPATH**/ ?>