<?php $__env->startSection('content'); ?>
    <h1 class="title">Settings <span class="tag is-dark">Stempel</span></h1>

    <table class="table is-fullwidth is-vcentered">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama Sekolah</th>
                <th>Stempel</th>
                <th class="has-text-centered">Action</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $schoolConfigurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schoolConfiguration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $school = $schoolConfiguration->sekolah;
                $stempel = Arr::get($schoolConfiguration->settings,'stamp')
            ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e(is_null($school) ? "-" : $school->nama); ?></td>
                    <td> 
                        <?php if(!is_null($stempel)): ?>
                            <img width="100" height="100" src="<?php echo e(Storage::url('stamps/' . $stempel)); ?>" alt="">
                        <?php else: ?>
                            <span>Belum Ada</span>
                        <?php endif; ?>
                    </td>
                    <td class="has-text-centered">
                        <a href="<?php echo e(url('admin/settings/stamp/'. $schoolConfiguration->sekolah_id) .'/edit'); ?>" class="button">
                            <span class="icon"><i class="fas fa-edit"></i></span>
                            <span>Edit</span>
                        </a>
                         
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/admin/settings/stamp/index.blade.php ENDPATH**/ ?>