<?php
	$sidebarView = 'partials.sidebars.default';

	if (Str::contains(request()->route()->getPrefix(), 'admin')) {
		$sidebarView = 'partials.sidebars.admin';
	}

	if (Str::contains(request()->route()->getPrefix(), 'teacher')) {
		$sidebarView = 'partials.sidebars.teacher';
	}

	if (Str::contains(request()->route()->getPrefix(), 'musyrif')) {
		$sidebarView = 'partials.sidebars.musyrif';
	}

	if (Str::contains(request()->route()->getPrefix(), 'tester')) {
		$sidebarView = 'partials.sidebars.tester';
	}

	if (Str::contains(request()->route()->getPrefix(), 'student')) {
		$sidebarView = 'partials.sidebars.student';
	}
?>

<?php echo $__env->make($sidebarView, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\Kafila Projects\tahfizapp\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>